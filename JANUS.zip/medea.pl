#!/usr/bin/perl

use Cwd qw(); 
use strict;
use warnings;
#use diagnostics;
use Storable qw(dclone);
use List::Util qw[min max];
use Time::HiRes qw( time );
use warnings FATAL => 'all';
use Term::ANSIColor qw(:constants);
use Term::ANSIColor 2.00 qw(:pushpop);

my $cur_dir = Cwd::cwd();
push @INC, $cur_dir;
require janus_pack;

my $the_verb = 2;
my $ulb_diff = 31;
my $file_pla = "";
my $sat_limit = 300;
my $cpu_limit = 21600;

my $arg_ok = 1;
my $arg_cnt = 0;
while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
      last;
    }
    else{
      if (index($ARGV[$arg_cnt], "-verb=") != -1){
        $the_verb = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_verb < 0 or $the_verb > 2){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-cpu_lim=") != -1){
        $cpu_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9) + 0.0;
      }
      elsif (index($ARGV[$arg_cnt], "-sat_lim=") != -1){
        $sat_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9) + 0.0;
      }
      elsif (index($ARGV[$arg_cnt], "-ulbd=") != -1){
        $ulb_diff = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
      }
      else{
        if (!$arg_cnt){
          $file_pla = $ARGV[0];
        }
        else{
          $arg_ok = 0;
          last;
        }
      }
    }
  }
  else{
    if (!$arg_cnt){
      $arg_ok = 0;
    }
    last;
  }

  $arg_cnt++;
}

if ($arg_ok){
  if ($file_pla ne ""){
    main_part();
  }
  else{
    help_part();
  }
}
else{
  help_part();
}

sub help_part{
  print "############################################################################################################### \n";
  print "# Usage:       perl medea.pl <File_Name> -verb=0/1/2 -cpu_lim=<int> -sat_lim=<int> -ulbd=<int>                # \n";
  print "# File_Name:   Name of the file including a single target function given in PLA format                        # \n";
  print "# -verb:       Level of verbosity (0: full, 1: medium, 2: none), by default it is none                        # \n";
  print "# -cpu_lim:    CPU time limit in seconds, by default it is 21600                                              # \n";
  print "# -sat_lim:    CPU time limit for the SAT algorithm in seconds, by default it is 300                          # \n";
  print "# -ubld:       Difference between the upper and lower bounds greater than 0, by default it is 31              # \n";
  print "# Description: Finds the realization of a single logic function in a lattice including four-terminal switches # \n";
  print "############################################################################################################### \n";
}

sub is_inside_numeric_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] == $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub is_inside_string_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] eq $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub is_inside_array_list{
  my ($the_cnt, $conf_cnt, $the_arr_ref, $conf_arr_ref) = @_;
  my @the_arr = @ {$the_arr_ref};
  my @conf_arr = @ {$conf_arr_ref};

  my $the_value = 0;

  foreach my $i (1 .. $conf_cnt){
    if ($conf_arr[0][$i] == $the_cnt){
      my $is_equal = 1;
      foreach my $j (1 .. $conf_arr[0][$i]){
        if (!is_inside_string_array($conf_arr[$j][$i], $the_cnt, @the_arr)){
          $is_equal = 0;
          last;
        }
      }

      if ($is_equal){
        $the_value = 1;
        last;
      }
    }
  }

  return ($the_value);
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      return $the_offset;
    }
  }

  return $the_offset;
}

sub skip_spaces_backward{
  my ($the_string, $the_offset) = @_;

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset--;
    if ($the_offset < 0) {
      last;
    }
  }

  return $the_offset;
}

sub convert2binary{
  my ($the_int, $the_len) = @_;

  my @the_rep = ();

  foreach my $i (1 .. $the_len){
    $the_rep[$i] = 0;
  }

  my $the_index = 0;
  while ($the_int > 1){
    $the_index++;
    my $the_val = $the_int % 2;
    $the_rep[$the_index] = $the_val;
    $the_int = ($the_int - $the_val) / 2;
  }

  $the_index++;
  $the_rep[$the_index] = $the_int;

  return (@the_rep);
}

sub remove_dontcare_inputs{
  my ($file_simp) = @_;
  
  my $in_num = 0;
  my $out_num = 0;
  my $prod_num = 0;

  my @in_arr = ();
  my @out_arr = ();
  my @prod_arr = ();

  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  my $ndc_in_cnt;
  my @ndc_in_arr;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $in_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $out_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $in_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_cnt++;
          $in_arr[$in_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $out_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_cnt++;
          $out_arr[$out_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".") == -1){
        $prod_num++;

        my $in_cnt = 0;
        $the_index = skip_spaces_forward($the_line, 0);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $in_cnt++;
          $prod_arr[$in_cnt][$prod_num] = $the_char;
          $the_index++;

          if ($in_cnt == $in_num){
            last;
          }
        }

        my $out_cnt = 0;
        $the_index = skip_spaces_forward($the_line, $the_index);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $out_cnt++;
          $prod_arr[$in_num+$out_cnt][$prod_num] = substr($the_line, $the_index , 1);
          $the_index++;

          if ($out_cnt == $out_num){
            last;
          }
        }
      }
    }
    
    close $file_header;

    if (!(@in_arr)){
      foreach my $i (1 .. $in_num){
        $in_arr[$i] = $i;
      }
    }

    #Check if an input variable is DC
    my $dcin_cnt = 0;
    my @dcin_arr = ();
    foreach my $i (1 .. $in_num){
      my $is_dcin = 1;
      foreach my $j (1 .. $prod_num){
        if ($prod_arr[$i][$j] eq "0" or $prod_arr[$i][$j] eq "1"){
          $is_dcin = 0;
          last;
        }
      }

      if ($is_dcin){
        #print "[INFO] The $in_arr[$i] input is always DC and hence, is removed from the input list \n";
        $dcin_cnt++;
        $dcin_arr[$dcin_cnt] = $i;
      }
    }

    if ($dcin_cnt){
      $ndc_in_cnt = 0;
      @ndc_in_arr = ();

      open (my $fid_pla, '>', $file_simp);
      printf $fid_pla ".i %0d \n", $in_num - $dcin_cnt;
      printf $fid_pla ".o %0d \n", $out_num;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_num){
          if (!is_inside_numeric_array($i, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s ", $in_arr[$i];

            $ndc_in_cnt++;
            $ndc_in_arr[$ndc_in_cnt] = $in_arr[$i];
          }
        }
        printf $fid_pla "\n";
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_num){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".p %0d \n", $prod_num;
      foreach my $i (1 .. $prod_num){
        foreach my $j (1 .. $in_num){
          if (!is_inside_numeric_array($j, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s", $prod_arr[$j][$i];
          }
        }
        printf $fid_pla " ";
        foreach my $j (1 .. $out_num){
          printf $fid_pla "%0s", $prod_arr[$in_num+$j][$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".e \n";
      close ($fid_pla);
    }
    else{
      $ndc_in_cnt = $in_num;
      @ndc_in_arr = @in_arr;
    }

  }
  else{
    print RED, "Could not open the $file_simp file \n";
  }

  return ($ndc_in_cnt, @ndc_in_arr);
}

sub simplify_sop{
  my ($file_dir, $file_main, $the_file, $path_espresso) = @_;
  #print "The file: $the_file \n";

  my $false_true = -1;
  
  my $in_cnt = 0;
  my $in_say = 0;
  my $lit_cnt = 0;
  my $out_cnt = 0;
  my $out_say = 0;
  my @in_arr = ();
  my @tt_arr = ();
  my @lit_arr = ();
  my @out_arr = ();
  
  my $deg_simp = 0;
  my $prod_simp = 0;
  my $mindeg_simp = 0;
  my $prod_cnt_simp = 0;
  my @prod_num_simp = ();
  my @prod_lvl_simp = ();
  my @prod_ind_simp = ();
  my @prod_arr_simp = ();

  my $init_index = 0;
  my $last_index = 0;

  my $file_simp = $file_main . "_simp.pla";

  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $prod_cnt = 0;
    my @prod_arr = ();
    my $minreq_cnt = 0;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $minreq_cnt++;
        $in_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $minreq_cnt++;
        $out_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_say++;
          $in_arr[$in_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($in_cnt and $in_say != $in_cnt){
          print RED, "[ERROR] The number of inputs is not the same as the number of input labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_say++;
          $out_arr[$out_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($out_cnt and $out_say != $out_cnt){
          print RED, "[ERROR] The number of outputs is not the same as the number of output labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".") == -1){
        if ($minreq_cnt < 2){
          $prod_cnt++;
          $prod_arr[$prod_cnt] = $the_line;
        }
      }
    }

    close $file_header;

    if ($minreq_cnt < 2){
      my $init_index = skip_spaces_forward($prod_arr[1], 0);
      my $last_index = index($prod_arr[1], " ", $init_index);
      $in_cnt = $last_index - $init_index;

      $last_index = skip_spaces_forward($prod_arr[1], $last_index);
      while (substr($prod_arr[1], $last_index, 1) ne " "){
        $last_index++;
        $out_cnt++;

        if ($last_index >= length($prod_arr[1])){
          last;
        }
      }

      my $file_temp = $file_dir . "temp_file.pla";
      open (my $fid_pla, '>', $file_temp);
      printf $fid_pla ".i %0s \n", $in_cnt;
      printf $fid_pla ".o %0s \n", $out_cnt;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_say){
          printf $fid_pla "%0s ", $in_arr[$i];
        }
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_say){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
      }
      printf $fid_pla ".p %0s \n", $prod_cnt;
      foreach my $i (1 .. $prod_cnt){
        printf $fid_pla "%0s \n", $prod_arr[$i];
      }
      printf $fid_pla ".e \n";
      close $fid_pla;

      my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_simp;
      system($the_cmd);
    }
    else{
      my $the_cmd = $path_espresso . " -Dexact " . $the_file . " > " . $file_simp;
      system($the_cmd);
    }

    if (!@in_arr){
      foreach my $i (1 .. $in_cnt){
        $in_arr[$i] = "$i";
      }
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
    return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
  }

  ($in_cnt, @in_arr) = remove_dontcare_inputs($file_simp);

  #Generating the initial truth table with full of zeros
  foreach my $i (0 .. 2**$in_cnt-1) {
    my @bin_rep = convert2binary($i, $in_cnt);
    foreach my $j (1 .. $in_cnt){
      $tt_arr[$i][$j] = $bin_rep[$j];
    }
    $tt_arr[$i][$in_cnt+1] = 0;
  }

  #Display the truth table
  #foreach my $i (0 .. 2**$in_cnt-1){
  #  foreach my $j (1 .. $in_cnt+1){
  #    print "$tt_arr[$i][$j]";
  #  }
  #  print "\n";
  #}

  #Generating the initial literal index array
  my @lit_index_arr = ();
  foreach my $i (1 .. 2*$in_cnt){
    $lit_index_arr[$i] = 0;
  }

  my $in_simp = 0;
  my $neg_lit = 0;
  my $pos_lit = 0;
  #Find the degree for the upper bound and generate the truth table
  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".i ") != -1){
        my $the_index = 3;
        $in_simp = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
      }
      elsif (index($the_line, ".p ") != -1){
        my $the_index = 3;
        $prod_simp = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;

        if (!$prod_simp and !$in_simp){
          $in_cnt = 0;
          $false_true = 0;
          print YELLOW, "[INFO] The target function is equal to zero. No need to run the lattice synthesis algorithm! \n", RESET;
          return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
        }
        if ($prod_simp == 1 and !$in_simp){
          $in_cnt = 0;
          $false_true = 1;
          print YELLOW, "[INFO] The target function is equal to one. No need to run the lattice synthesis algorithm! \n", RESET;
          return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
        }
      }
      elsif (index($the_line, ".") == -1){
        my $x_cnt = 0;
        my @x_arr = ();
        my $the_base = 0;
        
        my $lit_num = 0;
        $prod_cnt_simp++;
        my $the_index = -1;
        my $the_char = " ";
            
        do{
          $the_index++;
          $the_char = substr($the_line, $the_index, 1);
          if ($the_char eq "0"){
            $lit_num++;
            $neg_lit = 1;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = "!" . $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = -1;

            $lit_index_arr[2*($the_index+1)]++;
          }
          elsif ($the_char eq "1"){
            $pos_lit = 1;
            $the_base = $the_base + 2**$the_index;
            
            $lit_num++;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 1;
            
            $lit_index_arr[2*($the_index+1)-1]++;
          }
          elsif ($the_char eq "-"){
            $x_cnt++;
            $x_arr[$x_cnt] = $the_index;
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 0;
          }
        }while ($the_char ne " ");

        if (defined $prod_num_simp[$lit_num]){
          $prod_num_simp[$lit_num]++;
        }
        else{
          $prod_num_simp[$lit_num] = 1;
        }

        if ($lit_num > $deg_simp){
          $deg_simp = $lit_num;
        }

        #Find the truth table entries where the function is high
        if ($x_cnt){
          my @val_arr = ();
          my $the_pointer = 0;

          foreach my $i (1 .. $x_cnt){
            $val_arr[$i] = 0;
          }

          do{
            #Display the val_arr
            #foreach my $i (1 .. $x_cnt){
            #  print "$val_arr[$i]";
            #}
            #print "\n";

            $the_pointer = 1;

            my $x_sum = $the_base;
            foreach my $i (1 .. $x_cnt){
              $x_sum = $x_sum + $val_arr[$i] * 2**$x_arr[$i];
            }
            $tt_arr[$x_sum][$in_cnt+1] = 1;

            while ($val_arr[$the_pointer]){
              $val_arr[$the_pointer] = 0;
              $the_pointer++;

              if ($the_pointer > $x_cnt){
                last;
              }
            }

            if ($the_pointer <= $x_cnt){
              $val_arr[$the_pointer] = 1;
            }  
          }while ($the_pointer <= $x_cnt);
        }
        else{
          $tt_arr[$the_base][$in_cnt+1] = 1;
        }
      }
    }

    #Display the truth table
    #foreach my $i (0 .. 2**$in_cnt-1){
    #  foreach my $j (1 .. $in_cnt+1){
    #    print "$tt_arr[$i][$j]";
    #  }
    #  print "\n";
    #}

    close $file_header;
  }
  else{
    $in_cnt = 0;
    print RED, "[ERROR] Could not open the $file_simp file! \n", RESET;
    return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
  }

  #Generate the literal array including the literals to be considered
  foreach my $i (1 .. 2*$in_cnt){
    if ($lit_index_arr[$i]){
      $lit_cnt++;
      if ($i % 2){
        $lit_arr[$lit_cnt] = ($i+1)/2;
      }
      else{
        $lit_arr[$lit_cnt] = (-1)*($i)/2;
      }
    }
  }

  #Find the minimum degree for the lower bound in a recursive fashion
  my $file_prim = $file_main . "_simp_prim.pla";
  my $the_cmd = $path_espresso . " -Dprimes " . $file_simp . " > " . $file_prim;
  system($the_cmd);
  
  while (1) {
    my $max_deg = 0;
    my $min_deg = 9*9*9;

    my @lit_mat = ();
    my $prim_cnt = 0;
    my @prim_arr = ();
    my $maxprim_cnt = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".") == -1){
          my $lit_num = 0;
          my $the_index = -1;
          my $the_char = " ";

          $prim_cnt++;
          $prim_arr[$prim_cnt] = $the_line;

          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0" or $the_char eq "1"){
              $lit_num++;
            }
          }while ($the_char ne " ");

          $lit_mat[$prim_cnt] = $lit_num;

          if ($lit_num > $max_deg){
            $max_deg = $lit_num;
            $maxprim_cnt = 1;
          }
          elsif ($lit_num == $max_deg){
            $maxprim_cnt++;
          }
          
          if ($lit_num < $min_deg){
            $min_deg = $lit_num;
          }
        }
      }
      close $file_header;

      #print "Minimum number of literals: $min_deg \n";
      #print "Maximum number of literals: $max_deg \n";

      if ($min_deg < $max_deg){
        my $file_temp = $file_dir . "temp_file.pla";
        my $file_verify = $file_dir . "verify.out";

        open (my $fid_temp, '>', $file_temp);
        foreach my $i (1 .. $prim_cnt){
          if ($lit_mat[$i] != $max_deg){
            printf $fid_temp "%0s \n", $prim_arr[$i];
          }
        }
        close $fid_temp;

        my $the_cmd = $path_espresso . " -Dverify " . $file_simp . " " . $file_temp . " > " . $file_verify;
        system($the_cmd);

        my $is_verified = 0;
        if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, "compared equal") != -1){
              $is_verified = 1;
              last;
            }
          }

          if (!$is_verified){
            $mindeg_simp = $max_deg;
            last;
          }
          else{
            open (my $fid_prim, '>', $file_prim);
            printf $fid_prim ".i %0d \n", $in_cnt;
            printf $fid_prim ".o %0d \n", $out_cnt;
            printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
            foreach my $i (1 .. $prim_cnt){
              if ($lit_mat[$i] != $max_deg){
                printf $fid_prim "%0s \n", $prim_arr[$i];
              }
            }
            printf $fid_prim ".e \n";
            close $fid_prim;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
        }
      }
      else{
        $mindeg_simp = $max_deg;
        last;
      }
    }
    else{
      $in_cnt = 0;
      print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
      return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
    }
  }

  return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
}

sub find_dual{
  my ($file_dir, $file_main, $the_file, $path_espresso, $in_cnt, $out_cnt, $in_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};

  my $deg_num = 0;
  my $prod_cnt = 0;
  my @prod_lvl = ();
  my @prod_ind = ();
  my @prod_arr = ();
  my $mindeg_num = 0;
  my @prod_num_dual = ();
  
  my $file_dual = $file_main . "_dual.pla";

  #Generating the dual pla file by complementing each variable and the output function
  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_out, '>', $file_temp);
  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $first_prod = 1;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      
      my $the_char = "";
      my $the_index = 0;
     
      if (index($the_line, ".") == -1){
        #Complementing the output function
        if ($first_prod){
          printf $fid_out ".phase 0 \n";
          $first_prod = 0;
        }

        #Complementing the variable
        $the_index = skip_spaces_forward($the_line, $the_index);
        do {
          $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq "1"){
            printf $fid_out "0";
          }
          elsif ($the_char eq "0"){
            printf $fid_out "1";
          }
          elsif ($the_char eq "-" or $the_char eq " "){
            printf $fid_out "%0s", $the_char;
          }
          else{
            print "[WARNING] Only expecting 0 1 or - in this case. Something must be wrong! \n";
          }
          $the_index++;
        }while ($the_char ne " ");

        printf $fid_out "%0s \n", substr($the_line, $the_index, length($the_line)-$the_index+1);
      }
      else{
        printf $fid_out "%s \n", $the_line;
      }
    }

    close $file_header;
    close $fid_out;
    
    #Find the dual function with espresso
    my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_dual;
    system($the_cmd);

    #Compute the degree of the dual function for the upper bound, determine the literals, and generate the truth table.
    if (open (my $file_header, '<:encoding(UTF-8)', $file_dual)){
      my $prod_num = 0;
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".p ") != -1){
          my $the_index = 3;
          $prod_cnt = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
        }
        elsif (index($the_line, ".") == -1){
          my $lit_cnt = 0;
          $prod_num++;
          my $the_index = -1;
          my $the_char = " ";
          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0"){ 
              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = "!" . $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = -1;
            }
            elsif ($the_char eq "1"){
              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = 1;
            }
            elsif ($the_char eq "-") {
              $prod_ind[$the_index+1][$prod_num] = 0;
            }
          }while ($the_char ne " ");

          if (defined $prod_num_dual[$lit_cnt]){
            $prod_num_dual[$lit_cnt]++;
          }
          else{
            $prod_num_dual[$lit_cnt] = 1;
          }

          if ($lit_cnt > $deg_num){
            $deg_num = $lit_cnt;
          }
        }
      }
      close $file_header;

      #Compute the minimum degree for the lower bound in a recursive fashion
      my $file_prim = $file_main . "_dual_prim.pla";
      $the_cmd = $path_espresso . " -Dprimes " . $file_dual . " > " . $file_prim;
      system($the_cmd);
      
      while (1) {
        my $max_deg = 0;
        my $min_deg = 9*9*9;

        my @lit_arr = ();
        my $prim_cnt = 0;
        my @prim_arr = ();
        my $maxprim_cnt = 0;

        if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, ".") == -1){
              my $lit_cnt = 0;
              my $the_index = -1;
              my $the_char = " ";

              $prim_cnt++;
              $prim_arr[$prim_cnt] = $the_line;

              do{
                $the_index++;
                $the_char = substr($the_line, $the_index, 1);
                if ($the_char eq "0" or $the_char eq "1"){
                  $lit_cnt++;
                }
              }while ($the_char ne " ");

              $lit_arr[$prim_cnt] = $lit_cnt;

              if ($lit_cnt > $max_deg){
                $max_deg = $lit_cnt;
                $maxprim_cnt = 1;
              }
              elsif ($lit_cnt == $max_deg){
                $maxprim_cnt++;
              }
              
              if ($lit_cnt < $min_deg){
                $min_deg = $lit_cnt;
              }
            }
          }
          close $file_header;

          #print "Minimum number of literals: $min_deg \n";
          #print "Maximum number of literals: $max_deg \n";

          if ($min_deg < $max_deg){
            my $file_temp = $file_dir . "temp_file.pla";
            open (my $fid_temp, '>', $file_temp);
            foreach my $i (1 .. $prim_cnt){
              if ($lit_arr[$i] != $max_deg){
                printf $fid_temp "%0s \n", $prim_arr[$i];
              }
            }
            close $fid_temp;

            my $file_verify = $file_dir . "verify.out";
            $the_cmd = $path_espresso . " -Dverify " . $file_dual . " " . $file_temp . " > " . $file_verify;
            system($the_cmd);

            my $is_verified = 0;
            if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
              while (my $the_line = <$file_header>){
                chomp $the_line;

                if (index($the_line, "compared equal") != -1){
                  $is_verified = 1;
                  last;
                }
              }

              if (!$is_verified){
                $mindeg_num = $max_deg;
                last;
              }
              else{
                open (my $fid_prim, '>', $file_prim);
                printf $fid_prim ".i %0d \n", $in_cnt;
                printf $fid_prim ".o %0d \n", $out_cnt;
                printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
                foreach my $i (1 .. $prim_cnt){
                  if ($lit_arr[$i] != $max_deg){
                    printf $fid_prim "%0s \n", $prim_arr[$i];
                  }
                }
                printf $fid_prim ".e \n";
                close $fid_prim;
              }
            }
            else{
              print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
            }
          }
          else{
            $mindeg_num = $max_deg;
            last;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
        }
      }
    }
    else{
      print RED, "[ERROR] Could not open the $file_dual file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
  }

  return ($file_dual, $prod_cnt, $deg_num, $mindeg_num, \@prod_num_dual, \@prod_lvl, \@prod_arr, \@prod_ind);
}

sub determine_single_double_products{
  my ($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt, $prod_lvl_ref, $prod_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl = @ {$prod_lvl_ref};
  my @prod_arr = @ {$prod_arr_ref};

  my $non_double = 0;
  my $non_single = 0;
  my @double_lit = ();
  my @single_lit = ();

  my $the_index;
  $double_lit[0] = 0;
  $single_lit[0] = 0;
  foreach my $i (1 .. $prod_cnt){
    if ($prod_lvl[$i] == 1){
      $single_lit[0]++;
      my $the_var = $prod_arr[1][$i];
      if (index($the_var, "!") == -1){
        $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
      }
      else{
        $the_var = substr($the_var, 1, length($the_var)-1);
        $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
        $the_index = (-1) * $the_index;
      }

      $single_lit[$single_lit[0]] = is_inside_numeric_array($the_index, $lit_num, @lit_arr);
    }
    elsif ($prod_lvl[$i] == 2){
      $non_single = 1;

      $double_lit[0]++;
      foreach my $j (1 .. 2){
        my $the_var = $prod_arr[$j][$i];
        if (index($the_var, "!") == -1){
          $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
        }
        else{
          $the_var = substr($the_var, 1, length($the_var)-1);
          $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
          $the_index = (-1)*$the_index;
        }

        $double_lit[2*($double_lit[0]-1)+$j] = is_inside_numeric_array($the_index, $lit_num, @lit_arr);
      }
    }
    else{
      $non_single = 1;
      $non_double = 1;
    }
  }

  return ($non_single, $non_double, \@single_lit, \@double_lit);
}

sub extract_lattice_product_info{
  my ($file_lattice) = @_;

  my $lat_deg = 0;
  my $prod_cnt = 0;
  my @lat_prod_num = ();

  my $init_index = 0;
  my $last_index = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_lattice)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      if (substr($the_line, 0, 1) eq "#"){
        $init_index = index($the_line, "with ");
        if ($init_index != -1){
          $init_index = skip_spaces_forward($the_line, $init_index+4);
          
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= length($the_line)){
              print RED, "[ERROR] There must be something wrong here! \n", RESET;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
          if ($the_var > $lat_deg){
            $lat_deg = $the_var;
          }

          $init_index = index($the_line, ": ");
          if ($init_index != -1){
            $init_index = skip_spaces_forward($the_line, $init_index+1);

            my $the_num = substr($the_line, $init_index, length($the_line)-$init_index) + 0.0;
            $lat_prod_num[$the_var] = $the_num;
            $prod_cnt += $the_num;
          }
        }
      }
    }
  }
  else{
    print RED, "[ERROR] Could not open the $file_lattice file! \n", RESET;
  }
  
  return ($prod_cnt, $lat_deg, \@lat_prod_num);
}

sub is_function_synthesizable{
  my ($prod_cnt, $fun_deg, $prod_num_ref, $lat_prod_cnt, $lat_deg, $lat_prod_num_ref) = @_;
  my @prod_num = @ {$prod_num_ref};
  my @lat_prod_num = @ {$lat_prod_num_ref};

  my $the_value = 1;

  foreach my $i (1 .. $fun_deg){
    if (defined $prod_num[$i]){
      my $the_point = $i;
      my $the_sum = $prod_num[$i];
      
      while (1){
        if (defined $lat_prod_num[$the_point]){
          if ($lat_prod_num[$the_point] >= $the_sum){
            $lat_prod_num[$the_point] = $lat_prod_num[$the_point] - $the_sum;
            $the_sum = 0;
          }
          else{
            $the_sum = $the_sum - $lat_prod_num[$the_point];
            $lat_prod_num[$the_point] = 0;
          }
        }

        $the_point++;
        if ($the_point > $lat_deg or !$the_sum){
          last;
        }
      }
      
      if ($the_sum){
        $the_value = 0;
        last;
      }
    }
  }

  return ($the_value);
}

sub determine_lower_bound{
  my ($prod_simp, $prod_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref) = @_;

  my $lb_col = 1;
  if ($prod_simp > 1){
    $lb_col = 2;
  }
  if ($mindeg_dual > 2){
    $lb_col = 3;
  }

  my $lb_row = 3;
  if ($mindeg_simp == 2){
    $lb_row = 2;
  }
  elsif ($mindeg_simp == 1){
    $lb_row = 1;
  }

  my $the_lb = 1;
  my $the_end = 0;
  while (1){
    $the_lb++;

    for (my $the_row = 1; $the_row <= $the_lb; $the_row++){
      if (!($the_lb % $the_row)){
        my $the_col = $the_lb/$the_row;

        if ($the_row >= $lb_row and $the_col >= $lb_col){
          my $lat_str = $the_row . "x" . $the_col;
          my $file_lattice = "l" . $lat_str . ".eqn";
          if (!(-e $file_lattice)){
            my $the_cmd = "perl genlatfunc_rec.pl -r=" . $the_row . "  -c=" . $the_col;
            if ($the_verb < 1){print "[INFO] The $lat_str lattice equation (4-terminal) cannot be found! Generating...\n";}
            system($the_cmd);
          }
          my ($lat_prod_simp, $lat_deg_simp, $lat_prod_num_simp_ref) = extract_lattice_product_info($file_lattice);
          
          my $file_dual = "d" . $lat_str . ".eqn";
          if (!(-e $file_dual)){
            my $the_cmd = "perl genlatfunc_dual_rec.pl -r=" . $the_row . "  -c=" . $the_col;
            if ($the_verb < 1){print "[INFO] The dual of $lat_str lattice equation (8-terminal) cannot be found! Generating...\n";}
            system($the_cmd);
          }
          my ($lat_prod_dual, $lat_deg_dual, $lat_prod_num_dual_ref) = extract_lattice_product_info($file_dual);
         
          #print "[INFO] Checking the lower bound for the $lat_str lattice... \n";
          if (is_function_synthesizable($prod_simp, $deg_simp, $prod_num_simp_ref, $lat_prod_simp, $lat_deg_simp, $lat_prod_num_simp_ref)){
            if (is_function_synthesizable($prod_dual, $deg_dual, $prod_num_dual_ref, $lat_prod_dual, $lat_deg_dual, $lat_prod_num_dual_ref)){
              $the_end = 1;
              last;
            }
          }
        }
      }
    }

    if ($the_end){
      last;
    }
  }

  return ($the_lb);
}

sub read_match_pla{
  my ($file_dir, $the_first, $in_arr_ref, $prod_ind_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  my $the_index;
  my $imp_cnt = 0;
  my $match_cnt = 0;
  my @match_arr = ();

  my $file_temp_dual = $file_dir . "temp_dual_file.pla";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_temp_dual)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".p ") != -1){
        $imp_cnt = substr($the_line, 3, length($the_line)-3) + 0.0;
      }
      elsif (index($the_line, ".") == -1){
        $match_cnt++;
        $the_index = -1;

        my $the_cnt = 0;
        my @the_ind = ();
        my @the_arr = ();
        while (1){
          $the_index++;
          my $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq " "){
            last;
          }
          elsif($the_char eq "0"){
            $the_cnt++;
            $the_arr[$the_cnt] = "!" . $in_arr[$the_index+1];
            $the_ind[$the_cnt] = (-1)*($the_index+1);
          }
          elsif($the_char eq "1"){
            $the_cnt++;
            $the_arr[$the_cnt] = $in_arr[$the_index+1];
            $the_ind[$the_cnt] = $the_index+1;
          }

          if ($the_cnt == 1){
            $match_arr[$match_cnt][1] = $the_arr[1];
            $match_arr[$match_cnt][2] = $the_arr[1];
          }
          elsif ($the_cnt == 2){
            if ($prod_ind[abs($the_ind[1])][$the_first] == -1 and $the_ind[1] < 0){
              $match_arr[$match_cnt][1] = $the_arr[1];
              $match_arr[$match_cnt][2] = $the_arr[2];
            }
            elsif ($prod_ind[abs($the_ind[1])][$the_first] == 1 and $the_ind[1] > 0){
              $match_arr[$match_cnt][1] = $the_arr[1];
              $match_arr[$match_cnt][2] = $the_arr[2];
            }
            elsif ($prod_ind[abs($the_ind[2])][$the_first] == -1 and $the_ind[2] < 0){
              $match_arr[$match_cnt][1] = $the_arr[2];
              $match_arr[$match_cnt][2] = $the_arr[1];
            }
            elsif ($prod_ind[abs($the_ind[2])][$the_first] == 1 and $the_ind[2] > 0){
              $match_arr[$match_cnt][1] = $the_arr[2];
              $match_arr[$match_cnt][2] = $the_arr[1];
            }
          }
          elsif ($the_cnt > 2){
            print "[WARNING] The number of terms should not be greater than two! \n";
          }
        }
      }
    }
    close $file_header;
  }
  else{
    print RED "[ERROR] Could not open the $file_temp_dual file! \n", RESET;
  }

  return ($imp_cnt, $match_cnt, @match_arr);
}

sub write_match_pla{
  my ($file_dir, $in_num, $out_num, $the_first, $the_second, @prod_ind) = @_;

  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_pla, '>', $file_temp);
  
  printf $fid_pla ".i %0d \n", $in_num;
  printf $fid_pla ".o %0d \n", $out_num;
  printf $fid_pla ".phase 0 \n";
  printf $fid_pla ".p 2 \n";
  foreach my $k (1 .. $in_num){
    if ($prod_ind[$k][$the_first] == 1){
      printf $fid_pla "0";
    }
    elsif ($prod_ind[$k][$the_first] == -1){
      printf $fid_pla "1";
    }
    else{
      printf $fid_pla "-";
    }
  }
  printf $fid_pla " 1 \n";
  
  foreach my $k (1 .. $in_num){
    if ($prod_ind[$k][$the_second] == 1){
      printf $fid_pla "0";
    }
    elsif ($prod_ind[$k][$the_second] == -1){
      printf $fid_pla "1";
    }
    else{
      printf $fid_pla "-";
    }
  }
  printf $fid_pla " 1 \n";
  printf $fid_pla ".e \n";
  
  close $fid_pla;
}

sub find_forth_upper_bound{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_simp, $deg_simp, $in_arr_ref, $lit_arr_ref, $single_lit_simp_ref, $double_lit_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
  my @prod_arr_simp = @ {$prod_arr_simp_ref};
  my @prod_ind_simp = @ {$prod_ind_simp_ref};
  my @double_lit_simp = @ {$double_lit_simp_ref};
  my @single_lit_simp = @ {$single_lit_simp_ref};

  my $ub_four = 0;
  my $col_num = 0;
  my @imp_arr = ();
  my @sol_four = ();
  my $single_pointer = 0;

  #Initialize the implementation array
  foreach my $i (1 .. $prod_simp){
    if ($prod_lvl_simp[$i] == 1){
      $imp_arr[$i] = 1;
    }
    elsif ($double_lit_simp[0] > 1 and $prod_lvl_simp[$i] == 2){
      $imp_arr[$i] = 1;
    }
    else{
      $imp_arr[$i] = 0;
    }
  }

  my $the_end = 0;
  #First, place the products with two terms if there are more than one
  if ($double_lit_simp[0] > 1){
    foreach my $h (1 .. $double_lit_simp[0]){
      $ub_four += $deg_simp;

      my $first_var = "";
      if ($lit_arr[$double_lit_simp[2*$h-1]] < 0){
        $first_var = "!";
      }
      $first_var = $first_var . $in_arr[abs($lit_arr[$double_lit_simp[2*$h-1]])];
      
      my $second_var = "";
      if ($lit_arr[$double_lit_simp[2*$h]] < 0){
        $second_var = "!";
      }
      $second_var = $second_var . $in_arr[abs($lit_arr[$double_lit_simp[2*$h]])];
      
      $col_num++;
      foreach my $i (1 .. $deg_simp-1){
        $sol_four[$i][$col_num] = $first_var;
      }
      $sol_four[$deg_simp][$col_num] = $second_var;
    }

    $the_end = 1;
    foreach my $h (1 .. $prod_simp){
      if (!$imp_arr[$h]){
        $the_end = 0;
        last;
      }
    }

    if (!$the_end){
      #Adding a single term if there is any or just a false-column
      $col_num++;
      $ub_four += $deg_simp;
      if ($double_lit_simp[0] and $single_lit_simp[0]){
        $single_pointer++;
        
        my $the_var = "";
        if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
          $the_var = "!";
        }
        $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
        
        foreach my $i (1 .. $deg_simp){
          $sol_four[$i][$col_num] = $the_var;
        }
      }
      else{
        foreach my $i (1 .. $deg_simp){
          $sol_four[$i][$col_num] = "F";
        }
      }
    }
  }

  #Second, one by one add a prime implicant with a match if there is any
  if (!$the_end){
    foreach my $i (1 .. $prod_simp){
      if (!$imp_arr[$i]){
        my $imp_cnt;
        my $match_cnt;
        my @match_arr;
        my $match_found = 0;

        #Finding the match
        for (my $j = $i+1; $j <= $prod_simp; $j++){
          if (!$imp_arr[$j]){
            #Check if these prime implicants share at least oone common literal
            my $is_rel = 0;
            foreach my $k (1 .. $in_num){
              if ($prod_ind_simp[$k][$i] and $prod_ind_simp[$k][$j]){
                $is_rel = 1;
                last;
              }
            }

            if ($is_rel){
              write_match_pla($file_dir, $in_num, $out_num, $i, $j, @prod_ind_simp);
              my $file_temp = $file_dir . "temp_file.pla";
              my $file_temp_dual = $file_dir . "temp_dual_file.pla";
              my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_temp_dual;
              system ($the_cmd);
              ($imp_cnt, $match_cnt, @match_arr) = read_match_pla($file_dir, $i, \@in_arr, \@prod_ind_simp);

              if ($imp_cnt <= $deg_simp){
                $match_found = $j;
                last;
              }
            }
          }
        }

        if ($match_found){
          $col_num += 2;
          $imp_arr[$i] = 1;
          $imp_arr[$match_found] = 1;
          $ub_four += 2*$deg_simp;

          foreach my $j (1 .. $match_cnt){
            $sol_four[$j][$col_num-1] = $match_arr[$j][1];
            $sol_four[$j][$col_num] = $match_arr[$j][2];
          }
          for (my $j = $match_cnt+1; $j <= $deg_simp; $j++){
            $sol_four[$j][$col_num-1] = "T";
            $sol_four[$j][$col_num] = "T";
          }
        }
        else{
          $imp_arr[$i] = 1;
          $ub_four += $deg_simp;

          $col_num++;
          foreach my $j (1 .. $prod_lvl_simp[$i]){
            $sol_four[$j][$col_num] = $prod_arr_simp[$j][$i];
          }
          for (my $j = $prod_lvl_simp[$i]+1; $j <= $deg_simp; $j++){
            $sol_four[$j][$col_num] = "T";
          }
        }

        $the_end = 1;
        for (my $j = $i+1; $j <= $prod_simp; $j++){
          if (!$imp_arr[$j]){
            $the_end = 0;
            last;
          }
        }

        #Add a single-term prime implicant or a false-column if there is at least one prime implicant not considered, otherwise return
        if ($the_end){
          last;
        }
        else{
          $col_num++;
          $ub_four += $deg_simp;

          if ($single_pointer < $single_lit_simp[0]){
            $single_pointer++;
            
            my $the_var = "";
            if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
              $the_var = "!";
            }
            $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
            
            foreach my $j (1 .. $deg_simp){
              $sol_four[$j][$col_num] = $the_var;
            }
          }
          else{
            foreach my $j (1 .. $deg_simp){
              $sol_four[$j][$col_num] = "F";
            }
          }
        }
      }
    }
  }

  #Adding the single term prime implicant if there is any left
  while ($single_pointer < $single_lit_simp[0]){
    $col_num++;
    $single_pointer++;
    $ub_four += $deg_simp;
    
    my $the_var = "";
    if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
      $the_var = "!";
    }
    $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
    
    foreach my $i (1 .. $deg_simp){
      $sol_four[$i][$col_num] = $the_var;
    }
  }

  #print "The solution on the forth criteria: \n";
  #foreach my $i (1 .. $deg_simp){
  #  print "| ";
  #  foreach my $j (1 .. $col_num){
  #    if (index($sol_four[$i][$j], "!") != -1){
  #      print "$sol_four[$i][$j] | ";
  #    }
  #    else{
  #      print "$sol_four[$i][$j]  | ";
  #    }
  #  }
  #  print "\n";
  #}

  return ($ub_four, @sol_four);
}

sub find_fifth_upper_bound{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_dual, $deg_dual, $in_arr_ref, $lit_arr_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl_dual = @ {$prod_lvl_dual_ref};
  my @prod_arr_dual = @ {$prod_arr_dual_ref};
  my @prod_ind_dual = @ {$prod_ind_dual_ref};
  my @single_lit_dual = @ {$single_lit_dual_ref};

  my $ub_five = 0;
  my $row_num = 0;
  my @imp_arr = ();
  my @sol_five = ();
  my $single_pointer = 0;

  #Initialize the implementation array
  my $the_end = 1;
  foreach my $i (1 .. $prod_dual){
    if ($prod_lvl_dual[$i] == 1){
      $imp_arr[$i] = 1;
    }
    else{
      $the_end = 0;
      $imp_arr[$i] = 0;
    }
  }

  #One by one add a prime implicant with a match if there is any
  if (!$the_end){
    foreach my $i (1 .. $prod_dual){
      if (!$imp_arr[$i]){
        my $imp_cnt;
        my $match_cnt;
        my @match_arr;
        my $match_found = 0;

        #Finding the match
        for (my $j = $i+1; $j <= $prod_dual; $j++){
          if (!$imp_arr[$j]){
            #Check if these prime implicants share at least oone common literal
            my $is_rel = 0;
            foreach my $k (1 .. $in_num){
              if ($prod_ind_dual[$k][$i] and $prod_ind_dual[$k][$j]){
                $is_rel = 1;
                last;
              }
            }

            if ($is_rel){
              write_match_pla($file_dir, $in_num, $out_num, $i, $j, @prod_ind_dual);
              my $file_temp = $file_dir . "temp_file.pla";
              my $file_temp_dual = $file_dir . "temp_dual_file.pla";
              my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_temp_dual;
              system ($the_cmd);
              ($imp_cnt, $match_cnt, @match_arr) = read_match_pla($file_dir, $i, \@in_arr, \@prod_ind_dual);

              if ($imp_cnt <= $deg_dual){
                $match_found = $j;
                last;
              }
            }
          }
        }

        if ($match_found){
          $row_num += 2;
          $imp_arr[$i] = 1;
          $imp_arr[$match_found] = 1;
          $ub_five += 2*$deg_dual;

          foreach my $j (1 .. $match_cnt){
            $sol_five[$row_num-1][$j] = $match_arr[$j][1];
            $sol_five[$row_num][$j] = $match_arr[$j][2];
          }
          for (my $j = $match_cnt+1; $j <= $deg_dual; $j++){
            $sol_five[$row_num-1][$j] = "F";
            $sol_five[$row_num][$j] = "F";
          }
        }
        else{
          $imp_arr[$i] = 1;
          $ub_five += $deg_dual;

          $row_num++;
          foreach my $j (1 .. $prod_lvl_dual[$i]){
            $sol_five[$row_num][$j] = $prod_arr_dual[$j][$i];
          }
          for (my $j = $prod_lvl_dual[$i]+1; $j <= $deg_dual; $j++){
            $sol_five[$row_num][$j] = "F";
          }
        }

        $the_end = 1;
        for (my $j = $i+1; $j <= $prod_dual; $j++){
          if (!$imp_arr[$j]){
            $the_end = 0;
            last;
          }
        }

        #Add a single-term prime implicant or a false-row if there is at least one prime implicant not considered, otherwise return
        if ($the_end){
          last;
        }
        else{
          $row_num++;
          $ub_five += $deg_dual;

          if ($single_pointer < $single_lit_dual[0]){
            $single_pointer++;
            
            my $the_var = "";
            if ($lit_arr[$single_lit_dual[$single_pointer]] < 0){
              $the_var = "!";
            }
            $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_dual[$single_pointer]])];
            
            foreach my $j (1 .. $deg_dual){
              $sol_five[$row_num][$j] = $the_var;
            }
          }
          else{
            foreach my $j (1 .. $deg_dual){
              $sol_five[$row_num][$j] = "T";
            }
          }
        }
      }
    }
  }

  #Adding the single term prime implicant if there is any left
  while ($single_pointer < $single_lit_dual[0]){
    $row_num++;
    $single_pointer++;
    $ub_five += $deg_dual;
    
    my $the_var = "";
    if ($lit_arr[$single_lit_dual[$single_pointer]] < 0){
      $the_var = "!";
    }
    $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_dual[$single_pointer]])];
    
    foreach my $i (1 .. $deg_dual){
      $sol_five[$row_num][$i] = $the_var;
    }
  }

  #print "The solution on the fifth criteria: \n";
  #foreach my $i (1 .. $row_num){
  #  print "| ";
  #  foreach my $j (1 .. $deg_dual){
  #    if (index($sol_five[$i][$j], "!") != -1){
  #      print "$sol_five[$i][$j] | ";
  #    }
  #    else{
  #      print "$sol_five[$i][$j]  | ";
  #    }
  #  }
  #  print "\n";
  #}

  return ($ub_five, @sol_five);
}

sub determine_ub{
  my ($file_dir, $path_espresso, $file_simp, $in_num, $out_num, $prod_simp, $prod_dual, $deg_simp, $deg_dual, $in_arr_ref, $lit_arr_ref, $non_double_simp, $non_single_dual, $single_lit_simp_ref, $double_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = @_;
  my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
  my @prod_arr_simp = @ {$prod_arr_simp_ref};
  my @prod_lvl_dual = @ {$prod_lvl_dual_ref};
  my @prod_arr_dual = @ {$prod_arr_dual_ref};

  my $the_ub = 0;
  my $the_row = 0;
  my $the_col = 0;
  my @the_sol = ();
  my $ub_index = 0;

  my $ub_one = $prod_simp * $prod_dual;
  #print "[INFO] #rows: $prod_simp #columns: $prod_dual \n";
  #print "[INFO] The first upper bound: $ub_one \n";
  
  my $ub_two = $deg_simp * (2*$prod_simp-1);
  $the_col = 2*$prod_simp-1;
  #print "[INFO] #rows: $deg_simp #columns: $the_col \n";
  #print "[INFO] The second upper bound: $ub_two \n";

  my $ub_three = $deg_dual * (2*$prod_dual-1);
  $the_row = 2*$prod_dual-1;
  #print "[INFO] #rows: $the_row #columns: $deg_dual \n";
  #print "[INFO] The third upper bound: $ub_three \n";

  my ($ub_four, @sol_four) = find_forth_upper_bound($file_dir, $path_espresso, $in_num, $out_num, $prod_simp, $deg_simp, $in_arr_ref, $lit_arr_ref, $single_lit_simp_ref, $double_lit_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref);
  my ($ub_five, @sol_five) = find_fifth_upper_bound($file_dir, $path_espresso, $in_num, $out_num, $prod_dual, $deg_dual, $in_arr_ref, $lit_arr_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref);

  if ($ub_one <= $ub_two and $ub_one <= $ub_three and $ub_one <= $ub_four and $ub_one <= $ub_five){
    $ub_index = 1;
    $the_ub = $ub_one;

    $the_row = $prod_dual;
    $the_col = $prod_simp;

    foreach my $i (1 .. $the_row){
      foreach my $j (1 .. $the_col){
        my $var_found = 0;
        foreach my $m (1 .. $prod_lvl_dual[$i]){
          foreach my $k (1 .. $prod_lvl_simp[$j]){
            if ($prod_arr_simp[$k][$j] eq $prod_arr_dual[$m][$i]){
              $var_found = 1;
              $the_sol[$i][$j] = $prod_arr_simp[$k][$j];
              last;
            }
          }
          if ($var_found){
            last;
          }
        }

        if (!$var_found){
          print RED, "[ERROR] A literal in a normal product must match one literal in a dual product! \n", RESET;
        }
      }
    }

    #print "The first solution: \n";
    #foreach my $i (1 .. $the_row){
    #  print "| ";
    #  foreach my $j (1 .. $the_col){
    #    if (index($the_sol[$i][$j], "!") != -1){
    #      print "$the_sol[$i][$j] | ";
    #    }
    #    else{
    #      print "$the_sol[$i][$j]  | ";
    #    }
    #  }
    #  print "\n";
    #}
  }
  elsif ($ub_two <= $ub_one and $ub_two <= $ub_three and $ub_two <= $ub_four and $ub_two <= $ub_five){
    $ub_index = 2;
    $the_ub = $ub_two;

    $the_row = $deg_simp;
    $the_col = $the_ub/$the_row;

    #Writing the products and ones except the last product
    my $prod_cnt_simp = 0;
    foreach my $i (1 .. $the_col-1){
      if ($i % 2){
        $prod_cnt_simp++;
        foreach my $j (1 .. $prod_lvl_simp[$prod_cnt_simp]){
          $the_sol[$j][$i] = $prod_arr_simp[$j][$prod_cnt_simp];
        }
        for (my $j = $prod_lvl_simp[$prod_cnt_simp]+1; $j <= $the_row; $j++){
          $the_sol[$j][$i] = "T";
        }
      }
      else{
        foreach my $j (1 .. $the_row){
          $the_sol[$j][$i] = "F";
        }
      }
    }

    #Writing the last product
    foreach my $j (1 .. $prod_lvl_simp[$prod_simp]){
      $the_sol[$j][$the_col] = $prod_arr_simp[$j][$prod_simp];
    }
    for (my $j = $prod_lvl_simp[$prod_simp]+1; $j <= $the_row; $j++){
      $the_sol[$j][$the_row] = "T";
    }

    #print "The second solution: \n";
    #foreach my $i (1 .. $the_row){
    #  print "| ";
    #  foreach my $j (1 .. $the_col){
    #    if (index($the_sol[$i][$j], "!") != -1){
    #      print "$the_sol[$i][$j] | ";
    #    }
    #    else{
    #      print "$the_sol[$i][$j]  | ";
    #    }
    #  }
    #  print "\n";
    #}
  }
  elsif ($ub_three <= $ub_one and $ub_three <= $ub_two and $ub_three <= $ub_four and $ub_three <= $ub_five){
    $ub_index = 3;
    $the_ub = $ub_three;

    $the_col = $deg_dual;
    $the_row = $the_ub/$the_col;

    #Writing the products and ones except the last product
    my $prod_cnt_dual = 0;
    foreach my $i (1 .. $the_row-1){
      if ($i % 2){
        $prod_cnt_dual++;
        foreach my $j (1 .. $prod_lvl_dual[$prod_cnt_dual]){
          $the_sol[$i][$j] = $prod_arr_dual[$j][$prod_cnt_dual];
        }
        for (my $j = $prod_lvl_dual[$prod_cnt_dual]+1; $j <= $the_col; $j++){
          $the_sol[$i][$j] = "T";
        }
      }
      else{
        foreach my $j (1 .. $the_col){
          $the_sol[$i][$j] = "T";
        }
      }
    }

    #Writing the last product
    foreach my $j (1 .. $prod_lvl_dual[$prod_dual]){
      $the_sol[$the_row][$j] = $prod_arr_dual[$j][$prod_dual];
    }
    for (my $j = $prod_lvl_dual[$prod_dual]+1; $j <= $the_col; $j++){
      $the_sol[$the_row][$j] = "T";
    }
    
    #print "The third solution: \n";
    #foreach my $i (1 .. $the_row){
    #  print "| ";
    #  foreach my $j (1 .. $the_col){
    #    if (index($the_sol[$i][$j], "!") != -1){
    #      print "$the_sol[$i][$j] | ";
    #    }
    #    else{
    #      print "$the_sol[$i][$j]  | ";
    #    }
    #  }
    #  print "\n";
    #}
  }
  elsif ($ub_four <= $ub_one and $ub_four <= $ub_two and $ub_four <= $ub_three and $ub_four <= $ub_five){
    $ub_index = 4;
    $the_ub = $ub_four;
    $the_row = $deg_simp;
    $the_col = $the_ub/$deg_simp;
    @the_sol = @sol_four;
  }
  elsif ($ub_five <= $ub_one and $ub_five <= $ub_two and $ub_five <= $ub_three and $ub_five <= $ub_four){
    $ub_index = 5;
    $the_ub = $ub_five;
    $the_row = $the_ub/$deg_dual;
    $the_col = $deg_dual;
    @the_sol = @sol_five;
  }

  return ($the_ub, $ub_index, $the_row, $the_col, @the_sol);
}

sub extract_paths{
  my ($paths_file) = @_;

  my $path_espresso = " ";
  my $path_ilp = " ";
  my $path_sat = " ";
  my $paths_ok = 1;

  if (-e $paths_file){
    my $the_index = 0;
    my $init_index = 0;
    my $last_index = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $paths_file)){
      while (my $the_line = <$file_header>){
        chomp $the_line;
        #print "$the_line \n";

        $the_index = index ($the_line, "=");

        if ($the_index >= 0){
          $init_index = skip_spaces_forward($the_line, 0);
          $last_index = skip_spaces_backward($the_line, $the_index-1);
          my $the_solver = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_solver: $the_solver \n";

          $init_index = skip_spaces_forward($the_line, $the_index+1);
          $last_index = skip_spaces_backward($the_line, length($the_line));
          my $the_path = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_path: $the_path \n";

          if ($the_path =~ /[0-9a-zA-Z_]/ ){
            if ($the_solver eq "espresso"){
              $path_espresso = $the_path;
            }
            elsif ($the_solver eq "ilp"){
              $path_ilp = $the_path;
            }
            elsif ($the_solver eq "sat"){
              $path_sat = $the_path;
            }
          }
          else{
            $paths_ok = 0;
          }
        }
      }

      if ($path_espresso eq " ") {
        $paths_ok = 0;
        print RED, "[ERROR] The path to the espresso could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_espresso: $path_espresso \n";
      #}
      if ($path_ilp eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the ILP solver could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_ilp: $path_ilp \n";
      #}
      if ($path_sat eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the SAT solver could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_sat: $path_sat \n";
      #}

      close ($file_header);
    }
    else{
      print RED, "[ERROR] Could not open the $paths_file file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not find the file including paths to solvers! \n", RESET;
  }

  return ($paths_ok, $path_espresso, $path_ilp, $path_sat);
}

sub file_write_pla_nosingle{
  my ($file_main, $prod_cnt, $in_num, $in_arr_ref, $prod_lvl_ref, $prod_arr_ref, $prod_ind_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @prod_lvl = @ {$prod_lvl_ref};
  my @prod_arr = @ {$prod_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  my $prod_cnt_nos = 0;

  my $file_pla = $file_main . ".pla";
  open(my $fid_pla, '>', $file_pla);
  printf $fid_pla ".i %0d \n", $in_num;
  printf $fid_pla ".o 1 \n";
  printf $fid_pla ".ilb ";
  foreach my $i (1 .. $in_num){
    printf $fid_pla "%0s ", $in_arr[$i];
  }
  printf $fid_pla "\n";
  printf $fid_pla ".ob f \n";
  foreach my $i (1 .. $prod_cnt){
    if ($prod_lvl[$i] > 1){
      $prod_cnt_nos++;

      foreach my $j (1 .. $in_num){
        if ($prod_ind[$j][$i] == 1){
          printf $fid_pla "1";
        }
        elsif ($prod_ind[$j][$i] == -1){
          printf $fid_pla "0";
        }
        else{
          printf $fid_pla "-";
        }
      }
      printf $fid_pla " 1 \n";
    }
  }
  print $fid_pla ".e \n";
  close ($fid_pla);

  return ($prod_cnt_nos);
}

sub file_write_pla{
  my ($file_part, $prod_cnt, $in_num, $in_arr_ref, $prod_ind_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  open (my $fid_part, '>', $file_part);
  printf $fid_part ".i %0d \n", $in_num;
  printf $fid_part ".o 1 \n";
  printf $fid_part ".ilb ";
  foreach my $i (1 .. $in_num){
    printf $fid_part "%0s ", $in_arr[$i];
  }
  printf $fid_part "\n";
  printf $fid_part ".ob f \n";
  printf $fid_part ".p %0d \n", $prod_cnt;
  foreach my $i (1 .. $prod_cnt){
    foreach my $j (1 .. $in_num){
      if ($prod_ind[$j][$i] == 0){
        printf $fid_part "-";
      }
      elsif ($prod_ind[$j][$i] == 1){
        printf $fid_part "1";
      }
      elsif ($prod_ind[$j][$i] == -1){
        printf $fid_part "0";
      }
    }
    printf $fid_part " 1 \n";
  }
  printf $fid_part ".e \n";
  close $fid_part;
}

sub file_write_partition_pla{
  my ($file_main, $part_cnt, $in_num, $prod_num, $first_cnt, $part_arr_ref, $in_arr_ref, $prod_ind_ref, $prod_first_list_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @part_arr = @ {$part_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};
  my @prod_first_list = @ {$prod_first_list_ref};

  foreach my $the_part (1 .. $part_cnt){
    my $file_part = $file_main . "_part" . $part_arr[$the_part] . ".pla";

    open (my $fid_part, '>', $file_part);
    printf $fid_part ".i %0d \n", $in_num;
    printf $fid_part ".o 1 \n";
    printf $fid_part ".ilb ";
    foreach my $i (1 .. $in_num){
      printf $fid_part "%0s ", $in_arr[$i];
    }
    printf $fid_part "\n";
    printf $fid_part ".ob f \n";
    if ($the_part == 1){
      printf $fid_part ".p %0d \n", $first_cnt;
    }
    else{
      printf $fid_part ".p %0d \n", $prod_num - $first_cnt;
    }
    foreach my $i (1 .. $prod_num){
      if (($the_part == 1 and $prod_first_list[$i]) or ($the_part == 2 and !$prod_first_list[$i])){
        foreach my $j (1 .. $in_num){
          if ($prod_ind[$j][$i] == 0){
            printf $fid_part "-";
          }
          elsif ($prod_ind[$j][$i] == 1){
            printf $fid_part "1";
          }
          elsif ($prod_ind[$j][$i] == -1){
            printf $fid_part "0";
          }
        }
        printf $fid_part " 1 \n";
      }
    }
    printf $fid_part ".e \n";
    close $fid_part;
  }
}

sub file_read_ilp_solution{
  my ($file_dir, $prod_num, $first_prodvar) = @_;
  
  my $the_index = 0;
  my $first_cnt = 0;
  my $init_index = 0;
  my $last_index = 0;
  my @prod_first_list = ();

  foreach my $i (1 .. $prod_num){
    $prod_first_list[$i] = 0;
  }

  my $sol_found = 0;
  my $file_sol = $file_dir . "ilp_problem.sol";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (my $the_line = <$file_header>){
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      if (index($the_line, "objective value: ") != -1){
        while (1){
          my $the_line = <$file_header>;
          chomp $the_line;

          my $var_index = index($the_line, "x");

          if ($var_index != -1){
            $sol_found = 1;
            $init_index = skip_spaces_forward($the_line, $var_index+1);
            $last_index = $init_index;
            while (substr($the_line, $last_index, 1) ne " "){
              $last_index++;
            }

            my $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;

            if ($the_var >= $first_prodvar){
              if (($the_var - $first_prodvar) % 2 == 0){
                $first_cnt++;
                $the_index = ($the_var - $first_prodvar) / 2 + 1;
                $prod_first_list[$the_index] = 1;
              }
            }
          }
          else{
            last;
          }
        }
      }
      if ($sol_found){
        last;
      }
    }
    close ($file_header);
  }
  else{
    print RED "[ERROR] Could not open the $file_sol file! \n", RESET;
  }

  return ($first_cnt, @prod_first_list);
}

sub solve_separation_problem_ilp{
  my ($file_dir, $file_main, $path_ilp, $prod_num, $in_num, $out_num, $in_arr_ref, $prod_ind_ref, $part_cnt, $part_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @part_arr = @ {$part_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  my $first_cnt = 0;
  my @prod_first_list = ();

  if ($prod_num > 1){
    my $con_cnt = 0;
    my $var_cnt = 0;
    my $optvar_cnt = 0;
    my $min_func = "min: ";
    
    my $file_opb = $file_dir . "ilp_problem.opb";
    my $file_var = $file_dir . "ilp_problem.var";
    open (my $fid_opb, '>', $file_opb);
    open (my $fid_var, '>', $file_var);

    #Generating the objective function and optimization variables
    my $first_optvar = 1;
    foreach my $in_var (1 .. $in_num){
      foreach my $the_stat (0 .. 1){
        foreach my $the_part (1 .. 2){
          $var_cnt++;
          $optvar_cnt++;
          $min_func = $min_func . "+1 x" . $var_cnt . " ";
          printf $fid_var "%0d = in%0d_stat%0d_part%0d \n", $var_cnt, $in_var, $the_stat, $the_part;
        }
      }
    }

    printf $fid_opb "%0s; \n", $min_func;
    
    #Generating the product related variables
    my $first_prodvar = $var_cnt+1;
    foreach my $prod_var (1 .. $prod_num){
      foreach my $the_part (1 .. 2){
        $var_cnt++;
        printf $fid_var "%0d = prod%0d_part%0d \n", $var_cnt, $prod_var, $the_part;
      }
    }

    #Generating the constraints indicating that each product must be in partition 1 or 2
    foreach my $prod_var (1 .. $prod_num){
      my $pos_cnf = "";
      my $neg_cnf = "";

      foreach my $the_part (1 .. 2){
        my $the_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;
        $pos_cnf = $pos_cnf . "+1 x" . $the_index . " ";
        $neg_cnf = $neg_cnf . "-1 x" . $the_index . " ";
      }

      $con_cnt++;
      $con_cnt++;
      printf $fid_opb "%0s>= 1; \n", $pos_cnf;
      printf $fid_opb "%0s>= -1; \n", $neg_cnf;
    }

    #Generating the constraints indicating that in partition 1 and 2 there must be at least prod_cnt_limit products
    my $prod_cnt_limit = int ($prod_num / 2);
    #my $prod_cnt_limit = int ($prod_num / 2) - 1;
    foreach my $the_part (1 ..2){
      my $the_cnf = "";
      foreach my $prod_var (1 .. $prod_num){
        my $the_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;
        $the_cnf = $the_cnf . "+1 x" . $the_index . " ";
      }
      
      $con_cnt++;
      printf $fid_opb "%0s>= %0d; \n", $the_cnf, $prod_cnt_limit;
    }

    #Generating the constraints indicating that when a product is selected for a partition its variables are also selected for that partition
    foreach my $the_part (1 .. 2){
      foreach my $prod_var (1 .. $prod_num){
        foreach my $in_var (1 .. $in_num){
          if ($prod_ind[$in_var][$prod_var] == -1){
            my $in_index = $first_optvar + 4*($in_var-1) + $the_part - 1;
            my $prod_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;

            $con_cnt++;
            printf $fid_opb "-1 x%0d +1 x%0d >= 0; \n", $prod_index, $in_index;
          }
          elsif ($prod_ind[$in_var][$prod_var] == 1){
            my $in_index = $first_optvar + 4*($in_var-1) + $the_part + 1;
            my $prod_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;

            $con_cnt++;
            printf $fid_opb "-1 x%0d +1 x%0d >= 0; \n", $prod_index, $in_index;
          }
        }
      }
    }

    close ($fid_opb);
    close ($fid_var);

    #print "[INFO] #variables: $var_cnt #constraints: $con_cnt #optimization variables: $optvar_cnt \n";

    #my $path_ilp = extract_ilpsolver_path();
    my $file_sol = $file_dir . "ilp_problem.sol";
    my $the_cmd = $path_ilp . " -f " . $file_opb . " > " . $file_sol;
    system ($the_cmd);

    ($first_cnt, @prod_first_list) = file_read_ilp_solution($file_dir, $prod_num, $first_prodvar);
  }
  elsif ($prod_num == 1){
    $first_cnt = 1;
    $prod_first_list[1] = 1;
  }

  file_write_partition_pla($file_main, $part_cnt, $in_num, $prod_num, $first_cnt, \@part_arr, \@in_arr, \@prod_ind, \@prod_first_list);
}

sub divide_and_conquer{
  my ($file_dir, $file_main, $path_espresso, $path_ilp) = @_;

  my $part_cnt = 0;
  my @part_arr = ();
  my $file_pla = $file_main . ".pla";

  #Solves the separation of products into two parts using a 0-1 ILP technique as done when -tech=2. In this cae, the functions are divided into two sub-functions recursively 
  #considering the difference between the lower and upper bounds of the function

  $part_cnt = 1;
  my $part_index=1;
  my ($false_true, $file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref);
  my ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref);
  my ($non_single_simp, $non_double_simp, $single_lit_simp_ref, $double_lit_simp_ref);
  my ($non_single_dual, $non_double_dual, $single_lit_dual_ref, $double_lit_dual_ref);

  do{
    if ($the_verb < 1){print "[INFO] Finding the lower and upper bounds on the target function in the $file_pla file \n";}
    ($false_true, $file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = simplify_sop($file_dir, $file_main, $file_pla, $path_espresso);
    ($non_single_simp, $non_double_simp, $single_lit_simp_ref, $double_lit_simp_ref) = determine_single_double_products($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt_simp, $prod_lvl_simp_ref, $prod_arr_simp_ref);
    ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = find_dual($file_dir, $file_main, $file_simp, $path_espresso, $in_num, $out_num, $in_arr_ref);
    ($non_single_dual, $non_double_dual, $single_lit_dual_ref, $double_lit_dual_ref) = determine_single_double_products($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt_dual, $prod_lvl_dual_ref, $prod_arr_dual_ref);

    my $the_lb = determine_lower_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref);
    my ($the_ub, $ub_index, $sol_row, $sol_col, @the_sol) = determine_ub($file_dir, $path_espresso, $file_simp, $in_num, $out_num, $prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $in_arr_ref, $lit_arr_ref, $non_double_simp, $non_single_dual, $single_lit_simp_ref, $double_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref);
    if ($the_verb < 1){print BRIGHT_MAGENTA, "[INFO] Lower bound: $the_lb Upper bound: $the_ub \n", RESET;}

    my $file_part = $file_main . "_part" . $part_index . ".pla";
    file_write_pla($file_part, $prod_cnt_simp, $in_num, $in_arr_ref, $prod_ind_simp_ref);

    if ($the_ub - $the_lb >= $ulb_diff){
      $part_arr[1] = $part_index;
      $part_cnt++;
      $part_arr[2] = $part_cnt;

      solve_separation_problem_ilp($file_dir, $file_main, $path_ilp, $prod_cnt_simp, $in_num, $out_num, $in_arr_ref, $prod_ind_simp_ref, 2, \@part_arr);
    }
    else{
      $part_index++;
    }
   
    #Update the PLA file name
    $file_pla = $file_main . "_part" . $part_index . ".pla";
  } while ($part_index <= $part_cnt);

  return ($part_cnt);
}

sub find_lattice_realization{
  my ($initial_time, $the_file, $set_row, $set_col, $path_espresso, $path_sat) = @_;

  my $time_limit = $cpu_limit - (time() - $initial_time);
  janus_pack::janus_func($the_file, $the_verb, $time_limit, $sat_limit, $set_row, $set_col, $path_espresso, $path_sat);
}

sub file_read_solution{
  my ($the_file) = @_;

  my $dot_index = index($the_file, ".pla");
  my $file_sol = substr($the_file, 0, $dot_index) . ".sol";
  #print "Solution file: $file_sol \n";

  my $sol_row = 0;
  my $sol_col = 0;
  my @sol_mat = ();
  my $sol_found = 1;

  my $the_row = 0;
  my $the_col = 0;
  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      #sleep 1;

      if (index($the_line, "#") != -1){
        #Extract the best solution
        if (index($the_line, "# Lattice RowxColumn: ") != -1){
          my $the_size = substr($the_line, 22, length($the_line)-22);
          $the_index = index($the_size, "x");
          $sol_row = substr($the_size, 0, $the_index) + 0.0;
          $sol_col = substr($the_size, $the_index+1, length($the_size)-$the_index-1) + 0.0;
        }
      }
      else{
        if (index($the_line, "NO SOLUTION") != -1){
          $sol_found = 0;
        }
        else{
          #Extract the solution matrix
          if (index($the_line, "| ") != -1){
            $the_row++;
            $the_col = 0;
            
            my $init_index = 0;
            while ($the_col != $sol_col){
              while (substr($the_line, $init_index, 1) eq " " or substr($the_line, $init_index, 1) eq "|"){
                $init_index++;
              }
              $last_index = $init_index;
              while (substr($the_line, $last_index, 1) ne " " and substr($the_line, $last_index, 1) ne "|"){
                $last_index++;
              }
              my $sol_entry = substr($the_line, $init_index, $last_index-$init_index);
              #print "sol entry: $sol_entry \n";

              $the_col++;
              $sol_mat[$the_row][$the_col] = $sol_entry;

              $init_index = $last_index;
            }
          }
        }
      }
    }
    close ($file_header);
  }
  else{
    print RED "[ERROR] Could not open the $file_sol file \n", RESET;
  }

  return ($sol_found, $sol_row, $sol_col, @sol_mat);
}

sub merge_solution{
  my ($the_row, $the_col, $sol_row, $sol_col, $the_sol_ref, $sol_mat_ref) = @_;
  my @the_sol = @ {$the_sol_ref};
  my @sol_mat = @ {$sol_mat_ref};

  if ($sol_row){
    if ($the_row > $sol_row){
      $sol_row = $the_row;
    }

    $sol_col++;
    foreach my $i (1 .. $sol_row){
      $sol_mat[$i][$sol_col] = "F";
    }

    foreach my $i (1 .. $the_col){
      $sol_col++;
      foreach my $j (1 .. $the_row){
        $sol_mat[$j][$sol_col] = $the_sol[$j][$i];
      }
    }
  }
  else{
    $sol_row = $the_row;
    $sol_col = $the_col;
    @sol_mat = @the_sol;
  }

  return ($sol_row, $sol_col, @sol_mat);
}

sub write_solution_falsetrue{
  my ($file_pla, $false_true) = @_;
  #print "Total SAT run: $tot_run \n";

  my $file_name = "";
  my $dot_index = index($file_pla, ".pla");
  if ($dot_index == -1){
    $file_name = $file_pla;
  }
  else{
    $file_name = substr($file_pla, 0, $dot_index);
  }
  $file_name = $file_name . ".sol";

  open (my $fid_out, '>', $file_name);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);    
  printf $fid_out "# Synthesis of a Single Logic Function with a Lattice of Four-Terminal Switches\n";
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Target Function File: %0s \n", $file_pla;
  printf $fid_out "# Solution Quality: Optimal \n";
  printf $fid_out "# Lattice RowxColumn: 1x1 \n";
  printf $fid_out "# Size of lattice: 1 \n";
  printf $fid_out "# Lower bound: 1 \n";
  printf $fid_out "# Upper bound: 1 \n";
  printf $fid_out "# ULB time: 0 \n";
  printf $fid_out "# CPU time: 0 \n";

  if ($false_true){
    printf $fid_out "| T | \n";
  }
  else{
    printf $fid_out "| F | \n";
  }

  close $fid_out;

  return;
}

sub write_solution{
  my ($file_pla, $tot_time, $imp_cnt, $sol_row, $sol_col, $sol_arr_ref, $sol_imp_ref) = @_;
  my @sol_arr = @ {$sol_arr_ref};
  my @sol_imp = @ {$sol_imp_ref};

  my $dot_index = index($file_pla, ".pla");
  my $file_sol = substr($file_pla, 0, $dot_index) . "_dc.sol";

  open (my $fid_out, '>', $file_sol);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);    
  printf $fid_out "# Synthesis of a Single Logic Function with a Lattice of Four-Terminal Switches\n";
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Target Function File: %0s \n", $file_pla;
  printf $fid_out "# Lattice RowxColumn: %0dx%0d \n", $sol_row, $sol_col;
  printf $fid_out "# Size of lattice: %0d \n", $sol_row*$sol_col;
  foreach my $i (1 .. $imp_cnt){
    printf $fid_out "# Realization of the %0s. part lays in between %0d and %0d columns: \n", $sol_imp[$i][1], $sol_imp[$i][2], $sol_imp[$i][3];
  }
  printf $fid_out "# CPU time: %.2f \n", $tot_time;

  foreach my $i (1 .. $sol_row){
    printf $fid_out "| ";
    foreach my $j (1 .. $sol_col){
      if (defined $sol_arr[$i][$j]){
        if (index($sol_arr[$i][$j], "!") != -1){
          printf $fid_out "%0s | ", $sol_arr[$i][$j];
        }
        else{
          printf $fid_out "%0s  | ", $sol_arr[$i][$j];
        }
      }
      else{
        printf $fid_out "T  | ";
      }
    }
    printf $fid_out "\n";
  }

  close $fid_out;
}

sub read_lattice{
  my ($file_name) = @_;

  my $in_cnt = 0;
  my $the_deg = 0;
  my @in_arr = ();

  my $prod_cnt = 0;
  my @prod_arr =();
  my @prod_lvl =();
  my @prod_num = ();

  my $the_end;
  my $the_var;
  my $the_index;
  my $init_index;
  my $last_index;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_name)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      my $llength = length($the_line);

      $init_index=skip_spaces_forward($the_line, 0);
      if (substr($the_line, $init_index, 1) ne "#"){
        #Extract the products
        #print "[INFO] The product: $the_line \n";
        #sleep 1;
        
        $the_end = 0;
        if ($init_index < $llength){
          $prod_cnt++;
          $prod_lvl[$prod_cnt] = 0;

          while ($init_index < $llength){
            $last_index = $init_index;
            while (substr($the_line,$last_index,1) ne " "){
              $last_index++;

              if ($last_index > $llength){
                $the_end = 1;
                last;
              }
            }

            $the_var = substr($the_line, $init_index, $last_index-$init_index);
            #print "[INFO] The product literal: $the_var \n";
            #sleep 1;
 
            $prod_lvl[$prod_cnt]++;
            $prod_arr[$prod_lvl[$prod_cnt]][$prod_cnt] = $the_var;

            $init_index = skip_spaces_forward($the_line, $last_index);
          }

          if (defined $prod_num[$prod_lvl[$prod_cnt]]){
            $prod_num[$prod_lvl[$prod_cnt]]++;
          }
          else{
            $prod_num[$prod_lvl[$prod_cnt]] = 1;
          }

          if ($prod_lvl[$prod_cnt] > $the_deg){
            $the_deg = $prod_lvl[$prod_cnt];
          }
        }
      }
      else{
        if (index($the_line, "INORDER = ") != -1){
          $init_index = index($the_line, "=");
          $init_index = skip_spaces_forward($the_line, $init_index+1);

          $the_end = 0;
          while (1){
            $last_index = $init_index;
            while (substr($the_line,$last_index,1) ne " " and substr($the_line,$last_index,1) ne ";"){
              $last_index++;

              if ($last_index > $llength){
                $the_end = 1;
                last;
              }
            }

            if (substr($the_line,$last_index,1) eq ";"){
              $the_end = 1;
            }

            if ($last_index >= $init_index){
              $the_var = substr($the_line,$init_index,$last_index-$init_index);
              #print "[INFO] The variable: $the_var \n";

              if ($the_var =~ /[0-9a-zA-Z_]/ ){
                $in_cnt++;
                $in_arr[$in_cnt]=$the_var;
              }
            }

            if (!$the_end){
              $init_index = skip_spaces_forward($the_line, $last_index+1);
            }
            else{
              last;
            }
          }
        }
      }
    }

    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the $file_name file \n", RESET;
  }

  return ($in_cnt, $prod_cnt, $the_deg, \@in_arr, \@prod_num, \@prod_lvl, \@prod_arr);
}

sub generate_solution_lattice{
  my ($file_lattice, $sol_row, $sol_col, $sol_arr_ref) = @_;
  my @sol_arr = @ {$sol_arr_ref};

  my $sol_prod_cnt = 0;
  my @sol_prod_lvl = ();
  my @sol_prod_arr = ();

  my ($lat_in_cnt, $lat_prod_cnt, $lat_deg, $lat_in_arr_ref, $lat_prod_num_ref, $lat_prod_lvl_ref, $lat_prod_arr_ref) = read_lattice($file_lattice);
  my @lat_prod_lvl = @ {$lat_prod_lvl_ref};
  my @lat_prod_arr = @ {$lat_prod_arr_ref};

  foreach my $i (1 .. $lat_prod_cnt){
    my $prod_cnt = 0;
    my @prod_arr = ();
    my $valid_prod = 1;

    #print "Lattice product: ";
    foreach my $j (1 .. $lat_prod_lvl[$i]){
      #print "$lat_prod_arr[$j][$i] ";

      my $the_index = $lat_prod_arr[$j][$i] + 0.0;
      my $the_row = int (($the_index-1) / $sol_col) + 1;
      my $the_col = $the_index % $sol_col;
      if (!$the_col){
        $the_col = $sol_col;
      }

      if (defined $sol_arr[$the_row][$the_col]){
        if ($sol_arr[$the_row][$the_col] eq "F"){
          $valid_prod = 0;
          last;
        }
        else{
          if ($sol_arr[$the_row][$the_col] ne "T"){
            $prod_cnt++;
            $prod_arr[$prod_cnt] = $sol_arr[$the_row][$the_col];
          }
        }
      }
    }
    #print "\n";

    if ($valid_prod){
      $sol_prod_cnt++;
      $sol_prod_lvl[$sol_prod_cnt] = $prod_cnt;
      #print "The product in the solution: ";
      foreach my $j (1 .. $prod_cnt){
        $sol_prod_arr[$j][$sol_prod_cnt] = $prod_arr[$j];
        #print "$prod_arr[$j] ";
      }
      #print "\n";
    }
  }

  return ($sol_prod_cnt, \@sol_prod_lvl, \@sol_prod_arr);
}

sub write_not_cnf{
  my ($con_cnt, $not_in, $not_out, @con_arr) = @_;

  $con_cnt++;
  $con_arr[$con_cnt] = $not_in . " " . $not_out . " 0";
  $con_cnt++;
  $con_arr[$con_cnt] = "-" . $not_in . " -" . $not_out . " 0";

  return ($con_cnt, @con_arr);
}

sub write_and_cnf{
  my ($con_cnt, $the_out, $in_cnt, $in_arr_ref, $con_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @con_arr = @ {$con_arr_ref};

  my $last_con = $the_out . " ";
  foreach my $i (1 .. $in_cnt){
    $con_cnt++;
    $con_arr[$con_cnt] = "-" . $the_out . " " . $in_arr[$i] . " 0";
    $last_con = $last_con . "-" . $in_arr[$i] . " ";
  }
  $con_cnt++;
  $con_arr[$con_cnt] = $last_con . "0";

  return ($con_cnt, @con_arr);
}

sub write_or_cnf{
  my ($con_cnt, $the_out, $in_cnt, $in_arr_ref, $con_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @con_arr = @ {$con_arr_ref};

  my $last_con = "-" . $the_out . " ";
  foreach my $i (1 .. $in_cnt){
    $con_cnt++;
    $con_arr[$con_cnt] = $the_out . " -" . $in_arr[$i] . " 0";
    $last_con = $last_con . $in_arr[$i] . " ";
  }
  $con_cnt++;
  $con_arr[$con_cnt] = $last_con . "0";

  return ($con_cnt, @con_arr);
}

sub write_sop_cnf{
  my ($out_name, $var_cnt, $con_cnt, $mit_cnt, $prod_cnt, $var_arr_ref, $con_arr_ref, $mit_arr_ref, $prod_lvl_ref, $prod_arr_ref) = @_;
  my @var_arr = @ {$var_arr_ref};
  my @con_arr = @ {$con_arr_ref};
  my @mit_arr = @ {$mit_arr_ref};
  my @prod_arr = @ {$prod_arr_ref};
  my @prod_lvl = @ {$prod_lvl_ref};

  my $not_in;
  my $not_out;

  my $and_out;
  my $and_in_cnt;
  my @and_in_arr;

  my $or_in_cnt = 0;
  my @or_in_arr = ();

  #OR GATE
  foreach my $i (1 .. $prod_cnt){
    $and_out = 0;
    $and_in_cnt = 0;
    @and_in_arr = ();

    my $zero_prod = 0;
    foreach my $j (1 .. $prod_lvl[$i]){
      if ($prod_arr[$j][$i] eq "F"){
        $zero_prod = 1;
        last;
      }
    }

    if (!$zero_prod){
      my $the_prod = "";
      #AND GATE
      #Only one literal
      if ($prod_lvl[$i] == 1){
        #TARGET LITERAL
        my $var_index = 0;
        my $not_index = index($prod_arr[1][$i], "!");
        
        if ($not_index == -1){
          $var_index = is_inside_string_array($prod_arr[1][$i], $var_cnt, @var_arr);

          if (!$var_index){
            $var_cnt++;
            $var_index = $var_cnt;
            $var_arr[$var_cnt] = $prod_arr[1][$i];
          }
        }
        else{
          #NOT GATE
          #print "The variable with NOT: $prod_arr[1][$i] \n";
          my $the_var = substr($prod_arr[1][$i], $not_index+1, length($prod_arr[1][$i])-$not_index);
          #print "The variable without NOT: $the_var \n";
          
          my $not_var = "NOT_" . $the_var;
          my $notvar_index = is_inside_string_array($not_var, $var_cnt, @var_arr);
          
          if (!$notvar_index){
            $var_cnt++;
            $notvar_index = $var_cnt;
            $var_arr[$var_cnt] = $not_var;
            $not_out = $notvar_index;

            $var_index = is_inside_string_array($the_var, $var_cnt, @var_arr);
            if (!$var_index){
              $var_cnt++;
              $var_index = $var_cnt;
              $var_arr[$var_cnt] = $the_var;
            }
            $not_in = $var_index;

            ($con_cnt, @con_arr) = write_not_cnf($con_cnt, $not_in, $not_out, @con_arr);
          }
          $var_index = $notvar_index;
        }
        $and_out = $var_index;
      }
      #More than one literal
      else{
        foreach my $j (1 .. $prod_lvl[$i]){
          if ($prod_arr[$j][$i] ne "T"){
            $the_prod = $the_prod . $prod_arr[$j][$i];

            #TARGET LITERAL
            my $var_index = 0;
            my $not_index = index($prod_arr[$j][$i], "!");
            
            if ($not_index == -1){
              $var_index = is_inside_string_array($prod_arr[$j][$i], $var_cnt, @var_arr);

              if (!$var_index){
                $var_cnt++;
                $var_index = $var_cnt;
                $var_arr[$var_cnt] = $prod_arr[$j][$i];
              }
            }
            else{
              #NOT GATE
              #print "The variable with NOT: $prod_arr[1][$i] \n";
              my $the_var = substr($prod_arr[$j][$i], $not_index+1, length($prod_arr[$j][$i])-$not_index);
              #print "The variable without NOT: $the_var \n";
              
              my $not_var = "NOT_" . $the_var;
              my $notvar_index = is_inside_string_array($not_var, $var_cnt, @var_arr);
              
              if (!$notvar_index){
                $var_cnt++;
                $notvar_index = $var_cnt;
                $var_arr[$var_cnt] = $not_var;
                $not_out = $notvar_index;

                $var_index = is_inside_string_array($the_var, $var_cnt, @var_arr);
                if (!$var_index){
                  $var_cnt++;
                  $var_index = $var_cnt;
                  $var_arr[$var_cnt] = $the_var;
                }
                $not_in = $var_index;

                ($con_cnt, @con_arr) = write_not_cnf($con_cnt, $not_in, $not_out, @con_arr);
              }
              $var_index = $notvar_index;
            }

            $and_in_cnt++;
            $and_in_arr[$and_in_cnt] = $var_index;
          }
        }

        my $and_var = "AND_" . $the_prod;
        $var_cnt++;
        $var_arr[$var_cnt] = $and_var;
        $and_out = $var_cnt;
        ($con_cnt, @con_arr) = write_and_cnf($con_cnt, $and_out, $and_in_cnt, \@and_in_arr, \@con_arr);
      }

      $or_in_cnt++;
      $or_in_arr[$or_in_cnt] = $and_out;
    }
  }

  my $or_var = "OR_" . $out_name;
  $var_cnt++;
  $var_arr[$var_cnt] = $or_var;
  my $or_out = $var_cnt;
  $mit_cnt++;
  $mit_arr[$mit_cnt] = $var_cnt;
  ($con_cnt, @con_arr) = write_or_cnf($con_cnt, $or_out, $or_in_cnt, \@or_in_arr, \@con_arr);

  return ($var_cnt, $con_cnt, $mit_cnt, \@var_arr, \@con_arr, \@mit_arr);
}

sub write_miter_cnf{
  my ($var_cnt, $con_cnt, $mit_cnt, $var_arr_ref, $con_arr_ref, $mit_arr_ref) = @_;
  my @var_arr = @ {$var_arr_ref};
  my @con_arr = @ {$con_arr_ref};
  my @mit_arr = @ {$mit_arr_ref};

  if ($mit_cnt == 2){
    my $mit_var = "XOR_" . $var_arr[$mit_arr[1]] . "_" . $var_arr[$mit_arr[2]];
    $var_cnt++;
    $var_arr[$var_cnt] = $mit_var;
    my $mit_out = $var_cnt;

    $con_cnt++;
    $con_arr[$con_cnt] = "-" . $mit_out . " -" . $mit_arr[1] . " -" . $mit_arr[2] . " 0";
    $con_cnt++;
    $con_arr[$con_cnt] = "-" . $mit_out . " " . $mit_arr[1] . " " . $mit_arr[2] . " 0";
    $con_cnt++;
    $con_arr[$con_cnt] = $mit_out . " " . $mit_arr[1] . " -" . $mit_arr[2] . " 0";
    $con_cnt++;
    $con_arr[$con_cnt] = $mit_out . " -" . $mit_arr[1] . " " . $mit_arr[2] . " 0";
    $con_cnt++;
    $con_arr[$con_cnt] = $mit_out . " 0";
  }
  else{
    print RED, "[ERROR] There should be only two variables in the MITER logic \n", RESET;
  }

  return ($var_cnt, $con_cnt, \@var_arr, \@con_arr);
}

sub write_cnf_variables{
  my ($file_dir, $var_cnt, @var_arr) = @_;

  my $file_var = $file_dir . "sat_problem.var";
  open (my $fid_var, '>', $file_var);
  
  foreach my $i (1 .. $var_cnt){
    printf $fid_var "%0d = %0s \n", $i, $var_arr[$i];
  }

  close $fid_var;
}

sub write_sat_problem{
  my ($file_dir, $var_cnt, $con_cnt, @con_arr) = @_;

  my $file_cnf = $file_dir . "sat_problem.cnf";
  open (my $fid_ilp, '>', $file_cnf);
  printf $fid_ilp "p cnf %0d %0d \n", $var_cnt, $con_cnt;

  foreach my $i (1 .. $con_cnt){
    printf $fid_ilp "%0s \n", $con_arr[$i];
  }

  close $fid_ilp;
}

sub file_read_cryptolingeling_unsat{
  my ($file_dir) = @_;

  my $unsat = 0;

  my $file_sol = $file_dir . "sat_problem.sol";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)){
    while (1){
      my $the_line = <$file_header>;
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      
      if (index($the_line,"s UNSATISFIABLE") != -1){
        $unsat = 1;
        last;
      }
      elsif (index($the_line, "s SATISFIABLE") != -1){
        last;
      }
    }

    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the cryptominisat/lingeling output! \n", RESET;
  }

  return ($unsat);
}

sub verify_solution{
  my ($file_dir, $path_sat, $target_prod_cnt, $lattice_prod_cnt, $target_prod_lvl_ref, $lattice_prod_lvl_ref, $target_prod_arr_ref, $lattice_prod_arr_ref) = @_;
  my @target_prod_lvl = @ {$target_prod_lvl_ref};
  my @target_prod_arr = @ {$target_prod_arr_ref};
  my @lattice_prod_lvl = @ {$lattice_prod_lvl_ref};
  my @lattice_prod_arr = @ {$lattice_prod_arr_ref};

  #print "[INFO] Products of the target function: \n";
  #foreach my $i (1 .. $target_prod_cnt){
  #  foreach my $j (1 .. $target_prod_lvl[$i]){
  #    print "$target_prod_arr[$j][$i] ";
  #  }
  #  print "\n";
  #}

  #print "[INFO] Products of the lattice function: \n";
  #foreach my $i (1 .. $lattice_prod_cnt){
  #  foreach my $j (1 .. $lattice_prod_lvl[$i]){
  #    print "$lattice_prod_arr[$j][$i] ";
  #  }
  #  print "\n";
  #}

  my $target_out_name = "target"; 
  my $lattice_out_name = "lattice";

  my $mit_cnt = 0;
  my $con_cnt = 0;
  my $var_cnt = 0;
  my @con_arr = ();
  my @mit_arr = ();
  my @var_arr = ();

  my $var_arr_ref = 0;
  my $mit_arr_ref = 0;
  my $con_arr_ref = 0;
  
  my $sol_verified = 0;
  
  #CNF for the target function in SOP
  ($var_cnt, $con_cnt, $mit_cnt, $var_arr_ref, $con_arr_ref, $mit_arr_ref) = write_sop_cnf($target_out_name, $var_cnt, $con_cnt, $mit_cnt, $target_prod_cnt, \@var_arr, \@con_arr, \@mit_arr, \@target_prod_lvl, \@target_prod_arr);
  @var_arr = @ {$var_arr_ref};
  @con_arr = @ {$con_arr_ref};
  @mit_arr = @ {$mit_arr_ref};

  #CNF for the lattice function in SOP
  ($var_cnt, $con_cnt, $mit_cnt, $var_arr_ref, $con_arr_ref, $mit_arr_ref) = write_sop_cnf($lattice_out_name, $var_cnt, $con_cnt, $mit_cnt, $lattice_prod_cnt, \@var_arr, \@con_arr, \@mit_arr, \@lattice_prod_lvl, \@lattice_prod_arr);
  @var_arr = @ {$var_arr_ref};
  @con_arr = @ {$con_arr_ref};
  @mit_arr = @ {$mit_arr_ref};

  #CNF for the MITER
  ($var_cnt, $con_cnt, $var_arr_ref, $con_arr_ref) = write_miter_cnf($var_cnt, $con_cnt, $mit_cnt, \@var_arr, \@con_arr, \@mit_arr);
  @var_arr = @ {$var_arr_ref};
  @con_arr = @ {$con_arr_ref};

  #print "[INFO] #vars: $var_cnt #clauses: $con_cnt \n";
  write_cnf_variables($file_dir, $var_cnt, @var_arr);
  write_sat_problem($file_dir, $var_cnt, $con_cnt, @con_arr);

  my $file_cnf = $file_dir . "sat_problem.cnf";
  my $file_sol = $file_dir . "sat_problem.sol";
  my $the_cmd = $path_sat .  " " . $file_cnf . " > " . $file_sol;
  system($the_cmd);
  $sol_verified = file_read_cryptolingeling_unsat($file_dir);

  return ($sol_verified);
}

sub compute_minimum_cost_simp{
  my ($max_row, $part_cnt, $single_lit_simp_ref, @sol_size) = @_;
  my @single_lit_simp = @ {$single_lit_simp_ref};

  my $the_col = 0;
  my $min_cost = 0;
  my @min_col_arr = ();

  #Compute the minimum column that a partition can have
  foreach my $the_part (1 .. $part_cnt){
    if ($sol_size[$the_part][1] == $max_row){
      $min_col_arr[$the_part] = $sol_size[$the_part][2];
      $the_col = $the_col + $sol_size[$the_part][2];
    }
    else{
      my $the_cost = $sol_size[$the_part][1]*$sol_size[$the_part][2];
      my $a_col = 0;
      do {
        $a_col++;
      } 
      while($a_col * $max_row < $the_cost);
      $min_col_arr[$the_part] = $a_col;
      $the_col = $the_col + $a_col;
    }
  }

  #Add the isolation columns
  $the_col = $the_col + $part_cnt - 1;

  #Add the products with a single literal
  if ($single_lit_simp[0] - $part_cnt + 1 > 0){
    $the_col = $the_col + $single_lit_simp[0] - $part_cnt + 1;
  }

  $min_cost = $max_row * $the_col;

  return ($min_cost, @min_col_arr);
}

sub find_solution_simp{
  my ($initial_time, $file_dir, $file_main, $path_espresso, $path_sat, $path_ilp, $an_ub, $prod_cnt_simp, $in_num, $in_arr_ref, $lit_arr_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $single_lit_simp_ref)= @_;
  my @single_lit_simp = @ {$single_lit_simp_ref};

  my $the_col = 0;
  my $the_row = 0;
  my @the_sol = ();
  my $sol_found = 0;

  my $sol_row = 0; 
  my $sol_col = 0;
  my $part_cnt = 0;
  my $sol_cost = 0;
  my @sol_arr = (); 
  my @sol_imp = (); 
  my @sol_size = ();
  my $time_expired = 0;
  my $sol_lat_str = "";

  #Write down the products under the file_main.pla file excluding the products including a single literal
  #The products with a single literal will be added later as an isolation column
  my ($prod_cnt_nos) = file_write_pla_nosingle($file_main, $prod_cnt_simp, $in_num, $in_arr_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref);
  if ($prod_cnt_nos){
    ($part_cnt) = divide_and_conquer($file_dir, $file_main, $path_espresso, $path_ilp, 0);
    if($the_verb < 1){print BRIGHT_RED "[INFO] Number of partitions: $part_cnt \n", RESET;}

    my $max_row = 0;
    my @orig_sol = ();
    my $prev_success = 1;

    foreach my $the_part (1 .. $part_cnt){
      my $file_part = $file_main . "_part" . $the_part . ".pla";

      #Find the realization of the partitioned partial products
      if($the_verb < 1){print "\n";}
      if($the_verb < 1){print BRIGHT_BLUE "[INFO] Finding the lattice realization on the $the_part. partition... \n", RESET;}
      find_lattice_realization($initial_time, $file_part, 0, 0, $path_espresso, $path_sat);
 
      my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_part);
      $sol_size[$the_part][1] = $the_row;
      $sol_size[$the_part][2] = $the_col;
      $sol_size[$the_part][3] = \@the_sol;
      if ($the_row > $max_row){
        $max_row = $the_row;
      }
      ($sol_row, $sol_col, @sol_arr) = merge_solution($the_row, $the_col, $sol_row, $sol_col, \@the_sol, \@sol_arr);
      $sol_imp[$the_part][1] = "$the_part";
      $sol_imp[$the_part][2] = $sol_col-$the_col+1;
      $sol_imp[$the_part][3] = $sol_col;

      if (time() - $initial_time + 0.1 > $cpu_limit){
        print "[INFO] Leaving the find_solution_simp process due to the CPU time limit... \n";
        $time_expired = 1;
        #print "time_expired: $time_expired \n";
        
        #@sol_arr = ();
        #@sol_imp = ();
        #$part_cnt = 0;
        #$sol_row = 9**9**9;
        #$sol_col = 9**9**9;
        #$sol_cost = 9**9**9;
        #return ($part_cnt, $sol_row, $sol_col, $sol_cost, \@sol_arr, \@sol_imp);
      }
    }

    if($the_verb < 1){print "\n";}
    my $max_cost = $sol_row*$sol_col; 
    $sol_lat_str = $sol_row . "x" . $sol_col;
    if($the_verb < 1){print BRIGHT_BLUE, "[INFO] Initial solution: $sol_lat_str \n", RESET;}
    if($the_verb < 1){print BRIGHT_RED, "[INFO] Initial cost value: $max_cost \n", RESET;}
    if($the_verb < 1){print "\n";}

    @orig_sol = @{ dclone(\@sol_size) };

    if ($part_cnt > 1 or ($part_cnt == 1 and $single_lit_simp[0])){
      while ($max_row >= 3 and !$time_expired){
        my $temp_row = 0;
        my $temp_col = 0;
        my @temp_sol = ();
        my @temp_imp = ();

        my ($min_cost, @min_col_arr) = compute_minimum_cost_simp($max_row, $part_cnt, $single_lit_simp_ref, @orig_sol);
        #print "max_row: $max_row \n";
        #print "min_cost: $min_cost \n";

        if ($min_cost < $max_cost){
          my $cost_exceeded = 0;
          foreach my $the_part (1 .. $part_cnt){
            my $file_part = $file_main . "_part" . $the_part . ".pla";

            if ($orig_sol[$the_part][1] < $max_row){
              if ($orig_sol[$the_part][2] > 2){
                my $orig_col = $orig_sol[$the_part][2];
                my $sol_improved = 0;
                while (1){
                  $orig_col--;
                  if ($orig_col > 1){
                    if ($orig_sol[$the_part][1] * $orig_sol[$the_part][2] <= $max_row * $orig_col){
                      my $lat_str = $max_row . "x" . $orig_col;
                      if($the_verb < 1){print BOLD BLUE "[INFO] Checking if the $the_part. output can be realized using the $lat_str lattice... \n", RESET;}
                      find_lattice_realization($initial_time, $file_part, $max_row, $orig_col, $path_espresso, $path_sat);
                      my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_part);
                      if ($sol_found){
                        $sol_improved = 1;
                        $sol_size[$the_part][1] = $the_row;
                        $sol_size[$the_part][2] = $the_col;
                        $sol_size[$the_part][3] = \@the_sol;
                      }
                      else{
                        last;
                      }
                    }
                  }
                  else{
                    last;
                  }

                  if (time() - $initial_time + 0.1 > $cpu_limit){
                    print "[INFO] Leaving the find_solution_simp process due to the CPU time limit... \n";
                    $time_expired = 1;
                    #print "time_expired: $time_expired \n";
                    last;
                  }
                }

                my @the_sol = ();
                if ($sol_improved){
                  $the_row = $sol_size[$the_part][1];
                  $the_col = $sol_size[$the_part][2];
                  @the_sol = @{ dclone(\@{$sol_size[$the_part][3]}) };
                }
                else{
                  $the_row = $orig_sol[$the_part][1];
                  $the_col = $orig_sol[$the_part][2];
                  @the_sol = @{ dclone(\@{$orig_sol[$the_part][3]}) };
                }
                ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
                $temp_imp[$the_part][1] = "$the_part";
                $temp_imp[$the_part][2] = $temp_col-$the_col+1;
                $temp_imp[$the_part][3] = $temp_col;
              }
              else{
                $the_row = $orig_sol[$the_part][1];
                $the_col = $orig_sol[$the_part][2];
                @the_sol = @{ dclone (\@{$orig_sol[$the_part][3]}) };
                ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
                $temp_imp[$the_part][1] = "$the_part";
                $temp_imp[$the_part][2] = $temp_col-$the_col+1;
                $temp_imp[$the_part][3] = $temp_col;
              }
            }
            elsif ($orig_sol[$the_part][1] > $max_row){
              my $orig_col = $orig_sol[$the_part][2];
              my $sol_improved = 0;
              while (1){
                $orig_col++;
                
                if ($orig_sol[$the_part][1] * $orig_sol[$the_part][2] <= $max_row * $orig_col){
                  my $current_cost = 0;
                  if ($the_part == 1){
                    $current_cost = $current_cost + $max_row*$orig_col;
                  }
                  elsif ($the_part > 1){
                    $current_cost = $current_cost + $max_row*$temp_col;
                    $current_cost = $current_cost + $max_row*($orig_col+1);
                  }
                  #Cost for this partition
                  #Minimum cost for the next partitions
                  for (my $part_index=$the_part+1; $part_index<=$part_cnt; $part_index++){
                    $current_cost = $current_cost + $max_row*($min_col_arr[$part_index]+1);
                  }
                  #print "current_cost: $current_cost \n";

                  if ($current_cost < $max_cost){
                    my $lat_str = $max_row . "x" . $orig_col;                                               
                    if($the_verb < 1){print BOLD BLUE "[INFO] Checking if the $the_part. output can be realized using the $lat_str lattice... \n", RESET;}
                    find_lattice_realization($initial_time, $file_part, $max_row, $orig_col, $path_espresso, $path_sat);
                    my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_part);        
                    if ($sol_found){
                      $sol_improved = 1;
                      $sol_size[$the_part][1] = $the_row;                                                  
                      $sol_size[$the_part][2] = $the_col;
                      $sol_size[$the_part][3] = \@the_sol;
                      last;
                    }
                  }
                  else{
                    $cost_exceeded = 1;
                    last;
                  }

                  if (time() - $initial_time + 0.1 > $cpu_limit){
                    print "[INFO] Leaving the find_solution_simp process due to the CPU time limit... \n";
                    $time_expired = 1;
                    last;
                  }
                }
              }

              my @the_sol = ();
              if ($sol_improved){
                $the_row = $sol_size[$the_part][1];
                $the_col = $sol_size[$the_part][2];
                @the_sol = @{ dclone(\@{$sol_size[$the_part][3]}) };
              }
              else{
                $the_row = $orig_sol[$the_part][1];
                $the_col = $orig_sol[$the_part][2];
                @the_sol = @{ dclone(\@{$orig_sol[$the_part][3]}) };
              }
              ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
              $temp_imp[$the_part][1] = "$the_part";
              $temp_imp[$the_part][2] = $temp_col-$the_col+1;
              $temp_imp[$the_part][3] = $temp_col;
            }   
            elsif ($orig_sol[$the_part][1] == $max_row){
              $the_row = $orig_sol[$the_part][1];
              $the_col = $orig_sol[$the_part][2];
              @the_sol = @{ dclone (\@{$orig_sol[$the_part][3]}) };
              ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
              $temp_imp[$the_part][1] = "$the_part";
              $temp_imp[$the_part][2] = $temp_col-$the_col+1;
              $temp_imp[$the_part][3] = $temp_col;
            }

            if ($time_expired or $cost_exceeded){
              last;
            }
          }

          if (!$time_expired){
            if (!$cost_exceeded){
              my $temp_cost = $temp_row*$temp_col;
              if ($temp_cost <= $max_cost){
                $prev_success = 1;

                if ($the_verb < 1){print BRIGHT_RED, "[INFO] Good job! The cost has been decreased to $temp_cost \n", RESET;};
                $max_cost = $temp_cost;
                $sol_row = $temp_row;
                $sol_col = $temp_col;
                @sol_arr = @{ dclone(\@temp_sol) };
                @sol_imp = @{ dclone(\@temp_imp) };

                if ($single_lit_simp[0] - $part_cnt + 1 > 0){
                  $an_ub = $temp_cost + $temp_row * ($single_lit_simp[0] - $part_cnt + 1);
                }
                else{
                  $an_ub = $temp_cost;
                }
              }
              else{
                if ($prev_success){
                  #$prev_success = 0;
                  $prev_success = 1;
                }
                else{
                  if ($the_verb < 1){print BRIGHT_RED, "[INFO] The last two attempts to find a solution with a small number of rows have just failed. Returning the solution... \n", RESET;};
                  last;
                }
              }
            }
            else{
              if ($prev_success){
                #$prev_success = 0;
                $prev_success = 1;
              }
              else{
                if ($the_verb < 1){print BRIGHT_RED, "[INFO] The last two attempts to find a solution with a small number of rows have just failed. Returning the solution... \n", RESET;};
                last;
              }
            }
          }
        }
        else{
          if ($the_verb < 1){print BRIGHT_GREEN, "[INFO] Computation of the cost with $max_row rows points out a worse cost than the found so far! Decreasing max_row... \n", RESET;};
          #$prev_success = 0;
          $prev_success = 1;
        }

        if ($time_expired){
          last;
        }
        else{
          $max_row--;
        }
      }
    }
  }
  
  #Add the products with single literals first to the isolation columns then at the right end of the lattice
  my $single_cnt = $single_lit_simp[0];
  #print "[INFO] single_cnt $single_cnt \n";
  if ($single_cnt){
    if ($the_verb <= 1){print BRIGHT_BLUE "[INFO] Adding the products with a single literal... \n", RESET;};
    my @in_arr = @ {$in_arr_ref};
    my @lit_arr = @ {$lit_arr_ref};
    
    my $single_pnt = 0;
    my $single_col = 0;
    
    foreach my $the_part (1 .. $part_cnt-1){
      $single_pnt++;

      my $the_var = "";
      if ($lit_arr[$single_lit_simp[$single_pnt]] < 0){
        $the_var = "!";
      }
      $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pnt]])];
      #print "[INFO] the_var: $the_var \n";

      $single_col = $sol_imp[$the_part][3]+1;
      #print "[INFO] single_col: $single_col \n";
      foreach my $row_index (1 .. $sol_row){
        $sol_arr[$row_index][$single_col] = $the_var;
      }

      if ($single_pnt == $single_cnt){
        last;
      }
    }

    if (!$prod_cnt_nos){
      $sol_row = 1;
    }

    while ($single_pnt < $single_cnt){
      $single_pnt++;
      my $the_var = "";
      if ($lit_arr[$single_lit_simp[$single_pnt]] < 0){
        $the_var = "!";
      }
      $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pnt]])];
      #print "[INFO] the_var: $the_var \n";

      $sol_col++;
      #print "[INFO] sol_col: $sol_col \n";
      foreach my $row_index (1 .. $sol_row){
        $sol_arr[$row_index][$sol_col] = $the_var;
      }
    }
  }

  $sol_cost = $sol_row * $sol_col;
  $sol_lat_str = $sol_row . "x" . $sol_col;
  if($the_verb < 1){print "\n"};
  if($the_verb < 1){print BRIGHT_BLUE, "[INFO] Final solution: $sol_lat_str \n", RESET;}
  if($the_verb < 1){print BRIGHT_RED, "[INFO] Final cost value: $sol_cost \n", RESET;}
  if($the_verb < 1){print "\n"};

  return ($time_expired, $part_cnt, $sol_row, $sol_col, $sol_cost, \@sol_arr, \@sol_imp);
}

sub compute_minimum_cost_dual{
  my ($max_col, $part_cnt, $single_lit_dual_ref, @sol_size) = @_;
  my @single_lit_dual = @ {$single_lit_dual_ref};

  my $the_row = 0;
  my $min_cost = 0;

  #Compute the minimum row that a partition can have
  foreach my $the_part (1 .. $part_cnt){
    if ($sol_size[$the_part][4]){
      $the_row = $the_row + $sol_size[$the_part][1];
    }
    else{
      my $the_cost = $sol_size[$the_part][1]*$sol_size[$the_part][2];
      my $a_row = 0;
      do {
        $a_row++;
      } 
      while(($a_row * $max_col) < $the_cost);
      $the_row = $the_row + $a_row;
    }
  }

  #Add the isolation rows
  $the_row = $the_row + $part_cnt - 1;

  #Add the products with a single literal
  if ($single_lit_dual[0] - $part_cnt + 1 > 0){
    $the_row = $the_row + $single_lit_dual[0] - $part_cnt + 1;
  }

  $min_cost = $the_row * $max_col;

  return ($min_cost);
}

sub main_part{
  my $initial_time = time();  

  my $file_dir = "";
  my $file_name = "";
  my $leaned_right = index($file_pla, "/");
  my $leaned_left = index($file_pla, "\\");
  if ($leaned_right != -1 or $leaned_left != -1){
    my $pla_index = index($file_pla, ".pla");
    my $dot_index = $pla_index;
    while (substr($file_pla, $pla_index, 1) ne "/" and substr($file_pla, $pla_index, 1) ne "\\"){
      $pla_index--;
    }
    $file_dir = substr($file_pla, 0, $pla_index+1) . "temp";
    $file_name = substr($file_pla, $pla_index+1, $dot_index-$pla_index-1);
  }
  else{
    $file_dir = "temp";
    $file_name = $file_pla;
  }
  if (!(-e $file_dir and -d $file_dir)){
    my $the_cmd = "mkdir " . $file_dir;
    system($the_cmd);
  }
  if ($leaned_right != -1){
    $file_dir = $file_dir . "/";
  }
  else{
    $file_dir = $file_dir . "\\";
  }

  my $file_main = $file_dir . $file_name;
  
  my $opt_col = 0;
  my $opt_row = 0;
  my $sol_opt = 0;
  my @opt_sol = ();
  my $sol_nonopt = 0;
  my $tot_sat_var = 0;
  my $tot_sat_cnf = 0;
  my $tot_sat_run = 0;
  
  #Extract the paths for the SAT solvers and espresso
  my ($paths_ok, $path_espresso, $path_ilp, $path_sat) = extract_paths("paths.pl");

  if (!$the_verb){print "[INFO] Simplifying the target function and generating the truth table... \n";}
  my ($false_true, $file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = simplify_sop($file_dir, $file_main, $file_pla, $path_espresso);
  if ($false_true == -1 and $in_num and $out_num == 1){
    my ($non_single_simp, $non_double_simp, $single_lit_simp_ref, $double_lit_simp_ref) = determine_single_double_products($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt_simp, $prod_lvl_simp_ref, $prod_arr_simp_ref);
    if (!$the_verb){print "[INFO] Finding the dual of the target function... \n";}
    my ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = find_dual($file_dir, $file_main, $file_simp, $path_espresso, $in_num, $out_num, $in_arr_ref);
    my ($non_single_dual, $non_double_dual, $single_lit_dual_ref, $double_lit_dual_ref) = determine_single_double_products($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt_dual, $prod_lvl_dual_ref, $prod_arr_dual_ref);

    if (!$the_verb){print "[INFO] Finding the lower and upper bounds of the problem... \n";}
    my ($the_lb) = determine_lower_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref);
    my ($the_ub, $ub_index, $ub_row, $ub_col, @ub_sol) = determine_ub($file_dir, $path_espresso, $file_simp, $in_num, $out_num, $prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $in_arr_ref, $lit_arr_ref, $non_double_simp, $non_single_dual, $single_lit_simp_ref, $double_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref);
    if ($the_verb <= 1){print MAGENTA, "[INFO] Lower bound: $the_lb Upper bound: $the_ub (determined by the $ub_index. criteria) \n", RESET;}
    my $ulb_time = time() - $initial_time;

    my $sol_row = 0;
    my $sol_col = 0;
    my $part_cnt = 0;
    my @sol_arr = ();
    my @sol_imp = ();
    my $time_expired = 0;

    my $part_cnt_simp = 0;
    my $sol_arr_simp_ref = 0;
    my $sol_imp_simp_ref = 0;
    my $sol_row_simp = 9**9**9;
    my $sol_col_simp = 9**9**9;
    my $sol_cost_simp = 9**9**9;
    
    my $an_ub = $the_ub;
    if ($the_verb <= 1){print BRIGHT_BLUE "[INFO] Searching a solution on the target function itself... \n", RESET;};
    ($time_expired, $part_cnt_simp, $sol_row_simp, $sol_col_simp, $sol_cost_simp, $sol_arr_simp_ref, $sol_imp_simp_ref) = find_solution_simp($initial_time, $file_dir, $file_main, $path_espresso, $path_sat, $path_ilp, $an_ub, $prod_cnt_simp, $in_num, $in_arr_ref, $lit_arr_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $single_lit_simp_ref);
    if ($ub_row * $ub_col >= $sol_cost_simp){
      if ($the_verb <= 1){print BRIGHT_YELLOW "[INFO] Hurray! The solution is obtained by the divide&conquer method on the target function itself. \n", RESET;};

      $sol_row = $sol_row_simp;
      $sol_col = $sol_col_simp;
      $part_cnt = $part_cnt_simp;
      @sol_arr = @ {$sol_arr_simp_ref};
      @sol_imp = @ {$sol_imp_simp_ref};
    }
    else{
      if ($the_verb <= 1){print BRIGHT_YELLOW "[INFO] Oops! The solution is obtained by the upper bound. \n", RESET;};
      $sol_row = $ub_row;
      $sol_col = $ub_col;
      @sol_arr = @{ dclone(\@ub_sol) };
      $sol_imp[1][1] = "1";
      $sol_imp[1][2] = 1;
      $sol_imp[1][3] = $sol_col;
    }

    my $total_time = time() - $initial_time;
    write_solution($file_pla, $total_time, $part_cnt, $sol_row, $sol_col, \@sol_arr,\@sol_imp);
    my $sollat_str = $sol_row . "x" . $sol_col;
    print BRIGHT_GREEN "[INFO] The solution: $sollat_str \n", RESET;
    print BRIGHT_CYAN "[INFO] Total CPU time: $total_time \n", RESET;

    my $file_lattice = "l" . $sollat_str . ".eqn";
    if (-e $file_lattice){
      my ($sol_prod_cnt, $sol_prod_lvl_ref, $sol_prod_arr_ref) = generate_solution_lattice($file_lattice, $sol_row, $sol_col, \@sol_arr);
      if (!$the_verb){print "[INFO] Verifying the found solution... \n";}
      my ($sol_verified) = verify_solution($file_dir, $path_sat, $prod_cnt_simp, $sol_prod_cnt, $prod_lvl_simp_ref, $sol_prod_lvl_ref, $prod_arr_simp_ref, $sol_prod_arr_ref);
      if ($sol_verified){
        if ($the_verb <= 1){print GREEN, "[INFO] The found solution has just been verified through SAT-based equivalence checking! \n", RESET;}
      }
      else{
        print RED, "[ERROR] The found solution could NOT be verified! \n", RESET;
      }
    }
  }
  else{
    if ($false_true != -1){
      write_solution_falsetrue($file_pla, $false_true);
    }
    elsif ($out_num != 1){
      print RED, "[INFO] MEDEA can only be applied to a single function! \n", RESET;
    }
  }
}

