#!/usr/bin/perl

use Cwd qw(); 
use strict;
#use warnings;
#use diagnostics;
use Time::HiRes qw( time );
use warnings FATAL => 'all';
use Term::ANSIColor qw(:constants);

my $row_num = 0;
my $col_num = 0;

my $arg_ok = 1;
my $arg_cnt = 0;

while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
      last;
    }
    elsif(index($ARGV[$arg_cnt], "-r=") != -1){
      my $row_str = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3);
      if ($row_str =~ /[0-9]/ and !($row_str =~ /[^0-9]/)){
        $row_num = $row_str + 0.0;
      }
      else{
        $arg_ok = 0;
        last;
      }
    }
    elsif(index($ARGV[$arg_cnt], "-c=") != -1){
      my $col_str = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3);
      if ($col_str =~ /[0-9]/ and !($col_str =~ /[^0-9]/)){
        $col_num = $col_str + 0.0;
      }
      else{
        $arg_ok = 0;
        last;
      }
    }
    else{
      $arg_ok = 0;
      last;
    }
  }
  else{
    last;
  }

  $arg_cnt++;
}

if ($arg_ok){
  main_part($row_num, $col_num);
}
else{
  help_part();
}

sub help_part{
  print "\n";
  print "###################################################################################\n";
  print "# Usage:        perl genlatfunc_rec.pl -r=m -c=n                                  #\n";
  print "# -r:           Indicates the number of rows where m is a positive integer        #\n";
  print "# -c:           Indicates the number of columns where n is a positive integer     #\n";
  print "# Output:       Lattice equation in sum of product (SOP) form where the variables #\n";
  print "#               are indexed as an integer, set to 0 initially, increased by each  #\n";
  print "#               column in every row                                               #\n";
  print "# Description:  Finds all the paths by extending the paths in the (m-1)xn lattice #\n";
  print "###################################################################################\n";
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      return $the_offset;
    }
  }

  return $the_offset;
}

sub write_lattice{
  my ($row_num, $col_num, $sop_cnt, $sop_lvl_ref, $sop_arr_ref) = @_;
  my @sop_lvl = @ {$sop_lvl_ref};
  my @sop_arr = @ {$sop_arr_ref};

  my $min_prod = 2^31-1;
  my $max_prod = 0;
  
  my @spec_prod = ();
  my $file_out = "l" . $row_num . "x" . "$col_num" . ".eqn";

  open (my $fid_out, '>', $file_out);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);    
  printf $fid_out "# Automatic Generation of the %0dx%0d Lattice Function \n", $row_num, $col_num;
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Number of Inputs: %0d \n", $row_num*$col_num;
  printf $fid_out "# Number of Outputs: 1 \n";
  printf $fid_out "# INORDER = ";
  foreach my $i (1 .. $row_num * $col_num - 1){
    printf $fid_out "%d ", $i; 
  }
  printf $fid_out "%0d;\n", $row_num * $col_num;
  printf $fid_out "# OUTORDER = f; \n";
  foreach my $i (1 .. $sop_cnt){
    if (defined $spec_prod[$sop_lvl[$i]]){
      $spec_prod[$sop_lvl[$i]]++;
    }
    else{
      $spec_prod[$sop_lvl[$i]] = 1;

      if ($sop_lvl[$i] > $max_prod){
        $max_prod = $sop_lvl[$i];
      }
      if ($sop_lvl[$i] < $min_prod){
        $min_prod = $sop_lvl[$i];
      }
    }

    foreach my $j (1 .. $sop_lvl[$i]){
      printf $fid_out "%d ", $sop_arr[$j][$i];
    }
    printf $fid_out "\n";
  }
  printf $fid_out "# Summary of the Function \n";
  printf $fid_out "# Number of products: %0d \n", $sop_cnt;
  printf $fid_out "# Minimum size of a product: %0d \n", $min_prod;
  printf $fid_out "# Maximum size of a product: %0d \n", $max_prod;
  foreach my $i ($min_prod .. $max_prod){
    if (defined $spec_prod[$i]){
      printf $fid_out "# Number of products with %0d variables: %0d \n", $i, $spec_prod[$i];
    }
    else{
      printf $fid_out "# Number of products with %0d variables: 0 \n", $i;
    }
  }
  printf $fid_out "\n";
  close $fid_out;
}

sub add_symmetric_products {
  my ($row_val, $col_val, $sop_cnt, $sop_lvl_ref, $sop_arr_ref) = @_;
  my @sop_lvl = @ {$sop_lvl_ref};
  my @sop_arr = @ {$sop_arr_ref};

  my @sym_arr = ();
  foreach my $the_point (1 .. $row_val*$col_val){
    my $the_row = int ($the_point/$col_val + 0.99);
    my $fl_sum = (2*$the_row-1) * ($col_val) + 1;

    $sym_arr[$the_point] = $fl_sum - $the_point;
  }

  my $col_sym = int ($col_num/2);
  foreach my $i (1 .. $sop_cnt){
    if ($sop_arr[1][$i] <= $col_sym){
      $sop_cnt++;
      $sop_lvl[$sop_cnt] = $sop_lvl[$i];
      foreach my $j (1 .. $sop_lvl[$i]){
        $sop_arr[$j][$sop_cnt] = $sym_arr[$sop_arr[$j][$i]];
      }
    }
  }
  
  return ($sop_cnt, \@sop_lvl, \@sop_arr);
}

sub read_lattice{
  my ($row_val, $col_val) = @_;

  my $file_name = "l" . $row_val . "x" . $col_val . ".eqn";

  my $prod_cnt = 0;
  my @prod_arr =();
  my @prod_lvl =();

  my $the_end;
  my $the_var;
  my $the_index;
  my $init_index;
  my $last_index;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_name)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      $init_index=skip_spaces_forward($the_line, 0);
      if (substr($the_line, $init_index, 1) ne "#"){
        #Extract the products
        #print "[INFO] The product: $the_line \n";
        #sleep 1;
        
        $the_end = 0;
        my $llength = length($the_line);

        if ($init_index < $llength){
          $prod_cnt++;
          $prod_lvl[$prod_cnt] = 0;

          while ($init_index < $llength){
            $last_index = $init_index;
            while (substr($the_line,$last_index,1) ne " "){
              $last_index++;

              if ($last_index > $llength){
                $the_end = 1;
                last;
              }
            }

            $the_var = substr($the_line, $init_index, $last_index-$init_index);
            #print "[INFO] The product literal: $the_var \n";
            #sleep 1;
 
            $prod_lvl[$prod_cnt]++;
            $prod_arr[$prod_lvl[$prod_cnt]][$prod_cnt] = $the_var;

            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
    }

    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the $file_name file \n", RESET;
  }

  return ($prod_cnt, \@prod_lvl, \@prod_arr);
}

sub add_path{
  my ($row_val, $col_val, $is_added, $the_index, $cand_move, $cand_point, $path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = @_;
  my @path_move = @ {$path_move_ref};
  my @path_end = @ {$path_end_ref};
  my @path_lvl = @ {$path_lvl_ref};
  my @path_arr = @ {$path_arr_ref};
 
  if ($is_added == 1){
    $path_lvl[$the_index]++;
    $path_move[$the_index] = abs(3 - $cand_move);
    $path_arr[$path_lvl[$the_index]][$the_index] = $cand_point;

    if ($cand_move == 3){
      my $the_row = int ($cand_point / $col_val + 0.99);
      if ($the_row == $row_val){
        $path_end[$the_index] = 1;
      }
      else{
        $path_end[$the_index] = 0;
      }
    }
  }
  else{
    $path_cnt++;
    $path_move[$path_cnt] = abs(3 - $cand_move);
    $path_lvl[$path_cnt] = $path_lvl[$the_index];
    foreach my $k (1 .. $path_lvl[$the_index]-1){
      $path_arr[$k][$path_cnt] = $path_arr[$k][$the_index];
    }
    $path_arr[$path_lvl[$path_cnt]][$path_cnt] = $cand_point;
    
    if ($cand_move == 3){
      my $the_row = int ($cand_point / $col_val + 0.99);
      if ($the_row == $row_val){
        $path_end[$path_cnt] = 1;
      }
      else{
        $path_end[$path_cnt] = 0;
      }
    }
  }

  return ($path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
}

sub generate_lattice{
  my ($row_val, $col_val) = @_;

  my $sop_cnt = 0;
  my @sop_lvl = ();
  my @sop_arr = ();
  my $sop_lvl_ref = 0;
  my $sop_arr_ref = 0;

  #my $initial_time = time();
  my $col_sym = int ($col_val/2 + 0.99);
  my $lat_str = $row_val . "x" . $col_val;
  my $pre_lat_str = ($row_val-1) . "x" . $col_val;
 
  #print "[INFO] Reading the $pre_lat_str lattice function... \n";
  my ($pre_sop_cnt, $pre_sop_lvl_ref, $pre_sop_arr_ref) = read_lattice($row_val-1, $col_val);
  my @pre_sop_arr = @ {$pre_sop_arr_ref};
  my @pre_sop_lvl = @ {$pre_sop_lvl_ref};

  #print "[INFO] Finding the $lat_str lattice function... \n";
  foreach my $i (1 .. $pre_sop_cnt){
    if ($pre_sop_arr[1][$i] <= $col_sym){
      my $path_cnt = 1;
      my @path_lvl = ();
      my @path_arr = ();
      my @path_end = ();
      my @path_move = ();
      my $path_end_ref = 0;
      my $path_lvl_ref = 0;
      my $path_arr_ref = 0;
      my $path_move_ref = 0;

      $path_end[$path_cnt] = 0;
      $path_move[$path_cnt] = 0; #Indicates the previous move (0: from up, 1: from left, 2: from right, 3: from down) 
      $path_lvl[$path_cnt] = $pre_sop_lvl[$i];
      foreach my $j (1 .. $pre_sop_lvl[$i]){
        $path_arr[$j][$path_cnt] = $pre_sop_arr[$j][$i];
      }

      while (1){
        my $the_end = 1;
        
        foreach my $j (1 .. $path_cnt){
          if (!$path_end[$j]){
            $the_end = 0;

            my $last_point = $path_arr[$path_lvl[$j]][$j];
            my $the_row = int ($last_point / $col_val + 0.99);
            my $the_col = ($last_point % $col_val);
            my $the_move = $path_move[$j];
            if (!$the_col){
              $the_col = $col_val;
            }

            my $is_added = 0;
            foreach my $cand_move (0 .. 3){
              if ($the_move != $cand_move){
                my $is_invalid = 0;

                if ($cand_move == 0){
                  my $cand_point = $last_point - $col_val;
                  
                  if ($the_row <= 2 or $col_val - $the_col <= 1 or $the_col <= 2){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $path_lvl[$j]){
                      if (($path_arr[$k][$j] + 1 == $cand_point and $the_col != 1) or $path_arr[$k][$j] - 1 == $cand_point or $path_arr[$k][$j] == $cand_point or $path_arr[$k][$j] + $col_val == $cand_point){
                        $is_invalid = 1;
                      }
                    }
                  }

                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 1){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point - 1;
                  my $cand_row = int ($cand_point / $col_val + 0.99);
                  
                  if ($the_row == 1 or $the_col == 1){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $path_lvl[$j]){
                      my $point_row = int ($path_arr[$k][$j]/$col_val + 0.99);

                      if ($path_arr[$k][$j] - $col_val == $cand_point or $path_arr[$k][$j] + $col_val == $cand_point or $path_arr[$k][$j] == $cand_point or ($path_arr[$k][$j] + 1 == $cand_point and $point_row == $cand_row)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 2){
                  my $is_invalid = 0;
                  my $cand_point = $last_point + 1;
                  my $cand_row = int ($cand_point / $col_val + 0.99);

                  if ($the_row == 1 or $the_col == $col_val){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $path_lvl[$j]){
                      my $point_row = int ($path_arr[$k][$j]/$col_val + 0.99);

                      if ($path_arr[$k][$j] - $col_val == $cand_point or $path_arr[$k][$j] + $col_val == $cand_point or $path_arr[$k][$j] == $cand_point or ($path_arr[$k][$j] - 1 == $cand_point and $point_row == $cand_row)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 3){
                  my $is_invalid = 0;
                  my $cand_point = $last_point + $col_val;
                  my $cand_row = int ($cand_point / $col_val + 0.99);
                  
                  foreach my $k (1 .. $path_lvl[$j]){
                    my $point_row = int ($path_arr[$k][$j]/$col_val + 0.99);

                    if (($path_arr[$k][$j] + 1 == $cand_point and $point_row == $cand_row) or ($path_arr[$k][$j] - 1 == $cand_point and $point_row == $cand_row) or $path_arr[$k][$j] - $col_val == $cand_point or $path_arr[$k][$j] == $cand_point){
                      $is_invalid = 1;
                      last;
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
              }
            }

            if (!$is_added){
              $path_end[$j] = -1;
            }
          }
        }

        if ($the_end){
          foreach my $m (1 .. $path_cnt){
            if ($path_end[$m] == 1){
              $sop_cnt++;
              $sop_lvl[$sop_cnt] = $path_lvl[$m];
              foreach my $n (1 .. $path_lvl[$m]){
                $sop_arr[$n][$sop_cnt] = $path_arr[$n][$m];
              }
            }
          }

          last;
        }
      }
    }
  }

  #print "[INFO] Adding the symmetric paths... \n";
  ($sop_cnt, $sop_lvl_ref, $sop_arr_ref) = add_symmetric_products($row_val, $col_val, $sop_cnt, \@sop_lvl, \@sop_arr);
  #print "[INFO] Number of products in the $lat_str lattice: $sop_cnt \n";
  #print "[INFO] Writing the lattice function... \n";
  write_lattice($row_val, $col_val, $sop_cnt, $sop_lvl_ref, $sop_arr_ref);
}

sub main_part{
  my ($row_val, $col_val) = @_;
  #print "\n";
  #print "#Rows: $row_num\n";
  #print "#Columns: $col_num\n";

  #Find the available lattice with mx(col_val) where m is the largest integer with m < $row_val. If not, generate the 1x(col_val) lattice
  while (1){
    $row_val--;
    if (!$row_val){
      my @sop_lvl = ();
      my @sop_arr = ();
      my $sop_cnt = $col_val;

      foreach my $i (1 .. $col_val){
        $sop_lvl[$i] = 1;
        $sop_arr[1][$i] = $i;
      }

      $row_val++;
      write_lattice(1, $col_val, $sop_cnt, \@sop_lvl, \@sop_arr);
      last;
    }
    else{
      my $base_lat_str = "l" . $row_val . "x" . $col_val . ".eqn";
      if (-e $base_lat_str){
        last;
      }
    }
  }

  #Start building up the lattices recursively
  while ($row_val != $row_num){
    $row_val++;
    generate_lattice($row_val, $col_val);
  }
}

