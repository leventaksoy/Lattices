#!/usr/bin/perl

use Cwd qw(); 
use strict;
use warnings;
#use diagnostics;
use Storable qw(dclone);
use List::Util qw[min max];
use Time::HiRes qw( time );
use warnings FATAL => 'all';
use Term::ANSIColor qw(:constants);
use Term::ANSIColor 2.00 qw(:pushpop);

my $cur_dir = Cwd::cwd();
push @INC, $cur_dir;
require janus_pack;

my $the_tech = 2;
my $the_verb = 2;
my $file_pla = "";
my $ulb_diff = 31;
my $sat_limit = 1200;
my $cpu_limit = 21600;

my $arg_ok = 1;
my $arg_cnt = 0;
while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
      last;
    }
    else{
      if (index($ARGV[$arg_cnt], "-verb=") != -1){
        $the_verb = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_verb < 0 or $the_verb > 2){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-cpu_lim=") != -1){
        $cpu_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9) + 0.0;
      }
      elsif (index($ARGV[$arg_cnt], "-sat_lim=") != -1){
        $sat_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9) + 0.0;
      }
      elsif (index($ARGV[$arg_cnt], "-tech=") != -1){
        $the_tech = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_tech < 0 or $the_tech > 3){
          $arg_ok = 0;
          last;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-ulbd=") != -1){
        $ulb_diff = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
      }
      else{
        if (!$arg_cnt){
          $file_pla = $ARGV[0];
        }
        else{
          $arg_ok = 0;
          last;
        }
      }
    }
  }
  else{
    if (!$arg_cnt){
      $arg_ok = 0;
    }
    last;
  }

  $arg_cnt++;
}

if ($arg_ok){
  if ($file_pla ne ""){
    main_part();
  }
  else{
    help_part();
  }
}
else{
  help_part();
}

sub help_part{
  print "######################################################################################################################################################## \n";
  print "# Usage:       perl janus_dc.pl <File_Name> -verb=0/1/2/3 -cpu_lim=<int> -sat_lim=<int> -tech=<int> -ulbd=<int>                                        # \n";
  print "# File_Name:   Name of the file including a single target function given in PLA format                                                                 # \n";
  print "# -verb:       Level of verbosity (0: full, 1: medium, 2: none), by default it is none                                                                 # \n";
  print "# -cpu_lim:    CPU time limit in seconds, by default it is 21600                                                                                       # \n";
  print "# -sat_lim:    CPU time limit for the SAT algorithm in seconds, by default it is 1200                                                                  # \n";
  print "# -tech:       The divide&conquer technique, by default it is 2                                                                                        # \n";
  print "#                0: Separate the partial products in two parts where the first one has the minimum number of inputs                                    # \n";
  print "#                1: Recursively separate the partial products in two parts based on the upper and lower bounds, given ulbd value                       # \n";
  print "#                2: Separate the partial products in two parts where the number of products is almost the same and number of literals is minimum (ILP) # \n";
  print "#                3: Recursively separate the partial products in two parts based as done when tech=2 on the upper and lower bounds, given ulbd value   # \n";
  print "# -ubld:       Difference between the upper and lower bounds when -tech=1/3, by default it is 31                                                       # \n";
  print "# Description: Finds the realization of a single logic function in a lattice including four-terminal switches # \n";
  print "######################################################################################################################################################## \n";
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      return $the_offset;
    }
  }

  return $the_offset;
}

sub skip_spaces_backward{
  my ($the_string, $the_offset) = @_;

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset--;
    if ($the_offset < 0) {
      last;
    }
  }

  return $the_offset;
}

sub is_inside_numeric_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] == $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub remove_dontcare_inputs{
  my ($file_simp) = @_;
  
  my $in_num = 0;
  my $out_num = 0;
  my $prod_num = 0;

  my @in_arr = ();
  my @out_arr = ();
  my @prod_arr = ();

  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  my $ndc_in_cnt;
  my @ndc_in_arr;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $in_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $out_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $in_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_cnt++;
          $in_arr[$in_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $out_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_cnt++;
          $out_arr[$out_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".") == -1){
        $prod_num++;

        my $in_cnt = 0;
        $the_index = skip_spaces_forward($the_line, 0);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $in_cnt++;
          $prod_arr[$in_cnt][$prod_num] = $the_char;
          $the_index++;

          if ($in_cnt == $in_num){
            last;
          }
        }

        my $out_cnt = 0;
        $the_index = skip_spaces_forward($the_line, $the_index);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $out_cnt++;
          $prod_arr[$in_num+$out_cnt][$prod_num] = substr($the_line, $the_index , 1);
          $the_index++;

          if ($out_cnt == $out_num){
            last;
          }
        }
      }
    }
    
    close $file_header;

    if (!(@in_arr)){
      foreach my $i (1 .. $in_num){
        $in_arr[$i] = $i;
      }
    }

    #Check if an input variable is DC
    my $dcin_cnt = 0;
    my @dcin_arr = ();
    foreach my $i (1 .. $in_num){
      my $is_dcin = 1;
      foreach my $j (1 .. $prod_num){
        if ($prod_arr[$i][$j] eq "0" or $prod_arr[$i][$j] eq "1"){
          $is_dcin = 0;
          last;
        }
      }

      if ($is_dcin){
        #print "[INFO] The $in_arr[$i] input is always DC and hence, is removed from the input list \n";
        $dcin_cnt++;
        $dcin_arr[$dcin_cnt] = $i;
      }
    }

    if ($dcin_cnt){
      $ndc_in_cnt = 0;
      @ndc_in_arr = ();

      open (my $fid_pla, '>', $file_simp);
      printf $fid_pla ".i %0d \n", $in_num - $dcin_cnt;
      printf $fid_pla ".o %0d \n", $out_num;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_num){
          if (!is_inside_numeric_array($i, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s ", $in_arr[$i];

            $ndc_in_cnt++;
            $ndc_in_arr[$ndc_in_cnt] = $in_arr[$i];
          }
        }
        printf $fid_pla "\n";
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_num){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".p %0d \n", $prod_num;
      foreach my $i (1 .. $prod_num){
        foreach my $j (1 .. $in_num){
          if (!is_inside_numeric_array($j, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s", $prod_arr[$j][$i];
          }
        }
        printf $fid_pla " ";
        foreach my $j (1 .. $out_num){
          printf $fid_pla "%0s", $prod_arr[$in_num+$j][$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".e \n";
      close ($fid_pla);
    }
    else{
      $ndc_in_cnt = $in_num;
      @ndc_in_arr = @in_arr;
    }

  }
  else{
    print RED, "Could not open the $file_simp file \n", RESET;
  }

  return ($ndc_in_cnt, @ndc_in_arr);
}

sub simplify_sop{
  my ($file_dir, $file_main, $the_file, $path_espresso) = @_;
  #print "The file: $the_file \n";

  my $in_cnt = 0;
  my $in_say = 0;
  my $out_cnt = 0;
  my $out_say = 0;
  my @in_arr = ();
  my @out_arr = ();
  
  my $deg_simp = 0;
  my $prod_simp = 0;
  my $mindeg_simp = 0;
  my $prod_cnt_simp = 0;
  my @prod_num_simp = ();
  my @prod_lvl_simp = ();
  my @prod_ind_simp = ();
  my @prod_arr_simp = ();
  
  my $init_index = 0;
  my $last_index = 0;

  my $file_simp = $file_main . "_simp.pla";

  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $prod_cnt = 0;
    my @prod_arr = ();
    my $minreq_cnt = 0;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $minreq_cnt++;
        $in_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $minreq_cnt++;
        $out_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_say++;
          $in_arr[$in_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($in_cnt and $in_say != $in_cnt){
          print RED, "[ERROR] The number of inputs is not the same as the number of input labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_say++;
          $out_arr[$out_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($out_cnt and $out_say != $out_cnt){
          print RED, "[ERROR] The number of outputs is not the same as the number of output labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".") == -1){
        if ($minreq_cnt < 2){
          $prod_cnt++;
          $prod_arr[$prod_cnt] = $the_line;
        }
      }
    }

    close $file_header;

    if ($minreq_cnt < 2){
      my $init_index = skip_spaces_forward($prod_arr[1], 0);
      my $last_index = index($prod_arr[1], " ", $init_index);
      $in_cnt = $last_index - $init_index;

      $last_index = skip_spaces_forward($prod_arr[1], $last_index);
      while (substr($prod_arr[1], $last_index, 1) ne " "){
        $last_index++;
        $out_cnt++;

        if ($last_index >= length($prod_arr[1])){
          last;
        }
      }

      my $file_temp = $file_dir . "temp_file.pla";
      open (my $fid_pla, '>', $file_temp);
      printf $fid_pla ".i %0s \n", $in_cnt;
      printf $fid_pla ".o %0s \n", $out_cnt;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_say){
          printf $fid_pla "%0s ", $in_arr[$i];
        }
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_say){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
      }
      printf $fid_pla ".p %0s \n", $prod_cnt;
      foreach my $i (1 .. $prod_cnt){
        printf $fid_pla "%0s \n", $prod_arr[$i];
      }
      printf $fid_pla ".e \n";
      close $fid_pla;

      my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_simp;
      system($the_cmd);
    }
    else{
      my $the_cmd = $path_espresso . " -Dexact " . $the_file . " > " . $file_simp;
      system($the_cmd);
    }

    if (!@in_arr){
      foreach my $i (1 .. $in_cnt){
        $in_arr[$i] = "$i";
      }
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
    return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, \@in_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp);
  }

  ($in_cnt, @in_arr) = remove_dontcare_inputs($file_simp);

  #Generating the initial literal index array
  my @lit_index_arr = ();
  foreach my $i (1 .. 2*$in_cnt){
    $lit_index_arr[$i] = 0;
  }

  #Find the degree for the upper bound and generate the truth table
  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".p ") != -1){
        my $the_index = 3;
        $prod_simp = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;

        if (!$prod_simp){
          $in_cnt = 0;
          print RED, "[INFO] The number of products in the simplified target function is zero. No need to run the lattice synthesis algorithm! \n", RESET;
          return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, \@in_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp);
        }
      }
      elsif (index($the_line, ".") == -1){
        my $lit_num = 0;
        $prod_cnt_simp++;
        my $the_index = -1;
        my $the_char = " ";
            
        do{
          $the_index++;
          $the_char = substr($the_line, $the_index, 1);
          if ($the_char eq "0"){
            $lit_num++;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = "!" . $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = -1;

            $lit_index_arr[2*($the_index+1)]++;
          }
          elsif ($the_char eq "1"){ 
            $lit_num++;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 1;
            
            $lit_index_arr[2*($the_index+1)-1]++;
          }
          elsif ($the_char eq "-"){
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 0;
          }
        }while ($the_char ne " ");

        if (defined $prod_num_simp[$lit_num]){
          $prod_num_simp[$lit_num]++;
        }
        else{
          $prod_num_simp[$lit_num] = 1;
        }

        if ($lit_num > $deg_simp){
          $deg_simp = $lit_num;
        }
      }
    }

    close $file_header;
  }
  else{
    $in_cnt = 0;
    print RED, "[ERROR] Could not open the $file_simp file! \n", RESET;
    return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, \@in_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp);
  }

  #Find the minimum degree for the lower bound in a recursive fashion
  my $file_prim = $file_main . "_simp_prim.pla";
  my $the_cmd = $path_espresso . " -Dprimes " . $file_simp . " > " . $file_prim;
  system($the_cmd);
  
  while (1) {
    my $max_deg = 0;
    my $min_deg = 9*9*9;

    my @lit_mat = ();
    my $prim_cnt = 0;
    my @prim_arr = ();
    my $maxprim_cnt = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".") == -1){
          my $lit_num = 0;
          my $the_index = -1;
          my $the_char = " ";

          $prim_cnt++;
          $prim_arr[$prim_cnt] = $the_line;

          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0" or $the_char eq "1"){
              $lit_num++;
            }
          }while ($the_char ne " ");

          $lit_mat[$prim_cnt] = $lit_num;

          if ($lit_num > $max_deg){
            $max_deg = $lit_num;
            $maxprim_cnt = 1;
          }
          elsif ($lit_num == $max_deg){
            $maxprim_cnt++;
          }
          
          if ($lit_num < $min_deg){
            $min_deg = $lit_num;
          }
        }
      }
      close $file_header;

      #print "Minimum number of literals: $min_deg \n";
      #print "Maximum number of literals: $max_deg \n";

      if ($min_deg < $max_deg){
        my $file_temp = $file_dir . "temp_file.pla";
        open (my $fid_temp, '>', $file_temp);
        foreach my $i (1 .. $prim_cnt){
          if ($lit_mat[$i] != $max_deg){
            printf $fid_temp "%0s \n", $prim_arr[$i];
          }
        }
        close $fid_temp;

        my $file_verify = $file_dir . "verify.out";
        my $the_cmd = $path_espresso . " -Dverify " . $file_simp . " " . $file_temp . " > " . $file_verify;
        system($the_cmd);

        my $is_verified = 0;
        if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, "compared equal") != -1){
              $is_verified = 1;
              last;
            }
          }

          if (!$is_verified){
            $mindeg_simp = $max_deg;
            last;
          }
          else{
            open (my $fid_prim, '>', $file_prim);
            printf $fid_prim ".i %0d \n", $in_cnt;
            printf $fid_prim ".o %0d \n", $out_cnt;
            printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
            foreach my $i (1 .. $prim_cnt){
              if ($lit_mat[$i] != $max_deg){
                printf $fid_prim "%0s \n", $prim_arr[$i];
              }
            }
            printf $fid_prim ".e \n";
            close $fid_prim;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
        }
      }
      else{
        $mindeg_simp = $max_deg;
        last;
      }
    }
    else{
      $in_cnt = 0;
      print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
      return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, \@in_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp);
    }
  }

  return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, \@in_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp);
}

sub find_dual{
  my ($file_dir, $file_main, $the_file, $path_espresso, $in_cnt, $out_cnt, $in_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};

  my $deg_num = 0;
  my $prod_cnt = 0;
  my @prod_lvl = ();
  my @prod_ind = ();
  my @prod_arr = ();
  my $mindeg_num = 0;
  my @prod_num_dual = ();
  
  my $file_dual = $file_main . "_dual.pla";

  #Generating the dual pla file by complementing each variable and the output function
  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_out, '>', $file_temp);
  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $first_prod = 1;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      
      my $the_char = "";
      my $the_index = 0;
     
      if (index($the_line, ".") == -1){
        #Complementing the output function
        if ($first_prod){
          printf $fid_out ".phase 0 \n";
          $first_prod = 0;
        }

        #Complementing the variable
        $the_index = skip_spaces_forward($the_line, $the_index);
        do {
          $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq "1"){
            printf $fid_out "0";
          }
          elsif ($the_char eq "0"){
            printf $fid_out "1";
          }
          elsif ($the_char eq "-" or $the_char eq " "){
            printf $fid_out "%0s", $the_char;
          }
          else{
            print "[WARNING] Only expecting 0 1 or - in this case. Something must be wrong! \n";
          }
          $the_index++;
        }while ($the_char ne " ");

        printf $fid_out "%0s \n", substr($the_line, $the_index, length($the_line)-$the_index+1);
      }
      else{
        printf $fid_out "%s \n", $the_line;
      }
    }

    close $file_header;
    close $fid_out;
    
    #Find the dual function with espresso
    my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_dual;
    system($the_cmd);

    #Compute the degree of the dual function for the upper bound, determine the literals, and generate the truth table.
    if (open (my $file_header, '<:encoding(UTF-8)', $file_dual)){
      my $prod_num = 0;
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".p ") != -1){
          my $the_index = 3;
          $prod_cnt = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
        }
        elsif (index($the_line, ".") == -1){ 
          $prod_num++;
          my $lit_cnt = 0;
          my $the_index = -1;
          my $the_char = " ";
          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0"){ 
              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = "!" . $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = -1;
            }
            elsif ($the_char eq "1"){
              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = 1;
            }
            elsif ($the_char eq "-") {
              $prod_ind[$the_index+1][$prod_num] = 0;
            }
          }while ($the_char ne " ");

          if (defined $prod_num_dual[$lit_cnt]){
            $prod_num_dual[$lit_cnt]++;
          }
          else{
            $prod_num_dual[$lit_cnt] = 1;
          }

          if ($lit_cnt > $deg_num){
            $deg_num = $lit_cnt;
          }
        }
      }
      close $file_header;

      #Compute the minimum degree for the lower bound in a recursive fashion
      my $file_prim = $file_main . "_dual_prim.pla";
      $the_cmd = $path_espresso . " -Dprimes " . $file_dual . " > " . $file_prim;
      system($the_cmd);
      
      while (1) {
        my $max_deg = 0;
        my $min_deg = 9*9*9;

        my @lit_arr = ();
        my $prim_cnt = 0;
        my @prim_arr = ();
        my $maxprim_cnt = 0;

        if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, ".") == -1){
              my $lit_cnt = 0;
              my $the_index = -1;
              my $the_char = " ";

              $prim_cnt++;
              $prim_arr[$prim_cnt] = $the_line;

              do{
                $the_index++;
                $the_char = substr($the_line, $the_index, 1);
                if ($the_char eq "0" or $the_char eq "1"){
                  $lit_cnt++;
                }
              }while ($the_char ne " ");

              $lit_arr[$prim_cnt] = $lit_cnt;

              if ($lit_cnt > $max_deg){
                $max_deg = $lit_cnt;
                $maxprim_cnt = 1;
              }
              elsif ($lit_cnt == $max_deg){
                $maxprim_cnt++;
              }
              
              if ($lit_cnt < $min_deg){
                $min_deg = $lit_cnt;
              }
            }
          }
          close $file_header;

          #print "Minimum number of literals: $min_deg \n";
          #print "Maximum number of literals: $max_deg \n";

          if ($min_deg < $max_deg){
            my $file_temp = $file_dir . "temp_file.pla";
            open (my $fid_temp, '>', $file_temp);
            foreach my $i (1 .. $prim_cnt){
              if ($lit_arr[$i] != $max_deg){
                printf $fid_temp "%0s \n", $prim_arr[$i];
              }
            }
            close $fid_temp;

            my $file_verify = $file_dir . "verify.out";
            $the_cmd = $path_espresso . " -Dverify " . $file_dual . " " . $file_temp . " > " . $file_verify;
            system($the_cmd);

            my $is_verified = 0;
            if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
              while (my $the_line = <$file_header>){
                chomp $the_line;

                if (index($the_line, "compared equal") != -1){
                  $is_verified = 1;
                  last;
                }
              }

              if (!$is_verified){
                $mindeg_num = $max_deg;
                last;
              }
              else{
                open (my $fid_prim, '>', $file_prim);
                printf $fid_prim ".i %0d \n", $in_cnt;
                printf $fid_prim ".o %0d \n", $out_cnt;
                printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
                foreach my $i (1 .. $prim_cnt){
                  if ($lit_arr[$i] != $max_deg){
                    printf $fid_prim "%0s \n", $prim_arr[$i];
                  }
                }
                printf $fid_prim ".e \n";
                close $fid_prim;
              }
            }
            else{
              print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
            }
          }
          else{
            $mindeg_num = $max_deg;
            last;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
        }
      }
    }
    else{
      print RED, "[ERROR] Could not open the $file_dual file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
  }

  return ($file_dual, $prod_cnt, $deg_num, $mindeg_num, \@prod_num_dual, \@prod_lvl, \@prod_arr, \@prod_ind);
}

sub extract_paths{
  my ($paths_file) = @_;

  my $path_espresso = " ";
  my $path_ilp = " ";
  my $path_sat = " ";
  my $paths_ok = 1;

  if (-e $paths_file){
    my $the_index = 0;
    my $init_index = 0;
    my $last_index = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $paths_file)){
      while (my $the_line = <$file_header>){
        chomp $the_line;
        #print "$the_line \n";

        $the_index = index ($the_line, "=");

        if ($the_index >= 0){
          $init_index = skip_spaces_forward($the_line, 0);
          $last_index = skip_spaces_backward($the_line, $the_index-1);
          my $the_solver = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_solver: $the_solver \n";

          $init_index = skip_spaces_forward($the_line, $the_index+1);
          $last_index = skip_spaces_backward($the_line, length($the_line));
          my $the_path = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_path: $the_path \n";

          if ($the_path =~ /[0-9a-zA-Z_]/ ){
            if ($the_solver eq "espresso"){
              $path_espresso = $the_path;
            }
            elsif ($the_solver eq "ilp"){
              $path_ilp = $the_path;
            }
            elsif ($the_solver eq "sat"){
              $path_sat = $the_path;
            }
          }
          else{
            $paths_ok = 0;
          }
        }
      }

      if ($path_espresso eq " ") {
        $paths_ok = 0;
        print RED, "[ERROR] The path to the espresso could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_espresso: $path_espresso \n";
      #}
      if ($path_ilp eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the ILP solver could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_ilp: $path_ilp \n";
      #}
      if ($path_sat eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the SAT solver could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_sat: $path_sat \n";
      #}

      close ($file_header);
    }
    else{
      print RED, "[ERROR] Could not open the $paths_file file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not find the file including paths to solvers! \n", RESET;
  }

  return ($paths_ok, $path_espresso, $path_ilp, $path_sat);
}
sub extract_lattice_product_info{
  my ($file_lattice) = @_;

  my $lat_deg = 0;
  my $prod_cnt = 0;
  my @lat_prod_num = ();

  my $init_index = 0;
  my $last_index = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_lattice)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      if (substr($the_line, 0, 1) eq "#"){
        $init_index = index($the_line, "with ");
        if ($init_index != -1){
          $init_index = skip_spaces_forward($the_line, $init_index+4);
          
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= length($the_line)){
              print RED, "[ERROR] There must be something wrong here! \n", RESET;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
          if ($the_var > $lat_deg){
            $lat_deg = $the_var;
          }

          $init_index = index($the_line, ": ");
          if ($init_index != -1){
            $init_index = skip_spaces_forward($the_line, $init_index+1);

            my $the_num = substr($the_line, $init_index, length($the_line)-$init_index) + 0.0;
            $lat_prod_num[$the_var] = $the_num;
            $prod_cnt += $the_num;
          }
        }
      }
    }
    close ($file_header);
  }
  else{
    print RED, "[ERROR] Could not open the $file_lattice file! \n", RESET;
  }
  
  return ($prod_cnt, $lat_deg, \@lat_prod_num);
}

sub is_function_synthesizable{
  my ($prod_cnt, $fun_deg, $prod_num_ref, $lat_prod_cnt, $lat_deg, $lat_prod_num_ref) = @_;
  my @prod_num = @ {$prod_num_ref};
  my @lat_prod_num = @ {$lat_prod_num_ref};

  my $the_value = 1;

  foreach my $i (1 .. $fun_deg){
    if (defined $prod_num[$i]){
      my $the_point = $i;
      my $the_sum = $prod_num[$i];
      
      while (1){
        if (defined $lat_prod_num[$the_point]){
          if ($lat_prod_num[$the_point] >= $the_sum){
            $lat_prod_num[$the_point] = $lat_prod_num[$the_point] - $the_sum;
            $the_sum = 0;
          }
          else{
            $the_sum = $the_sum - $lat_prod_num[$the_point];
            $lat_prod_num[$the_point] = 0;
          }
        }

        $the_point++;
        if ($the_point > $lat_deg or !$the_sum){
          last;
        }
      }
      
      if ($the_sum){
        $the_value = 0;
        last;
      }
    }
  }

  return ($the_value);
}

sub determine_lower_bound{
  my ($prod_simp, $prod_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref) = @_;

  my $lb_col = 1;
  if ($prod_simp > 1){
    $lb_col = 2;
  }
  if ($mindeg_dual > 2){
    $lb_col = 3;
  }

  my $lb_row = 3;
  if ($mindeg_simp == 2){
    $lb_row = 2;
  }
  elsif ($mindeg_simp == 1){
    $lb_row = 1;
  }

  my $the_lb = 1;
  my $the_end = 0;
  while (1){
    $the_lb++;

    for (my $the_row = 1; $the_row <= $the_lb; $the_row++){
      if (!($the_lb % $the_row)){
        my $the_col = $the_lb/$the_row;

        if ($the_row >= $lb_row and $the_col >= $lb_col){
          my $lat_str = $the_row . "x" . $the_col;
          my $file_lattice = "l" . $lat_str . ".eqn";
          if (!(-e $file_lattice)){
            my $the_cmd = "perl genlatfunc_rec.pl -r=" . $the_row . "  -c=" . $the_col;
            if ($the_verb < 1){print "[INFO] The $lat_str lattice equation (4-terminal) cannot be found! Generating...\n";}
            system($the_cmd);
          }
          my ($lat_prod_simp, $lat_deg_simp, $lat_prod_num_simp_ref) = extract_lattice_product_info($file_lattice);
          
          my $file_dual = "d" . $lat_str . ".eqn";
          if (!(-e $file_dual)){
            my $the_cmd = "perl genlatfunc_dual_rec.pl -r=" . $the_row . "  -c=" . $the_col;
            if ($the_verb < 1){print "[INFO] The dual of $lat_str lattice equation (8-terminal) cannot be found! Generating...\n";}
            system($the_cmd);
          }
          my ($lat_prod_dual, $lat_deg_dual, $lat_prod_num_dual_ref) = extract_lattice_product_info($file_dual);
         
          #print "[INFO] Checking the lower bound for the $lat_str lattice... \n";
          if (is_function_synthesizable($prod_simp, $deg_simp, $prod_num_simp_ref, $lat_prod_simp, $lat_deg_simp, $lat_prod_num_simp_ref)){
            if (is_function_synthesizable($prod_dual, $deg_dual, $prod_num_dual_ref, $lat_prod_dual, $lat_deg_dual, $lat_prod_num_dual_ref)){
              $the_end = 1;
              last;
            }
          }
        }
      }
    }

    if ($the_end){
      last;
    }
  }

  return ($the_lb);
}

sub determine_upper_bound{
  my ($prod_simp, $prod_dual, $deg_simp, $deg_dual) = @_;

  my $the_ub = 0;

  my $ub_one = $prod_simp * $prod_dual;
  #print "[INFO] The first upper bound: $ub_one \n";
  
  my $ub_two = $deg_simp * (2*$prod_simp-1);
  #print "[INFO] The second upper bound: $ub_two \n";

  my $ub_three = $deg_dual * (2*$prod_dual-1);
  #print "[INFO] The third upper bound: $ub_three \n";
  
  if ($ub_one < $ub_two and $ub_one < $ub_three){
    $the_ub = $ub_one;
  }
  elsif ($ub_two < $ub_one and $ub_two < $ub_three){
    $the_ub = $ub_two;
  }
  else{
    $the_ub = $ub_three;
  }

  return ($the_ub);
}

sub file_write_pla{
  my ($file_part, $prod_cnt, $in_num, $in_arr_ref, $prod_ind_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  open (my $fid_part, '>', $file_part);
  printf $fid_part ".i %0d \n", $in_num;
  printf $fid_part ".o 1 \n";
  printf $fid_part ".ilb ";
  foreach my $i (1 .. $in_num){
    printf $fid_part "%0s ", $in_arr[$i];
  }
  printf $fid_part "\n";
  printf $fid_part ".ob f \n";
  printf $fid_part ".p %0d \n", $prod_cnt;
  foreach my $i (1 .. $prod_cnt){
    foreach my $j (1 .. $in_num){
      if ($prod_ind[$j][$i] == 0){
        printf $fid_part "-";
      }
      elsif ($prod_ind[$j][$i] == 1){
        printf $fid_part "1";
      }
      elsif ($prod_ind[$j][$i] == -1){
        printf $fid_part "0";
      }
    }
    printf $fid_part " 1 \n";
  }
  printf $fid_part ".e \n";
  close $fid_part;
}

sub file_read_ilp_solution{
  my ($file_dir, $prod_num, $first_prodvar) = @_;
  
  my $the_index = 0;
  my $first_cnt = 0;
  my $init_index = 0;
  my $last_index = 0;
  my @prod_first_list = ();

  my $file_sol = $file_dir . "ilp_problem.sol";

  foreach my $i (1 .. $prod_num){
    $prod_first_list[$i] = 0;
  }

  my $sol_found = 0;
  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (my $the_line = <$file_header>){
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      if (index($the_line, "objective value: ") != -1){
        while (1){
          my $the_line = <$file_header>;
          chomp $the_line;

          my $var_index = index($the_line, "x");

          if ($var_index != -1){
            $sol_found = 1;
            $init_index = skip_spaces_forward($the_line, $var_index+1);
            $last_index = $init_index;
            while (substr($the_line, $last_index, 1) ne " "){
              $last_index++;
            }

            my $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;

            if ($the_var >= $first_prodvar){
              if (($the_var - $first_prodvar) % 2 == 0){
                $first_cnt++;
                $the_index = ($the_var - $first_prodvar) / 2 + 1;
                $prod_first_list[$the_index] = 1;
              }
            }
          }
          else{
            last;
          }
        }
      }
      if ($sol_found){
        last;
      }
    }
    close ($file_header);
  }
  else{
    print RED "[ERROR] Could not open the ilp_problem.sol file! \n", RESET;
  }

  return ($first_cnt, @prod_first_list);
}

sub file_write_partition_pla{
  my ($file_main, $part_cnt, $in_num, $prod_num, $first_cnt, $part_arr_ref, $in_arr_ref, $prod_ind_ref, $prod_first_list_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @part_arr = @ {$part_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};
  my @prod_first_list = @ {$prod_first_list_ref};

  foreach my $the_part (1 .. $part_cnt){
    my $file_part = $file_main . "_part" . $part_arr[$the_part] . ".pla";

    open (my $fid_part, '>', $file_part);
    printf $fid_part ".i %0d \n", $in_num;
    printf $fid_part ".o 1 \n";
    printf $fid_part ".ilb ";
    foreach my $i (1 .. $in_num){
      printf $fid_part "%0s ", $in_arr[$i];
    }
    printf $fid_part "\n";
    printf $fid_part ".ob f \n";
    if ($the_part == 1){
      printf $fid_part ".p %0d \n", $first_cnt;
    }
    else{
      printf $fid_part ".p %0d \n", $prod_num - $first_cnt;
    }
    foreach my $i (1 .. $prod_num){
      if (($the_part == 1 and $prod_first_list[$i]) or ($the_part == 2 and !$prod_first_list[$i])){
        foreach my $j (1 .. $in_num){
          if ($prod_ind[$j][$i] == 0){
            printf $fid_part "-";
          }
          elsif ($prod_ind[$j][$i] == 1){
            printf $fid_part "1";
          }
          elsif ($prod_ind[$j][$i] == -1){
            printf $fid_part "0";
          }
        }
        printf $fid_part " 1 \n";
      }
    }
    printf $fid_part ".e \n";
    close $fid_part;
  }
}

sub solve_separation_problem_ilp{
  my ($file_dir, $file_main, $path_ilp, $prod_num, $in_num, $out_num, $in_arr_ref, $prod_ind_ref, $part_cnt, $part_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @part_arr = @ {$part_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  my $first_cnt = 0;
  my @prod_first_list = ();

  if ($prod_num > 1){
    my $con_cnt = 0;
    my $var_cnt = 0;
    my $optvar_cnt = 0;
    my $min_func = "min: ";
    
    my $file_opb = $file_dir . "ilp_problem.opb";
    my $file_var = $file_dir . "ilp_problem.var";

    open (my $fid_opb, '>', $file_opb);
    open (my $fid_var, '>', $file_var);

    #Generating the objective function and optimization variables
    my $first_optvar = 1;
    foreach my $in_var (1 .. $in_num){
      foreach my $the_stat (0 .. 1){
        foreach my $the_part (1 .. 2){
          $var_cnt++;
          $optvar_cnt++;
          $min_func = $min_func . "+1 x" . $var_cnt . " ";
          printf $fid_var "%0d = in%0d_stat%0d_part%0d \n", $var_cnt, $in_var, $the_stat, $the_part;
        }
      }
    }

    printf $fid_opb "%0s; \n", $min_func;
    
    #Generating the product related variables
    my $first_prodvar = $var_cnt+1;
    foreach my $prod_var (1 .. $prod_num){
      foreach my $the_part (1 .. 2){
        $var_cnt++;
        printf $fid_var "%0d = prod%0d_part%0d \n", $var_cnt, $prod_var, $the_part;
      }
    }

    #Generating the constraints indicating that each product must be in partition 1 or 2
    foreach my $prod_var (1 .. $prod_num){
      my $pos_cnf = "";
      my $neg_cnf = "";

      foreach my $the_part (1 .. 2){
        my $the_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;
        $pos_cnf = $pos_cnf . "+1 x" . $the_index . " ";
        $neg_cnf = $neg_cnf . "-1 x" . $the_index . " ";
      }

      $con_cnt++;
      $con_cnt++;
      printf $fid_opb "%0s>= 1; \n", $pos_cnf;
      printf $fid_opb "%0s>= -1; \n", $neg_cnf;
    }

    #Generating the constraints indicating that in partition 1 and 2 there must be at least prod_cnt_limit products
    my $prod_cnt_limit = int ($prod_num / 2);
    #my $prod_cnt_limit = int ($prod_num / 2) - 1;
    foreach my $the_part (1 ..2){
      my $the_cnf = "";
      foreach my $prod_var (1 .. $prod_num){
        my $the_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;
        $the_cnf = $the_cnf . "+1 x" . $the_index . " ";
      }
      
      $con_cnt++;
      printf $fid_opb "%0s>= %0d; \n", $the_cnf, $prod_cnt_limit;
    }

    #Generating the constraints indicating that when a product is selected for a partition its variables are also selected for that partition
    foreach my $the_part (1 .. 2){
      foreach my $prod_var (1 .. $prod_num){
        foreach my $in_var (1 .. $in_num){
          if ($prod_ind[$in_var][$prod_var] == -1){
            my $in_index = $first_optvar + 4*($in_var-1) + $the_part - 1;
            my $prod_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;

            $con_cnt++;
            printf $fid_opb "-1 x%0d +1 x%0d >= 0; \n", $prod_index, $in_index;
          }
          elsif ($prod_ind[$in_var][$prod_var] == 1){
            my $in_index = $first_optvar + 4*($in_var-1) + $the_part + 1;
            my $prod_index = $first_prodvar + 2*($prod_var-1) + $the_part - 1;

            $con_cnt++;
            printf $fid_opb "-1 x%0d +1 x%0d >= 0; \n", $prod_index, $in_index;
          }
        }
      }
    }

    close ($fid_opb);
    close ($fid_var);

    #print "[INFO] #variables: $var_cnt #constraints: $con_cnt #optimization variables: $optvar_cnt \n";

    my $file_sol = $file_dir . "ilp_problem.sol";
    my $the_cmd = $path_ilp . " -f $file_opb >  $file_sol";
    system ($the_cmd);

    ($first_cnt, @prod_first_list) = file_read_ilp_solution($file_dir, $prod_num, $first_prodvar);
  }
  elsif ($prod_num == 1){
    $first_cnt = 1;
    $prod_first_list[1] = 1;
  }

  file_write_partition_pla($file_main, $part_cnt, $in_num, $prod_num, $first_cnt, \@part_arr, \@in_arr, \@prod_ind, \@prod_first_list);
}

sub divide_and_conquer{
  my ($file_dir, $file_main, $path_espresso, $path_ilp) = @_;

  my $part_cnt = 0;
  my @part_arr = ();

  if ($the_tech == 0){
    #Generates two product lists with almost similar size. The one with the minimum number of variables is added to the first list. Then, the ones that increase the number of variables the smallest are added incrementally till
    #the number of products is equal to the int (prod_cnt/2). The other products are added to the second list.

    my ($file_simp, $prod_cnt, $deg_simp, $mindeg_simp, $in_num, $out_num, $in_arr_ref, $prod_num_ref, $prod_lvl_ref, $prod_arr_ref, $prod_ind_ref) = simplify_sop($file_dir, $file_main, $file_pla, $path_espresso);
    my @in_arr = @ {$in_arr_ref};
    my @prod_lvl = @ {$prod_lvl_ref};
    my @prod_ind = @ {$prod_ind_ref};
    #my @in_arr = @ {$in_arr_ref};
    #my @prod_arr_simp = @ {$prod_arr_simp_ref};
    #my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
    #my @prod_ind_simp = @ {$prod_ind_simp_ref};
    #print "[INFO] Number of inputs: $in_num \n";
    #print "[INFO] Number of outputs: $out_num \n";
    #print "[INFO] Number of products: $prod_cnt_simp \n";
    #print "[INFO] The input array: ";
    #foreach my $i (1 .. $in_num){
    #  print "$in_arr[$i]";
    #}
    #print "\n";
    #print "[INFO] The product array: \n";
    #foreach my $i (1 .. $prod_cnt_simp){
    #  foreach my $j (1 .. $in_num){
    #    print "$prod_ind_simp[$j][$i] ";
    #  }
    #  print "\n";
    #}
    #print "\n";

    my $min_prod = 0;
    my $first_cnt = 0;
    my $min_value = 9**9**9;
    my @prod_first_list = ();
    foreach my $i (1 .. $prod_cnt){
      $prod_first_list[$i] = 0;

      if ($prod_lvl[$i] < $min_value){
        $min_value = $prod_lvl[$i];
        $min_prod = $i;
      }
    }

    $first_cnt++;
    $prod_first_list[$min_prod] = 1;
    #print "[INFO] The $min_prod. product is added to the first list! \n";
    
    my $first_limit = int ($prod_cnt/2);
    
    $part_cnt = 1;
    $part_arr[1] = 1;
    if ($first_limit){
      $part_cnt = 2;
      $part_arr[2] = 2;
    }
    
    while ($first_cnt < $first_limit){
      $min_prod = 0;
      $min_value = 9**9**9;
      foreach my $i (1 .. $prod_cnt){
        if (!$prod_first_list[$i]){
          my $the_value = 0;

          foreach my $j (1 .. $in_num){
            if ($prod_ind[$j][$i]){
              my $not_in_first = 1;
              foreach my $k (1 .. $prod_cnt){
                if ($prod_first_list[$k]){
                  if ($prod_ind[$j][$k]){
                    $not_in_first = 0;
                    last;
                  }
                }
              }

              my $not_in_second = 1;
              foreach my $k (1 .. $prod_cnt){
                if (!$prod_first_list[$k] and $i != $k){
                  if ($prod_ind[$j][$k]){
                    $not_in_second = 0;
                    last;
                  }
                }
              }

              $the_value = $the_value + $not_in_first - $not_in_second;
            }
          }

          if ($the_value < $min_value){
            $min_value = $the_value;
            $min_prod = $i;
          }
        }
      }

      $first_cnt++;
      $prod_first_list[$min_prod] = 1;
      #print "[INFO] The $min_prod. product is added to the first list! \n";
    }

    file_write_partition_pla($file_main, $part_cnt, $in_num, $prod_cnt, $first_cnt, \@part_arr, \@in_arr, \@prod_ind, \@prod_first_list)  
  }
  elsif ($the_tech == 1){
    #Generates product lists with almost similar sizes based on the lower and upper bound on the solution recursively. If the_ub - the_lb > 32, the products in the target function is split into two lists 
    #as done while -tech=0. Note that the lower and upper bounds of the resulting partition have the same condition the associated partial products are split again.

    if($the_verb < 1){print "[INFO] Finding the lower and upper bounds on the target function \n";}
    my ($file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $in_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = simplify_sop($file_dir, $file_main, $file_pla, $path_espresso);
    my @in_arr = @ {$in_arr_ref};
    my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
    my @prod_ind_simp = @ {$prod_ind_simp_ref};
    my ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = find_dual($file_dir, $file_main, $file_simp, $path_espresso, $in_num, $out_num, $in_arr_ref);
    my $the_lb = determine_lower_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref);
    #my $the_ub = $prod_cnt_simp*$prod_cnt_dual;
    my $the_ub = determine_upper_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual);

    $part_cnt++;
    my $part_index=1;
    my $file_part = $file_main . "_part" . $part_cnt . ".pla";
    file_write_pla($file_part, $prod_cnt_simp, $in_num, $in_arr_ref, $prod_ind_simp_ref);

    while ($part_index <= $part_cnt){
      if($the_verb < 1){print BRIGHT_MAGENTA, "[INFO] Lower bound: $the_lb Upper bound: $the_ub \n", RESET;}
      if ($the_ub - $the_lb >= $ulb_diff){
        my $min_prod = 0;
        my $first_cnt = 0;
        my $min_value = 9**9**9;
        my @prod_first_list = ();
        foreach my $i (1 .. $prod_cnt_simp){
          $prod_first_list[$i] = 0;

          if ($prod_lvl_simp[$i] < $min_value){
            $min_value = $prod_lvl_simp[$i];
            $min_prod = $i;
          }
        }

        $first_cnt++;
        $prod_first_list[$min_prod] = 1;
        #print "[INFO] The $min_prod. product is added to the first list! \n";
        
        my $first_limit = int ($prod_cnt_simp/2);
        while ($first_cnt < $first_limit){
          $min_prod = 0;
          $min_value = 9**9**9;
          foreach my $i (1 .. $prod_cnt_simp){
            if (!$prod_first_list[$i]){
              my $the_value = 0;

              foreach my $j (1 .. $in_num){
                if ($prod_ind_simp[$j][$i]){
                  my $not_in_first = 1;
                  foreach my $k (1 .. $prod_cnt_simp){
                    if ($prod_first_list[$k]){
                      if ($prod_ind_simp[$j][$k]){
                        $not_in_first = 0;
                        last;
                      }
                    }
                  }

                  my $not_in_second = 1;
                  foreach my $k (1 .. $prod_cnt_simp){
                    if (!$prod_first_list[$k] and $i != $k){
                      if ($prod_ind_simp[$j][$k]){
                        $not_in_second = 0;
                        last;
                      }
                    }
                  }

                  $the_value = $the_value + $not_in_first - $not_in_second;
                }
              }

              if ($the_value < $min_value){
                $min_value = $the_value;
                $min_prod = $i;
              }
            }
          }

          $first_cnt++;
          $prod_first_list[$min_prod] = 1;
          #print "[INFO] The $min_prod. product is added to the first list! \n";
        }

        foreach my $the_part (1 .. 2){
          my $file_part;
          my $part_label;

          if ($the_part == 1){
            $part_label = $part_index;
          }
          else{
            $part_cnt++;
            $part_label = $part_cnt;
          }

          $file_part = $file_main . "_part" . $part_label . ".pla";

          open (my $fid_part, '>', $file_part);
          printf $fid_part ".i %0d \n", $in_num;
          printf $fid_part ".o 1 \n";
          printf $fid_part ".ilb ";
          foreach my $i (1 .. $in_num){
            printf $fid_part "%0s ", $in_arr[$i];
          }
          printf $fid_part "\n";
          printf $fid_part ".ob f \n";
          if ($the_part == 1){
            printf $fid_part ".p %0d \n", $first_cnt;
          }
          else{
            printf $fid_part ".p %0d \n", $prod_cnt_simp - $first_cnt;
          }
          foreach my $i (1 .. $prod_cnt_simp){
            if (($the_part == 1 and $prod_first_list[$i]) or ($the_part == 2 and !$prod_first_list[$i])){
              foreach my $j (1 .. $in_num){
                if ($prod_ind_simp[$j][$i] == 0){
                  printf $fid_part "-";
                }
                elsif ($prod_ind_simp[$j][$i] == 1){
                  printf $fid_part "1";
                }
                elsif ($prod_ind_simp[$j][$i] == -1){
                  printf $fid_part "0";
                }
              }
              printf $fid_part " 1 \n";
            }
          }
          printf $fid_part ".e \n";
          close $fid_part;
        }
      }
      else{
        $part_index++;
      }

      if ($part_index > $part_cnt){
        last;
      }
      else{
        if($the_verb < 1){print "[INFO] Checking the lower and upper bounds of the $part_index. partition... \n";}
        my $file_part = $file_main . "_part" . $part_index . ".pla";
        ($file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $in_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = simplify_sop($file_dir, $file_main, $file_part, $path_espresso);
        @in_arr = @ {$in_arr_ref};
        @prod_lvl_simp = @ {$prod_lvl_simp_ref};
        @prod_ind_simp = @ {$prod_ind_simp_ref};
        ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = find_dual($file_dir, $file_main, $file_simp, $path_espresso, $in_num, $out_num, $in_arr_ref); 
        $the_lb = determine_lower_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref);
        $the_ub = $prod_cnt_simp*$prod_cnt_dual;
      }
    }
  }
  elsif ($the_tech == 2){
    #Solves the separation of products into two parts using a 0-1 ILP technique such that the resulting sub-functions include similar number of products and minimum number of literals
    my ($file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $in_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = simplify_sop($file_dir, $file_main, $file_pla, $path_espresso);

    $part_cnt = 1;
    $part_arr[1] = 1;
    if ($prod_cnt_simp > 1){
      $part_cnt = 2;
      $part_arr[2] = 2;
    }

    solve_separation_problem_ilp($file_dir, $file_main, $path_ilp, $prod_cnt_simp, $in_num, $out_num, $in_arr_ref, $prod_ind_simp_ref, $part_cnt, \@part_arr);
  }
  elsif ($the_tech == 3){
    #Solves the separation of products into two parts using a 0-1 ILP technique as done when -tech=2. In this cae, the functions are divided into two sub-functions recursively 
    #considering the difference between the lower and upper bounds of the function

    $part_cnt = 1;
    my $part_index=1;
    
    do{
      my ($file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $in_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = simplify_sop($file_dir, $file_main, $file_pla, $path_espresso);
      if($the_verb < 1){print "[INFO] Finding the lower and upper bounds on the target function in the $file_pla file \n";}
      my @in_arr = @ {$in_arr_ref};
      my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
      my @prod_ind_simp = @ {$prod_ind_simp_ref};
      my ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = find_dual($file_dir, $file_main, $file_simp, $path_espresso, $in_num, $out_num, $in_arr_ref);
      my $the_lb = determine_lower_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref);
      my $the_ub = determine_upper_bound($prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual);

      if($the_verb < 1){print BRIGHT_MAGENTA, "[INFO] Lower bound: $the_lb Upper bound: $the_ub \n", RESET;}

      my $file_part = $file_main . "_part" . $part_index . ".pla";
      file_write_pla($file_part, $prod_cnt_simp, $in_num, $in_arr_ref, $prod_ind_simp_ref);

      if ($the_ub - $the_lb >= $ulb_diff){
        $part_arr[1] = $part_index;
        $part_cnt++;
        $part_arr[2] = $part_cnt;

        solve_separation_problem_ilp($file_dir, $file_main, $path_ilp, $prod_cnt_simp, $in_num, $out_num, $in_arr_ref, $prod_ind_simp_ref, 2, \@part_arr);
      }
      else{
        $part_index++;
      }
     
      #Update the PLA file name
      $file_pla = $file_main . "_part" . $part_index . ".pla";
      #print "[INFO] PLA File: $file_pla \n";
      #print "[INFO] part_cnt: $part_cnt \n";
      #print "[INFO] part_index: $part_index \n";
    } while ($part_index <= $part_cnt);
  }

  return ($part_cnt);
}

sub find_lattice_realization{
  my ($the_file, $set_row, $set_col, $path_espresso, $path_sat) = @_;

  janus_pack::janus_func($the_file, $the_verb, $cpu_limit, $sat_limit, $set_row, $set_col, $path_espresso, $path_sat);
}

sub file_read_solution{
  my ($the_file) = @_;

  my $dot_index = index($the_file, ".pla");
  my $file_sol = substr($the_file, 0, $dot_index) . ".sol";
  #print "Solution file: $file_sol \n";

  my $sol_row = 0;
  my $sol_col = 0;
  my @sol_arr = ();
  my $sol_found = 1;

  my $the_row = 0;
  my $the_col = 0;
  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      #sleep 1;

      if (index($the_line, "#") != -1){
        #Extract the best solution
        if (index($the_line, "# Lattice RowxColumn: ") != -1){
          my $the_size = substr($the_line, 22, length($the_line)-22);
          $the_index = index($the_size, "x");
          $sol_row = substr($the_size, 0, $the_index);
          $sol_col = substr($the_size, $the_index+1, length($the_size)-$the_index-1);
        }
      }
      else{
        if (index($the_line, "NO SOLUTION") != -1){
          $sol_found = 0;
        }
        else{
          #Extract the solution matrix
          if (index($the_line, "| ") != -1){
            $the_row++;
            $the_col = 0;
            
            my $init_index = 0;
            while ($the_col != $sol_col){
              while (substr($the_line, $init_index, 1) eq " " or substr($the_line, $init_index, 1) eq "|"){
                $init_index++;
              }
              $last_index = $init_index;
              while (substr($the_line, $last_index, 1) ne " " and substr($the_line, $last_index, 1) ne "|"){
                $last_index++;
              }
              my $sol_entry = substr($the_line, $init_index, $last_index-$init_index);
              #print "sol entry: $sol_entry \n";

              $the_col++;
              $sol_arr[$the_row][$the_col] = $sol_entry;

              $init_index = $last_index;
            }
          }
        }
      }
    }
    close ($file_header);
  }
  else{
    print RED "[ERROR] Could not open the $file_sol file \n", RESET;
  }

  return ($sol_found, $sol_row, $sol_col, @sol_arr);
}

sub merge_solution{
  my ($the_row, $the_col, $sol_row, $sol_col, $the_sol_ref, $sol_arr_ref) = @_;
  my @the_sol = @ {$the_sol_ref};
  my @sol_arr = @ {$sol_arr_ref};

  my $max_row = 0;
  if ($the_row > $sol_row){
    $max_row = $the_row;
  }
  else{
    $max_row = $sol_row;
  }

  if ($sol_row){
    $sol_col++;
    foreach my $i (1 .. $max_row){
      $sol_arr[$i][$sol_col] = "F";
    }

    foreach my $i (1 .. $the_col){
      $sol_col++;
      foreach my $j (1 .. $the_row){
        $sol_arr[$j][$sol_col] = $the_sol[$j][$i];
      }
    }
  }
  else{
    $sol_row = $the_row;
    $sol_col = $the_col;
    @sol_arr = @the_sol;
  }

  return ($max_row, $sol_col, @sol_arr);
}

sub write_solution{
  my ($main_file, $tot_time, $imp_cnt, $sol_row, $sol_col, $sol_arr_ref, $sol_imp_ref) = @_;
  my @sol_arr = @ {$sol_arr_ref};
  my @sol_imp = @ {$sol_imp_ref};

  my $file_sol = $main_file . "_dc_tech_" . $the_tech . ".sol";

  open (my $fid_out, '>', $file_sol);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time); 
  printf $fid_out "# Synthesis of a Single Logic Function with a Lattice of Four-Terminal Switches\n";
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Target Function File: %0s \n", $file_pla;
  printf $fid_out "# Lattice RowxColumn: %0dx%0d \n", $sol_row, $sol_col;
  printf $fid_out "# Size of lattice: %0d \n", $sol_row*$sol_col;
  foreach my $i (1 .. $imp_cnt){
    printf $fid_out "# Realization of the %0s. part lays in between %0d and %0d columns: \n", $sol_imp[$i][1], $sol_imp[$i][2], $sol_imp[$i][3];
  }
  printf $fid_out "# CPU time: %.2f \n", $tot_time;

  if ($sol_row){
    foreach my $i (1 .. $sol_row){
      printf $fid_out "| ";
      foreach my $j (1 .. $sol_col){
        if (defined $sol_arr[$i][$j]){
          if (index($sol_arr[$i][$j], "!") != -1){
            printf $fid_out "%0s | ", $sol_arr[$i][$j];
          }
          else{
            printf $fid_out "%0s  | ", $sol_arr[$i][$j];
          }
        }
        else{
          printf $fid_out "T  | ";
        }
      }
      printf $fid_out "\n";
    }
  }
  else{
    printf $fid_out "NO SOLUTION\n";
  }

  close $fid_out;
}

sub compute_minimum_cost_simp{
  my ($max_row, $part_cnt, @sol_size) = @_;

  my $the_col = 0;
  my $min_cost = 0;
  my @min_col_arr = ();

  #Compute the minimum column that a partition can have
  foreach my $the_part (1 .. $part_cnt){
    if ($sol_size[$the_part][1] == $max_row){
      $min_col_arr[$the_part] = $sol_size[$the_part][2];
      $the_col = $the_col + $sol_size[$the_part][2];
    }
    else{
      my $the_cost = $sol_size[$the_part][1]*$sol_size[$the_part][2];
      my $a_col = 0;
      do {
        $a_col++;
      } 
      while($a_col * $max_row < $the_cost);
      $min_col_arr[$the_part] = $a_col;
      $the_col = $the_col + $a_col;
    }
  }

  #Add the isolation columns
  $the_col = $the_col + $part_cnt - 1;
  $min_cost = $max_row * $the_col;

  return ($min_cost, @min_col_arr);
}

sub main_part{ 
  my $initial_time = time();
  #print ("PLA file: $file_pla \n");
  
  my $file_dir = "";
  my $file_name = "";
  my $leaned_right = index($file_pla, "/");
  my $leaned_left = index($file_pla, "\\");
  if ($leaned_right != -1 or $leaned_left != -1){
    my $pla_index = index($file_pla, ".pla");
    my $dot_index = $pla_index;
    while (substr($file_pla, $pla_index, 1) ne "/" and substr($file_pla, $pla_index, 1) ne "\\"){
      $pla_index--;
    }
    $file_dir = substr($file_pla, 0, $pla_index+1) . "temp";
    $file_name = substr($file_pla, $pla_index+1, $dot_index-$pla_index-1);
  }
  else{
    $file_dir = "temp";
    $file_name = $file_pla;
  }
  if (!(-e $file_dir and -d $file_dir)){
    my $the_cmd = "mkdir " . $file_dir;
    system($the_cmd);
  }
  if ($leaned_right != -1){
    $file_dir = $file_dir . "/";
  }
  else{
    $file_dir = $file_dir . "\\";
  }
  
  my ($paths_ok, $path_espresso, $path_ilp, $path_sat) = extract_paths("paths.pl");
  #print ("Espresso path: $path_espresso \n");
  my $file_main = $file_dir . $file_name;
  my ($part_cnt) = divide_and_conquer($file_dir, $file_main, $path_espresso, $path_ilp);

  my $the_col = 0;
  my $the_row = 0;
  my @the_sol = ();
  my $sol_found = 0;

  my $imp_cnt = 0;
  my $max_row = 0;
  my $sol_row = 0;
  my $sol_col = 0;
  my @sol_arr = ();
  my @sol_imp = ();
  my @sol_size = ();
  my @orig_sol = ();
  my $cpu_expired = 0;

  $imp_cnt = $part_cnt;
  foreach my $the_part (1 .. $part_cnt){
    my $file_part = $file_main . "_part" . $the_part . ".pla";

    #Find the realization of the partitioned partial products
    if($the_verb < 1){print "\n";}
    if($the_verb < 1){print BRIGHT_BLUE "[INFO] Finding the lattice realization on the $the_part. partition... \n", RESET;}
    find_lattice_realization($file_part, 0, 0, $path_espresso, $path_sat);
 
    my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_part);
    my @cloned_sol = @{ dclone(\@the_sol) };
    if ($sol_found){
      $sol_size[$the_part][1] = $the_row;
      $sol_size[$the_part][2] = $the_col;
      $sol_size[$the_part][3] = \@cloned_sol;
      if ($the_row > $max_row){
        $max_row = $the_row;
      }
      ($sol_row, $sol_col, @sol_arr) = merge_solution($the_row, $the_col, $sol_row, $sol_col, \@the_sol, \@sol_arr);
      $sol_imp[$the_part][1] = "$the_part";
      $sol_imp[$the_part][2] = $sol_col-$the_col+1;
      $sol_imp[$the_part][3] = $sol_col;
    }

    if (time() - $initial_time > $cpu_limit){
      $cpu_expired = 1;
      if ($the_part < $part_cnt){
        $imp_cnt = 0;
        $sol_row = 0;
        $sol_col = 0;
        @sol_arr = ();

        foreach my $i (1 .. $part_cnt){
          $sol_imp[$i][1] = "0";
          $sol_imp[$i][2] = 0;
          $sol_imp[$i][3] = 0;
        }
      }
      last;
    }
  }

  if ($cpu_expired){
    print BRIGHT_RED, "[INFO] CPU time has expired! Returning the solution... \n", RESET;
  }
  else{
    if($the_verb < 1){print "\n";}
    my $max_cost = $sol_row*$sol_col; 
    my $sol_lat_str = $sol_row . "x" . $sol_col;
    my $first_part_time = time() - $initial_time;
    if($the_verb < 1){print BRIGHT_BLUE, "[INFO] Initial solution: $sol_lat_str \n", RESET;}
    if($the_verb < 1){print BRIGHT_RED, "[INFO] Initial cost value: $max_cost \n", RESET;}
    if($the_verb < 1){print BRIGHT_CYAN, "[INFO] First part CPU time: $first_part_time \n", RESET;}
    if($the_verb < 1){print "\n";}

    @orig_sol = @{ dclone(\@sol_size) };
 
    while ($max_row >= 3 and !$cpu_expired){
      my $temp_row = 0;
      my $temp_col = 0;
      my @temp_sol = ();
      my @temp_imp = ();

      my ($min_cost, @min_col_arr) = compute_minimum_cost_simp($max_row, $part_cnt, @orig_sol);
      #print "max_row: $max_row \n";
      #print "min_cost: $min_cost \n";
      #sleep 1;

      if ($min_cost < $max_cost){
        my $cost_exceeded = 0;

        foreach my $the_part (1 .. $part_cnt){
          my $the_row = $max_row;
          my $file_part = $file_main . "_part" . $the_part . ".pla";

          if ($orig_sol[$the_part][1] < $max_row){
            if ($orig_sol[$the_part][2] > 2){
              my $orig_col = $orig_sol[$the_part][2];
              my $sol_improved = 0;
              while (1){
                $orig_col--;
                if ($orig_col > 1){
                  if ($max_row*$orig_col >= $orig_sol[$the_part][1]*$orig_sol[$the_part][2]){
                    my $lat_str = $max_row . "x" . $orig_col;
                    if($the_verb < 1){print BOLD BLUE "[INFO] Checking if the $the_part. output can be realized using the $lat_str lattice... \n", RESET;}
                    find_lattice_realization($file_part, $max_row, $orig_col, $path_espresso, $path_sat);
                    my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_part);
                    my @cloned_sol = @{ dclone(\@the_sol) };
                    if ($sol_found){
                      $sol_improved = 1;
                      $sol_size[$the_part][1] = $the_row;
                      $sol_size[$the_part][2] = $the_col;
                      $sol_size[$the_part][3] = \@cloned_sol;
                    }
                    else{
                      last;
                    }
                  }
                }
                else{
                  last;
                }

                if (time() - $initial_time > $cpu_limit){
                  $cpu_expired = 1;
                  last;
                }
              }

              my @the_sol = ();
              if ($sol_improved){
                $the_row = $sol_size[$the_part][1];
                $the_col = $sol_size[$the_part][2];
                @the_sol = @{ dclone(\@{$sol_size[$the_part][3]}) };
              }
              else{
                $the_row = $orig_sol[$the_part][1];
                $the_col = $orig_sol[$the_part][2];
                @the_sol = @{ dclone(\@{$orig_sol[$the_part][3]}) };
              }
              ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
              $temp_imp[$the_part][1] = "$the_part";
              $temp_imp[$the_part][2] = $temp_col-$the_col+1;
              $temp_imp[$the_part][3] = $temp_col;
            }
            else{
              $the_row = $orig_sol[$the_part][1];
              $the_col = $orig_sol[$the_part][2];
              my @the_sol = @{ dclone(\@{$orig_sol[$the_part][3]}) };
              ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
              $temp_imp[$the_part][1] = "$the_part";
              $temp_imp[$the_part][2] = $temp_col-$the_col+1;
              $temp_imp[$the_part][3] = $temp_col;
            }
          }
          elsif ($orig_sol[$the_part][1] > $max_row) {
            my $orig_col = $orig_sol[$the_part][2];
            my $sol_improved = 0;
            while (1){
              $orig_col++; 
              if ($max_row*$orig_col >= $orig_sol[$the_part][1]*$orig_sol[$the_part][2]){
                my $current_cost = 0;
                if ($the_part == 1){
                  $current_cost = $current_cost + $max_row*$orig_col;
                }
                elsif ($the_part > 1){
                  $current_cost = $current_cost + $max_row*$temp_col;
                  $current_cost = $current_cost + $max_row*($orig_col+1);
                }
                for (my $part_index=$the_part+1; $part_index<=$part_cnt; $part_index++){
                  $current_cost = $current_cost + $max_row*($min_col_arr[$part_index]+1);
                }

                if ($current_cost < $max_cost){
                  my $lat_str = $max_row . "x" . $orig_col;
                  if($the_verb < 1){print BOLD BLUE "[INFO] Checking if the $the_part. output can be realized using the $lat_str lattice... \n", RESET;}
                  find_lattice_realization($file_part, $max_row, $orig_col, $path_espresso, $path_sat);
                  my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_part);
                  my @cloned_sol = @{ dclone(\@the_sol) };
                  if ($sol_found){
                    $sol_improved = 1;
                    $sol_size[$the_part][1] = $the_row;
                    $sol_size[$the_part][2] = $the_col;
                    $sol_size[$the_part][3] = \@cloned_sol;
                    last;
                  }
                }
                else{
                  $cost_exceeded = 1;
                  last;
                }

                if (time() - $initial_time > $cpu_limit){
                  $cpu_expired = 1;
                  last;
                }
              }
            }

            my @the_sol = ();
            if ($sol_improved){
              $the_row = $sol_size[$the_part][1];
              $the_col = $sol_size[$the_part][2];
              @the_sol = @{ dclone(\@{$sol_size[$the_part][3]}) };
            }
            else{
              $the_row = $orig_sol[$the_part][1];
              $the_col = $orig_sol[$the_part][2];
              @the_sol = @{ dclone(\@{$orig_sol[$the_part][3]}) };
            }
            ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
            $temp_imp[$the_part][1] = "$the_part";
            $temp_imp[$the_part][2] = $temp_col-$the_col+1;
            $temp_imp[$the_part][3] = $temp_col;
          }
          elsif ($orig_sol[$the_part][1] == $max_row){
            $the_row = $orig_sol[$the_part][1];
            $the_col = $orig_sol[$the_part][2];
            my @the_sol = @{ dclone(\@{$orig_sol[$the_part][3]}) };
            ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
            $temp_imp[$the_part][1] = "$the_part";
            $temp_imp[$the_part][2] = $temp_col-$the_col+1;
            $temp_imp[$the_part][3] = $temp_col;
          }

          if ($cpu_expired){
            if ($the_verb < 1){print BRIGHT_RED, "[INFO] CPU time has just expired! Returning the solution... \n",RESET;};
            last;
          }
          if ($cost_exceeded){
            if ($the_verb < 1){print BRIGHT_RED, "[INFO] No better solution can be foun with $max_row rows! \n",RESET;};
            last;
          }
        }

        if (!$cpu_expired and !$cost_exceeded){
          my $temp_cost = $temp_row*$temp_col;
          if ($temp_cost < $max_cost){
            if ($the_verb < 1){print RED, "[INFO] Good job! The cost has been decreased to $temp_cost \n", RESET;};
            $max_cost = $temp_cost;
            $sol_row = $temp_row;
            $sol_col = $temp_col;
            @sol_arr = @{ dclone(\@temp_sol) };
            @sol_imp = @{ dclone(\@temp_imp) };
          }
        }
      }
      else{
        if ($the_verb < 1){print BRIGHT_GREEN, "[INFO] Computation of the cost with $max_row rows points out a worse cost than the found so far! Decreasing max_row... \n", RESET;};
      }

      if ($cpu_expired){
        last;
      }
      else{
        $max_row--;
      }
    }
  }

  my $total_time = time() - $initial_time;
  write_solution($file_main, $total_time, $imp_cnt, $sol_row, $sol_col, \@sol_arr,\@sol_imp);
  my $sollat_str = $sol_row . "x" . $sol_col;
  if ($the_verb < 2){print "\n";}
  if ($the_verb < 2){print BRIGHT_GREEN "[INFO] The final solution: $sollat_str \n", RESET;};
  if ($the_verb < 2){print BRIGHT_CYAN "[INFO] Total CPU time: $total_time \n", RESET;};
  if ($the_verb < 2){print "\n";}
}

