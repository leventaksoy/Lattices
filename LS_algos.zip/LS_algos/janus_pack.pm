#!/usr/bin/perl

package janus_pack;

use Cwd qw(); 
use strict;
use warnings;
#use diagnostics;
use Storable qw(dclone);
use Time::HiRes qw( time );
use warnings FATAL => 'all';
use Term::ANSIColor qw(:constants);

sub is_inside_numeric_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] == $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub is_inside_string_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] eq $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub is_inside_array_list{
  my ($the_cnt, $conf_cnt, $the_arr_ref, $conf_arr_ref) = @_;
  my @the_arr = @ {$the_arr_ref};
  my @conf_arr = @ {$conf_arr_ref};

  my $the_value = 0;

  foreach my $i (1 .. $conf_cnt){
    if ($conf_arr[0][$i] == $the_cnt){
      my $is_equal = 1;
      foreach my $j (1 .. $conf_arr[0][$i]){
        if (!is_inside_string_array($conf_arr[$j][$i], $the_cnt, @the_arr)){
          $is_equal = 0;
          last;
        }
      }

      if ($is_equal){
        $the_value = 1;
        last;
      }
    }
  }

  return ($the_value);
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      return $the_offset;
    }
  }

  return $the_offset;
}

sub skip_spaces_backward{
  my ($the_string, $the_offset) = @_;

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset--;
    if ($the_offset < 0) {
      last;
    }
  }

  return $the_offset;
}

sub convert2binary{
  my ($the_int, $the_len) = @_;

  my @the_rep = ();

  foreach my $i (1 .. $the_len){
    $the_rep[$i] = 0;
  }

  my $the_index = 0;
  while ($the_int > 1){
    $the_index++;
    my $the_val = $the_int % 2;
    $the_rep[$the_index] = $the_val;
    $the_int = ($the_int - $the_val) / 2;
  }

  $the_index++;
  $the_rep[$the_index] = $the_int;

  return (@the_rep);
}

sub read_equation{
  my ($file_name) = @_;

  my $in_cnt = 0;
  my @in_arr = ();
  my $lit_cnt = 0;
  my $out_cnt = 0;
  my $the_deg = 0;
  my @lit_arr = ();
  my @out_arr = ();
  my $prod_cnt = 0;
  my @prod_arr =();
  my @prod_lvl =();
  my @prod_num =();

  my $the_end;
  my $the_var;
  my $the_index;
  my $init_index;
  my $last_index;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_name)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      $init_index = 0;
      $init_index=skip_spaces_forward($the_line, $init_index);

      if (substr($the_line, $init_index, 1) ne "#"){
        my $in_line = index($the_line, "INORDER ");
        my $out_line = index($the_line, "OUTORDER ");

        #Extract the input and output variables
        if ($in_line != -1 or $out_line != -1){
          if (index($the_line, ";") != -1){
            $init_index = index($the_line, "=");
            $init_index = skip_spaces_forward($the_line, $init_index+1);

            $the_end = 0;
            while (1){
              $last_index = $init_index;
              while (substr($the_line,$last_index,1) ne " " and substr($the_line,$last_index,1) ne ";"){
                $last_index++;

                if ($last_index > length($the_line)){
                  $the_end = 1;
                  last;
                }
              }

              if (substr($the_line,$last_index,1) eq ";"){
                $the_end = 1;
              }

              #print "[INFO] Last index: $last_index \n";
              #print "[INFO] Init index: $init_index \n";
              if ($last_index >= $init_index){
                $the_var = substr($the_line,$init_index,$last_index-$init_index);
                #print "[INFO] The variable: $the_var \n";

                if ($the_var =~ /[0-9a-zA-Z_]/ ){
                  if ($in_line != -1){
                    $in_cnt++;
                    $in_arr[$in_cnt]=$the_var;
                  }
                  else{
                    $out_cnt++;
                    $out_arr[$out_cnt]=$the_var;
                  }
                }
              }

              if (!$the_end){
                $init_index = skip_spaces_forward($the_line, $last_index+1);
              }
              else{
                last;
              }
            }
          }
          else{
            $in_cnt = 0;
            print RED, "[ERROR] A proper line should end with semicolon in eqn format \n", RESET;
          }
        }
        else{
          #Extract the target function
          $init_index = skip_spaces_forward($the_line,0);
          $last_index = index($the_line,"=");
          if ($last_index != -1){
            if (index ($the_line,";") != -1){
              $the_index = skip_spaces_backward($the_line,$last_index-1);
              my $the_out = substr($the_line,$init_index,$the_index-$init_index+1);
              #print "[INFO] The output: $the_out \n";

              #Extract the products in the target function
              if (is_inside_string_array($the_out, $out_cnt, @out_arr)){
                $init_index = skip_spaces_forward($the_line,$last_index+1);

                $the_end = 0;
                while (1){
                  $last_index = $init_index;
                  while (substr($the_line,$last_index,1) ne "+" and substr($the_line,$last_index,1) ne ";"){
                    $last_index++;

                    if ($last_index > length($the_line)){
                      $the_end = 1;
                      last;
                    }
                  }

                  if (!$the_end){
                    $the_index = skip_spaces_backward($the_line, $last_index-1);

                    if ($the_index >= $init_index){
                      my $the_prod = substr($the_line,$init_index,$the_index-$init_index+1);
                      #print "[INFO] The product: $the_prod \n";

                      my $prod_end = 0;
                      my $prod_init = 0;
                      my $prod_last = 0;

                      $prod_cnt++;
                      $prod_lvl[$prod_cnt] = 0;

                      $prod_init = skip_spaces_forward($the_prod, $prod_init);

                      #Extract the variables in the product
                      while (1){
                        $prod_last = $prod_init;

                        while (substr($the_prod,$prod_last,1) ne " " and substr($the_prod,$prod_last,1) ne "*"){
                          $prod_last++;

                          if ($prod_last > length($the_prod)){
                            $prod_end = 1;
                            last;
                          }
                        }

                        if (!$prod_end){
                          $the_var = substr($the_prod, $prod_init, $prod_last-$prod_init);
                          #print "[INFO] The product literal: $the_var \n";
                        }
                        else{
                          $the_var = substr($the_prod, $prod_init, $prod_last-$prod_init+1);
                          #print "[INFO] The product literal: $the_var \n";  
                        }

                        if (!is_inside_string_array($the_var, $lit_cnt, @lit_arr)){
                          $lit_cnt++;
                          $lit_arr[$lit_cnt] = $the_var;
                        }

                        my $pure_var;
                        my $inv_index = index($the_var,"!");
                        if ($inv_index != -1){
                          $pure_var = substr($the_var, $inv_index+1, length($the_var)-1);
                        }
                        else{
                          $pure_var = $the_var;
                        }
                        #print "[INFO] The pure product variable: $pure_var \n"; 
                        
                        if (is_inside_string_array($pure_var, $in_cnt, @in_arr)){
                          $prod_lvl[$prod_cnt]++;
                          $prod_arr[$prod_lvl[$prod_cnt]][$prod_cnt] = $the_var;
                        }
                        else{
                          $in_cnt = 0;
                          print RED, "[ERROR] The variable $pure_var in product $the_prod is not declared in INORDER \n", RESET;
                        }

                        if (!$prod_end){
                          $prod_init = $prod_last;
                          while (substr($the_prod, $prod_init, 1) eq " " or substr($the_prod, $prod_init, 1) eq "*"){
                            $prod_init++;

                            if ($prod_init > length($the_prod)){
                              $prod_end = 1;
                              last;
                            }
                          }
                        }

                        if ($prod_end){
                          last;
                        }
                      }

                      if (defined $prod_num[$prod_lvl[$prod_cnt]]){
                        $prod_num[$prod_lvl[$prod_cnt]]++;
                      }
                      else{
                        $prod_num[$prod_lvl[$prod_cnt]] = 1;
                      }

                      if ($prod_lvl[$prod_cnt] > $the_deg){
                        $the_deg = $prod_lvl[$prod_cnt];
                      }
                    }
                    $init_index = skip_spaces_forward($the_line, $last_index+1);
                  }
                  else{
                    last;
                  }
                }
              }
              else{
                $in_cnt = 0;
                print RED, "[ERROR] The $the_out variable is not declared in the OUTORDER \n", RESET;
              }
            }
            else{
              $in_cnt = 0;
              print RED, "[ERROR] A proper line should end with semicolon in eqn format \n", RESET;
            }
          }
        }
      }
    }

    close $file_header;
  }
  else{
    $in_cnt = 0;
    print RED, "[ERROR] Could not open the $file_name file \n", RESET;
  }

  return ($in_cnt, $out_cnt, $lit_cnt, $prod_cnt, $the_deg, \@in_arr, \@out_arr, \@lit_arr, \@prod_num, \@prod_lvl, \@prod_arr);
}

sub write_and_cnffile{
  my ($fid_cnf, $con_cnt, $the_out, $in_cnt, @in_arr) = @_;

  my $last_con = $the_out . " ";
  foreach my $i (1 .. $in_cnt){
    $con_cnt++;
    #$con_arr[$con_cnt] = "-" . $the_out . " " . $in_arr[$i] . " 0";
    printf $fid_cnf "-%0d %0d 0\n", $the_out, $in_arr[$i];
    $last_con = $last_con . "-" . $in_arr[$i] . " ";
  }
  $con_cnt++;
  #$con_arr[$con_cnt] = $last_con . "0";
  printf $fid_cnf "%0s0\n", $last_con;

  return ($con_cnt);
}

sub write_or_cnffile{
  my ($fid_cnf, $con_cnt, $the_out, $in_cnt, @in_arr) = @_;

  my $last_con = "-" . $the_out . " ";
  foreach my $i (1 .. $in_cnt){
    $con_cnt++;
    #$con_arr[$con_cnt] = $the_out . " -" . $in_arr[$i] . " 0";
    printf $fid_cnf "%0d -%0d 0\n", $the_out, $in_arr[$i];
    $last_con = $last_con . $in_arr[$i] . " ";
  }
  $con_cnt++;
  #$con_arr[$con_cnt] = $last_con . "0";
  printf $fid_cnf "%0s0\n", $last_con;

  return ($con_cnt);
}

sub write_selection_constraints{
  my ($npft, $fid_cnf, $cnf_cnt, $in_var, $lit_var, $the_var, $in_num, $lit_arr_ref, $latvar_tt_arr_ref, $tt_arr_ref) = @_;
  my @tt_arr = @ {$tt_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @latvar_tt_arr = @ {$latvar_tt_arr_ref};
 
  foreach my $tt_var (0 .. 2**$in_num-1){
    $cnf_cnt++;
    
    if ($npft == 1){
      if ($tt_arr[$tt_var][$lit_arr[$lit_var]]){
        printf $fid_cnf "-%0d %0d 0 \n", $the_var, $latvar_tt_arr[$in_var][$tt_var];
      }
      else{
        printf $fid_cnf "-%0d -%0d 0 \n", $the_var, $latvar_tt_arr[$in_var][$tt_var];
      }
    }
    elsif ($npft == 0){
      if ($tt_arr[$tt_var][abs($lit_arr[$lit_var])]){
        printf $fid_cnf "-%0d -%0d 0 \n", $the_var, $latvar_tt_arr[$in_var][$tt_var];
      }
      else{
        printf $fid_cnf "-%0d %0d 0 \n", $the_var, $latvar_tt_arr[$in_var][$tt_var];
      }
    }
    elsif ($npft == 3){
      printf $fid_cnf "-%0d %0d 0 \n", $the_var, $latvar_tt_arr[$in_var][$tt_var];
    }
    elsif ($npft == 2){
      printf $fid_cnf "-%0d -%0d 0 \n", $the_var, $latvar_tt_arr[$in_var][$tt_var];
    }
  }

  return ($cnf_cnt);
}


sub file_read_minisat_solution{
  my ($row_num, $col_num, $deg_num, $lat_in_cnt, $var_cnt, $deg_arr_ref, $deg_var_arr_ref) = @_;
  my @deg_arr = @ {$deg_arr_ref};
  my @deg_var_arr = @ {$deg_var_arr_ref};

  my $sol_found = 1;
  my @sol_matrix = ();
  
  my @sol_arr = ();
  foreach my $i (1 .. $lat_in_cnt){
    $sol_arr[$i] = 0;
  }

  my @var_arr = ();
  foreach my $i (1 .. $var_cnt){
    $var_arr[$i] = 0;
  }
 
  if (open (my $file_header, '<:encoding(UTF-8)', "sat_problem.sol")) {
    my $the_line = <$file_header>;
    chomp $the_line;
    #print "[INFO] The line: $the_line \n";
    
    if (index($the_line,"UNSAT") != -1){
      $sol_found = 0;
    }
    else{
      my $the_line = <$file_header>;
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      #Extract the values of variables in the SAT problem
      my $the_var = 0;
      my $init_index = 0;
      my $last_index = 0;
      do{
        $last_index = $init_index;
        while (substr($the_line, $last_index, 1) ne " "){
          $last_index++;

          if ($last_index >= length($the_line)){
            last;
          }
        }

        $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
        $var_arr[abs($the_var)] = $the_var;
        #print "[INFO] solution variable: $the_var \n";

        $last_index++;
        $init_index = $last_index;
      }while ($the_var);

      #Extract the selected values for each lattice variable
      foreach my $tt_ent (0 .. 2**$deg_num-1){
        foreach my $lat_var (1 .. $lat_in_cnt){
          my $pos_cnt = 0;
          foreach my $tar_var (1 .. 2*($deg_num+1)){
            if ($var_arr[$deg_var_arr[$lat_var][$tar_var][$tt_ent]] > 0){
              $pos_cnt++;
              if (!$sol_arr[$lat_var]){
                $sol_arr[$lat_var] = $tar_var;
              }
              else{
                if ($sol_arr[$lat_var] != $tar_var){
                  $sol_found = 0;
                  print RED, "[ERROR] For each truth table entry the same target should be assigned to a lattice variable! \n", RESET;
                }
              }
            }
          }

          if ($pos_cnt > 1){
            $sol_found = 0;
            print RED, "[ERROR] Only one target variable should be assigned to a lattice variable! \n", RESET;
          }
        }
      }

      #Generate the solution matrix based on the lattice entries
      my $the_index = 0;
      foreach my $i (1 .. $row_num){
        foreach my $j (1 .. $col_num){
          $the_index++;
          if ($sol_arr[$the_index] % 2){
            if (($sol_arr[$the_index]+1)/2 <= $deg_num){
              $sol_matrix[$i][$j] = $deg_arr[($sol_arr[$the_index]+1)/2];
            }
            elsif (($sol_arr[$the_index]+1)/2 == $deg_num+1){
              $sol_matrix[$i][$j] = "T";
            }
          }
          else{
            if ($sol_arr[$the_index]/2 <= $deg_num){
              $sol_matrix[$i][$j] = "!" . $deg_arr[$sol_arr[$the_index]/2];
            }
            elsif ($sol_arr[$the_index]/2 == $deg_num+1){
              $sol_matrix[$i][$j] = "F";
            }
          }
        }
      }
    }

    close $file_header;
  }
  else{
    $sol_found = 0;
    print RED, "[ERROR] Could not open the minisat output! \n", RESET;
  }

  return ($sol_found, @sol_matrix);
}

sub file_read_minisat_unsat{
  my $unsat = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', "sat_problem.sol")) {
    my $the_line = <$file_header>;
    chomp $the_line;
    #print "[INFO] The line: $the_line \n";
    
    if (index($the_line,"UNSAT") != -1){
      $unsat = 1;
    }
    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the minisat output! \n", RESET;
  }

  return ($unsat);
}

sub file_read_glucose_solution{
  my ($file_dir, $simp_dual, $row_num, $col_num, $in_num, $lit_num, $var_cnt, $in_arr_ref, $lit_arr_ref, $invar_lit_arr_ref) = @_;

  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @invar_lit_arr = @ {$invar_lit_arr_ref};

  my $sol_found = 1;
  my @sol_matrix = ();
  my $lat_in_cnt = $row_num*$col_num;
  
  my @var_arr = ();
  foreach my $i (1 .. $var_cnt){
    $var_arr[$i] = 0;
  }
 
  my $file_sol = $file_dir . "sat_problem.sol";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (1){
      my $the_line = <$file_header>;
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      #sleep 1;
      
      if (index($the_line,"s UNSATISFIABLE") != -1){
        close $file_header;
        $sol_found = 0;
        last;
      }
      elsif (index($the_line, "s INDETERMINATE") != -1){
        close $file_header;
        $sol_found = -1;
        last;
      }
      elsif (index($the_line, "s SATISFIABLE") != -1){
        close $file_header;
        last;
      }
    }

    if ($sol_found == 1){
      my $file_out = $file_dir . "sat_problem.out";
      if (open (my $fid_out, '<:encoding(UTF-8)', $file_out)) {
        my $the_line = <$fid_out>;
        chomp $the_line;

        my $init_index = 0;
        my $last_index = 0;
        my $length_line = length($the_line);
        
        while (1){
          #($init_index) = skip_spaces_forward($the_line, $last_index);
          while (!(substr($the_line, $last_index, 1) =~ /[0-9+-]/)){
            $last_index++;

            if ($last_index > $length_line){
              last;
            }
          }
          $init_index = $last_index;
          
          while (substr($the_line, $last_index, 1) =~ /[0-9+-]/){
            $last_index++;

            if ($last_index > $length_line){
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
          if ($the_var){
            $var_arr[abs($the_var)] = $the_var;
            #print "[INFO] solution variable: $the_var \n";
          }
          else{
            last;
          }
        }

        #Extract the selected target variables for each lattice variable
        foreach my $in_var (1 .. $lat_in_cnt){
          my $var_det = 0;
          foreach my $lit_var (1 .. $lit_num+2){
            if ($var_arr[$invar_lit_arr[$lit_var][$in_var]] > 0){
              my $the_row = int ($in_var/$col_num + 0.999);
              my $the_col = (($in_var-1) % $col_num) + 1;
              
              if (!$var_det){
                $var_det = 1;
                if ($lit_var == $lit_num+1){
                  if (!$simp_dual){
                    $sol_matrix[$the_row][$the_col] = "T";
                  }
                  else{
                    $sol_matrix[$the_row][$the_col] = "F";
                  }
                }
                elsif ($lit_var == $lit_num+2){
                  if (!$simp_dual){
                    $sol_matrix[$the_row][$the_col] = "F";
                  }
                  else{
                    $sol_matrix[$the_row][$the_col] = "T";
                  }
                }
                else{
                  if ($lit_arr[$lit_var] > 0){
                    $sol_matrix[$the_row][$the_col] = $in_arr[$lit_arr[$lit_var]];
                  }
                  else{
                    $sol_matrix[$the_row][$the_col] = "!" . $in_arr[abs($lit_arr[$lit_var])];
                  }
                }
              }
              else{
                $sol_found = 0;
                print RED, "[ERROR] A lattice variable should only be assigned to a single target variable! \n", RESET;
                last;
              }
            }
          }
          if (!$sol_found){
            last;
          }
        }

        close $fid_out;
      }
      else{
        $sol_found = 0;
        print RED, "[ERROR] Could not open the glucose output! \n", RESET;
      }
    }
  }
  else{
    $sol_found = 0;
    print RED, "[ERROR] Could not open the glucose output! \n", RESET;
  }

  return ($sol_found, @sol_matrix);
}

sub file_read_cryptolingeling_solution{
  my ($file_dir, $simp_dual, $row_num, $col_num, $in_num, $lit_num, $var_cnt, $in_arr_ref, $lit_arr_ref, $invar_lit_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @invar_lit_arr = @ {$invar_lit_arr_ref};

  my $sol_found = 1;
  my @sol_matrix = ();
  my $lat_in_cnt = $row_num*$col_num;
  
  my @var_arr = ();
  foreach my $i (1 .. $var_cnt){
    $var_arr[$i] = 0;
  }
 
  my $file_sol = $file_dir . "sat_problem.sol";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (1){
      my $the_line = <$file_header>;
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      #sleep 1;
      
      if (index($the_line,"s UNSATISFIABLE") != -1){
        close $file_header;
        $sol_found = 0;
        last;
      }
      elsif (index($the_line, "s INDETERMINATE") != -1){
        close $file_header;
        $sol_found = -1;
        last;
      }
      elsif (index($the_line, "s SATISFIABLE") != -1){
        my $the_var = 0;

        #Extract the values of variables in the SAT problem
        do{
          my $the_line = <$file_header>;
          chomp $the_line;
          #print "[INFO] The line: $the_line \n";

          my $init_index = 2;
          my $last_index = 2;
          do{
            $last_index = $init_index;
            while (substr($the_line, $last_index, 1) ne " "){
              $last_index++;

              if ($last_index >= length($the_line)){
                last;
              }
            }

            $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
            $var_arr[abs($the_var)] = $the_var;
            #print "[INFO] solution variable: $the_var \n";

            $last_index = skip_spaces_forward($the_line, $last_index);
            $init_index = $last_index;
          }while ($the_var and $last_index < length($the_line));
        }while($the_var);

        #Extract the selected target variables for each lattice variable
        foreach my $in_var (1 .. $lat_in_cnt){
          my $var_det = 0;
          foreach my $lit_var (1 .. $lit_num+2){
            if ($var_arr[$invar_lit_arr[$lit_var][$in_var]] > 0){
              my $the_row = int ($in_var/$col_num + 0.999);
              my $the_col = (($in_var-1) % $col_num) + 1;
              
              if (!$var_det){
                $var_det = 1;
                if ($lit_var == $lit_num+1){
                  if (!$simp_dual){
                    $sol_matrix[$the_row][$the_col] = "T";
                  }
                  else{
                    $sol_matrix[$the_row][$the_col] = "F";
                  }
                }
                elsif ($lit_var == $lit_num+2){
                  if (!$simp_dual){
                    $sol_matrix[$the_row][$the_col] = "F";
                  }
                  else{
                    $sol_matrix[$the_row][$the_col] = "T";
                  }
                }
                else{
                  if ($lit_arr[$lit_var] > 0){
                    $sol_matrix[$the_row][$the_col] = $in_arr[$lit_arr[$lit_var]];
                  }
                  else{
                    $sol_matrix[$the_row][$the_col] = "!" . $in_arr[abs($lit_arr[$lit_var])];
                  }
                }
              }
              else{
                $sol_found = 0;
                print RED, "[ERROR] A lattice variable should only be assigned to a single target variable! \n", RESET;
                last;
              }
            }
          }
        }

        last;
      }
    }

    close $file_header;
  }
  else{
    $sol_found = 0;
    print RED, "[ERROR] Could not open the cryptominisat/lingeling output! \n", RESET;
  }

  return ($sol_found, @sol_matrix);
}

sub write_solution{
  my ($tot_time, $file_pla, $sol_opt, $sol_nonopt, $row_num, $col_num, $tot_var, $tot_cnf, $tot_run, @the_sol) = @_;
  #print "Total SAT run: $tot_run \n";

  my $avg_var = 0;
  my $avg_cnf = 0;
  if ($tot_run){
    $avg_var = $tot_var/$tot_run;
    $avg_cnf = $tot_cnf/$tot_run;
  }

  my $file_name = "";
  my $dot_index = index($file_pla, ".");
  if ($dot_index == -1){
    $file_name = $file_pla;
  }
  else{
    $file_name = substr($file_pla, 0, $dot_index);
  }
  $file_name = $file_name . ".sol";

  open (my $fid_out, '>', $file_name);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);    
  printf $fid_out "# Synthesis of the Target Function with a Lattice of Four-Terminal Switches\n";
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Target Equation File: %0s \n", $file_pla;
  printf $fid_out "# Average Number of Variables in SAT Problems: %.2f \n", $avg_var;
  printf $fid_out "# Average Number of Clauses in SAT Problems: %.2f \n", $avg_cnf;
  printf $fid_out "# Solution Quality: Non-optimal \n";
  printf $fid_out "# Lattice RowxColumn: %0dx%0d \n", $row_num, $col_num;
  printf $fid_out "# Size of lattice: %0d \n", $row_num*$col_num;
  printf $fid_out "# CPU time: %.2f \n", $tot_time;

  if ($sol_opt){
    my $the_index = 0;
    foreach my $i (1 .. $row_num){
      printf $fid_out "| ";
      foreach my $j (1 .. $col_num){
        if (index($the_sol[$i][$j], "!") != -1){
          printf $fid_out "%0s | ", $the_sol[$i][$j];
        }
        else{
          printf $fid_out "%0s  | ", $the_sol[$i][$j];
        }
      }
      printf $fid_out "\n";
    }
  }
  else{
    printf $fid_out "NO SOLUTION \n";
  }

  close $fid_out;

  return;
}

sub extract_sat_problem_size{
  my ($file_name) = @_;

  my $var_cnt = 0;
  my $cnf_cnt = 0;

  my $init_index = 0;
  my $last_index = 0;

  if (open (my $fid_cnf, '<', $file_name)){
    while (my $the_line = <$fid_cnf>){
      chomp $the_line;

      if (index($the_line, "p cnf ") != -1){
        $init_index = skip_spaces_forward($the_line, 5);
        my $len_line = length($the_line);
        $last_index = $init_index;
        while (substr($the_line, $last_index, 1) ne " "){
          $last_index++;

          if ($last_index >= $len_line){
            last;
          }
        }

        $var_cnt = substr($the_line, $init_index, $last_index-$init_index);
        
        $init_index = skip_spaces_forward($the_line, $last_index);
        $last_index = $init_index;
        while (substr($the_line, $last_index, 1) ne " "){
          $last_index++;

          if ($last_index >= $len_line){
            last;
          }
        }
        
        $cnf_cnt = substr($the_line, $init_index, $last_index-$init_index);

        last;
      }
    }
    close ($fid_cnf);
  }
  else{
    print RED, "[ERROR] Copuld not open the sat_problem.cnf file! Returning... \n", RESET;
  }

  return ($var_cnt, $cnf_cnt);
}

sub lit_in_mapping{
  my ($in_str, $in_num, @in_arr) = @_;

  my $the_in = 0;

  my $is_neg = 1;
  my $the_str = $in_str;
  if (index($in_str, "!") != -1){
    $is_neg = -1;
    $the_str = substr($in_str, 1, length($in_str)-1);
  }

  $the_in = is_inside_string_array($the_str, $in_num, @in_arr);
  $the_in = $is_neg * $the_in;

  return ($the_in);
}

sub bergman_simp{
  my ($the_verb, $file_dir, $path_sat, $row_num, $col_num, $in_num, $lit_num, $tar_deg, $lat_deg, $in_arr_ref, $lit_arr_ref, $tt_arr_ref, $lat_in_cnt_simp, $prod_cnt_simp, $lat_prod_cnt_simp, $lat_prod_cnt_dual, $lat_in_arr_simp_ref, $single_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $lat_prod_lvl_simp_ref, $lat_prod_lvl_dual_ref, $prod_arr_simp_ref, $lat_prod_arr_simp_ref, $lat_prod_arr_dual_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @tt_arr = @ {$tt_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};

  my @single_lit_dual = @ {$single_lit_dual_ref};
  my @single_lit_simp = @ {$single_lit_simp_ref};

  #Related to the target function
  my @prod_arr_simp = @ {$prod_arr_simp_ref};
  my @prod_lvl_simp = @ {$prod_lvl_simp_ref};

  #Related to 4-terminal
  my $lat_in_cnt = $lat_in_cnt_simp;
  my $lat_prod_cnt = $lat_prod_cnt_simp;
  my @lat_in_arr = @ {$lat_in_arr_simp_ref};
  my @lat_prod_arr = @ {$lat_prod_arr_simp_ref};
  my @lat_prod_lvl = @ {$lat_prod_lvl_simp_ref};
  
  #Related to 8-terminal
  my @lat_prod_arr_dual = @ {$lat_prod_arr_dual_ref};
  my @lat_prod_lvl_dual = @ {$lat_prod_lvl_dual_ref};

  my $the_end = 0;
  my $var_cnt = 0;
  my $cnf_cnt = 0;
  my $the_ready = 1;
  my $netvar_cnt = 0;
  my $netcnf_cnt = 0;
  my @invar_lit_arr = ();

  if ($lat_in_cnt){
    if (!$the_verb){print "[INFO] Generating the SAT problem... \n";}
    my $file_cnf = $file_dir . "sat_problem_simp.cnf";
    my $file_var = $file_dir . "sat_problem_simp.var";
    open (my $fid_cnf, '>', $file_cnf);
    open (my $fid_var, '>', $file_var);
    printf $fid_cnf "p cnf 1 1 \n";

    my $the_cnf = "";
    my @latvar_tt_arr = ();

    #Generating the lattice network and lattice inputs for each truth table entry
    foreach my $tt_var (0 .. 2**$in_num-1){
      my $first_latvar = $var_cnt+1;
      foreach my $in_var (1 .. $lat_in_cnt){
        $var_cnt++;
        $latvar_tt_arr[$in_var][$tt_var] = $var_cnt;
        printf $fid_var "%0d = %0s_tt%0d \n", $var_cnt, $lat_in_arr[$in_var], $tt_var;
      }

      if ($tt_arr[$tt_var][$in_num+1]){
        $the_cnf = "";
        foreach my $i (1 .. $lat_prod_cnt){
          my $and_in_cnt = 0;
          my @and_in_arr = ();
          my $and_label = "AND";
          foreach my $j (1 .. $lat_prod_lvl[$i]){
            $and_in_cnt++;
            $and_label = $and_label . "_" . $lat_prod_arr[$j][$i];
            $and_in_arr[$and_in_cnt] = $first_latvar + $lat_prod_arr[$j][$i] - 1;
          }
          $var_cnt++;
          $the_cnf = $the_cnf . $var_cnt . " ";
          printf $fid_var "%0d = %0s_tt%0d \n", $var_cnt, $and_label, $tt_var;

          ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
        }
        $cnf_cnt++;
        printf $fid_cnf "%0s0 \n", $the_cnf;

        #Generating constraints indicating that all the lattice variables in each row should not be low
        foreach my $row_var (1 .. $row_num){
          $the_cnf = "";
          foreach my $col_var (1 .. $col_num){
            my $the_index = $first_latvar + ($row_var-1)*$col_num+$col_var - 1;
            $the_cnf = $the_cnf . $the_index . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }
        
        #Generating constraints indicating that all the variables in each path in dual of the lattice function (which blocks any path from top-bottom) should not be low 
        #foreach my $i (1 .. $lat_prod_cnt_dual){
        #  $the_cnf = "";
        #  foreach my $j (1 .. $lat_prod_lvl_dual[$i]){
        #    my $the_index = $first_latvar + $lat_prod_arr_dual[$j][$i] - 1;
        #    $the_cnf = $the_cnf . $the_index . " ";
        #  }
        #  $cnf_cnt++;
        #  printf $fid_cnf "%0s0 \n", $the_cnf;
        #}
        
        if ($row_num >= 2){
          #Generating constraints indicating that in each consecutive rows if there must be at least one case that two rows in the same column are high
          foreach my $row_var (1 .. $row_num-1){
            $the_cnf = "";
            foreach my $col_var (1 .. $col_num){
              my $and_in_cnt = 2;
              my @and_in_arr = ();
              
              $and_in_cnt = 2;
              $and_in_arr[1] = $first_latvar + ($row_var-1)*$col_num+$col_var - 1;
              $and_in_arr[2] = $first_latvar + ($row_var)*$col_num+$col_var - 1;
              $var_cnt++;
              printf $fid_var "%0d = AND_%0d_%0d \n", $var_cnt, $first_latvar+($row_var-1)*$col_num+$col_var-1, $first_latvar+($row_var)*$col_num+$col_var-1;
              ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
              $the_cnf = $the_cnf . $var_cnt . " ";
            }
            $cnf_cnt++;
            printf $fid_cnf "%0s0 \n", $the_cnf;
          }
        }
      }
      else{
        foreach my $i (1 .. $lat_prod_cnt){
          $the_cnf = "";
          foreach my $j (1 .. $lat_prod_lvl[$i]){
            my $the_index = $first_latvar + $lat_prod_arr[$j][$i] - 1;
            $the_cnf = $the_cnf . "-". $the_index . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }  
      }

      if ($cnf_cnt > 20000000){
        $the_end = 1;
        $netvar_cnt = $var_cnt;
        $netcnf_cnt = $cnf_cnt;
        print BRIGHT_YELLOW "[WARNING] Number of constraints has exceeded the limit! Completing the generation of the SAT problem... \n";
        last;
      }
    }

    #Generating the selection variables and the necessary constraints
    if (!$the_end){
      foreach my $in_var (1 .. $lat_in_cnt){
        foreach my $lit_var (1 .. $lit_num){
          if ($lit_arr[$lit_var] > 0){
            $var_cnt++;
            $invar_lit_arr[$lit_var][$in_var] = $var_cnt;
            printf $fid_var "%0d = %0s_pos%0s \n", $var_cnt, $lat_in_arr[$in_var], $in_arr[$lit_arr[$lit_var]];
            ($cnf_cnt) = write_selection_constraints(1, $fid_cnf, $cnf_cnt, $in_var, $lit_var, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);
          }
          else{
            $var_cnt++;
            $invar_lit_arr[$lit_var][$in_var] = $var_cnt;
            printf $fid_var "%0d = %0s_neg%0s \n", $var_cnt, $lat_in_arr[$in_var], $in_arr[abs($lit_arr[$lit_var])];
            ($cnf_cnt) = write_selection_constraints(0, $fid_cnf, $cnf_cnt, $in_var, $lit_var, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);
          }
        }

        #For TRUE and FALSE
        $var_cnt++;
        $invar_lit_arr[$lit_num+1][$in_var] = $var_cnt;
        printf $fid_var "%0d = %0s_true \n", $var_cnt, $lat_in_arr[$in_var];
        ($cnf_cnt) = write_selection_constraints(3, $fid_cnf, $cnf_cnt, $in_var, 0, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);
        $var_cnt++;
        $invar_lit_arr[$lit_num+2][$in_var] = $var_cnt;
        printf $fid_var "%0d = %0s_false \n", $var_cnt, $lat_in_arr[$in_var];
        ($cnf_cnt) = write_selection_constraints(2, $fid_cnf, $cnf_cnt, $in_var, 0, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);

        $the_cnf = "";
        foreach my $i (1 .. $lit_num+1){
          $the_cnf = $the_cnf . $invar_lit_arr[$i][$in_var] . " ";
          foreach my $j ($i+1 .. $lit_num+2){
            $cnf_cnt++;
            printf $fid_cnf "-%0d -%0d 0 \n", $invar_lit_arr[$i][$in_var], $invar_lit_arr[$j][$in_var];
          }
        }
        $cnf_cnt++;
        printf $fid_cnf "%0s%0d 0 \n", $the_cnf, $invar_lit_arr[$lit_num+2][$in_var];

        if ($cnf_cnt > 20000000){
          $the_end = 1;
          $netvar_cnt = $var_cnt;
          $netcnf_cnt = $cnf_cnt;
          print BRIGHT_YELLOW "[WARNING] Number of constraints has exceeded the limit! Completing the generation of the SAT problem... \n";
          last;
        }
      }

      #Assuming that the target function is not TRUE, the terms in the products cannot be TRUE at the same time
      if (!$the_end){
        foreach my $i (1 .. $lat_prod_cnt){
          $the_cnf = "";
          foreach my $j (1 .. $lat_prod_lvl[$i]){
            my $the_var = $lat_prod_arr[$j][$i] + 0.0;
            $the_cnf = $the_cnf . "-" . $invar_lit_arr[$lit_num+1][$the_var] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        #Assuming that the target function is not FALSE, for each row, the entiries on each column cannot be FALSE at the same time
        foreach my $i (1 .. $row_num){
          $the_cnf = "";
          foreach my $j (1 .. $col_num){
            my $the_var = ($i-1)*$col_num + $j;
            $the_cnf = $the_cnf . "-" . $invar_lit_arr[$lit_num+2][$the_var] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        $netvar_cnt = $var_cnt;
        $netcnf_cnt = $cnf_cnt;

        my @prod_considered = ();
        foreach my $i (1 .. $prod_cnt_simp){
          $prod_considered[$i] = 0;
        }

        #Generating constraints indicating that WHEN the degree of the target and lattice functions are the same, the products with this degree in the lattice function should realize the ones with the same degree in the target function
        if ($tar_deg == $lat_deg){
          foreach my $i (1 .. $prod_cnt_simp){
            if ($prod_lvl_simp[$i] == $tar_deg){
              $prod_considered[$i] = 1;

              my @lit_var_arr = ();
              foreach my $j (1 .. $lit_num){
                $lit_var_arr[$j] = 0;
              }
              #Generating the product label and lit_var_arr indicating the literals of the product in the lit_arr
              my $prod_label = "";
              foreach my $k (1 .. $prod_lvl_simp[$i]){
                $prod_label .= $prod_arr_simp[$k][$i];

                my $var_index = 1;
                my $the_var = $prod_arr_simp[$k][$i];
                if (index($the_var, "!") != -1){
                  $var_index = -1;
                  $the_var = substr($the_var, 1, length($the_var)-1);
                }
                my $in_index = is_inside_string_array($the_var, $in_num, @in_arr);
                $var_index = $var_index * $in_index;
                my $lit_index = is_inside_numeric_array($var_index, $lit_num, @lit_arr);
                $lit_var_arr[$lit_index] = 1;
              }
              
              $the_cnf = "";
              my @lat_var_arr = ();
              foreach my $j (1 .. $lat_prod_cnt){
                if ($prod_lvl_simp[$i] == $lat_prod_lvl[$j]){
                  my $and_in_cnt = 0;
                  my @and_in_arr = ();
                  my $and_label = "AND";
                  foreach my $k (1 .. $lat_prod_lvl[$j]){
                    my $the_index = $lat_prod_arr[$k][$j] + 0.0;
                    $and_label = $and_label . "_" . $the_index;

                    if (!(defined $lat_var_arr[$the_index])){
                      $var_cnt++;
                      printf $fid_var "%0d = %d_%0s \n", $var_cnt, $the_index, $prod_label;
                      $lat_var_arr[$the_index] = $var_cnt;
                    }

                    $and_in_cnt++;
                    $and_in_arr[$and_in_cnt] = $lat_var_arr[$the_index];
                  }

                  $var_cnt++;
                  printf $fid_var "%0d = %0s_%0s \n", $var_cnt, $and_label, $prod_label;
                  ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
                  $the_cnf = $the_cnf . $var_cnt . " ";
                }
              }

              #Generating the constraints indicating that at least one of products in the lattice function should realize the product in the target function
              if ($the_cnf ne ""){
                $cnf_cnt++;
                printf $fid_cnf "%0s0\n", $the_cnf;
              }

              #Generating the constraints indicating that when a selection variable is chosen the literals in the product have a high/low value as determined
              foreach my $j (1 .. $lat_in_cnt){
                if (defined $lat_var_arr[$j]){
                  foreach my $k (1 .. $lit_num){
                    $cnf_cnt++;
                    if ($lit_var_arr[$k]){
                      printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                    }
                    else{
                      printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                    }
                  }

                  #For TRUE and FALSE
                  $cnf_cnt++;
                  printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$lit_num+1][$j], $lat_var_arr[$j];
                  $cnf_cnt++;
                  printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$lit_num+2][$j], $lat_var_arr[$j];
                }
              }
            }
          }
        }

        #Generating constraints indicating that if there is a single term product then one of the entries in the lattice should be equal to this literal
        foreach my $i (1 .. $single_lit_simp[0]){
          $the_cnf = "";
          foreach my $j (1 .. $lat_in_cnt){
            $the_cnf = $the_cnf . $invar_lit_arr[$single_lit_simp[$i]][$j] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        foreach my $i (1 .. $single_lit_dual[0]){
          $the_cnf = "";
          foreach my $j (1 .. $lat_in_cnt){
            $the_cnf = $the_cnf . $invar_lit_arr[$single_lit_dual[$i]][$j] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        #Generating constraints indicating that the literals in the target function should appear at least in one entry of the lattice
        foreach my $i (1 .. $lit_num){
          if (!is_inside_numeric_array($i, $single_lit_simp[0], @single_lit_simp) and !is_inside_numeric_array($i, $single_lit_dual[0], @single_lit_dual)){
            $the_cnf = "";
            foreach my $j (1 .. $lat_in_cnt){
              $the_cnf = $the_cnf . $invar_lit_arr[$i][$j] . " ";
            }
            $cnf_cnt++;
            printf $fid_cnf "%0s0 \n", $the_cnf;
          }
        }

        #Generating constraints indicating that the single term product if there is any should be placed on the first row of the lattice
        #foreach my $i (1 .. $single_lit_simp[0]){
        #  $the_cnf = "";
        #  foreach my $j (1 .. $col_num){
        #    $the_cnf = $the_cnf . $invar_lit_arr[$single_lit_simp[$i]][$j] . " ";
        #  }
        #  $cnf_cnt++;
        #  printf $fid_cnf "%0s0 \n", $the_cnf;
        #}

        #Generating constraints indicating that a product in the target function must be realized by at least one of products in the lattice function
        foreach my $i (1 .. $prod_cnt_simp){
          if ($prod_lvl_simp[$i] > 5 and !$prod_considered[$i]){
            my @lit_var_arr = ();
            foreach my $j (1 .. $lit_num){
              $lit_var_arr[$j] = 0;
            }
            #Generating the product label and lit_var_arr indicating the literals of the product in the lit_arr
            my $prod_label = "";
            foreach my $k (1 .. $prod_lvl_simp[$i]){
              $prod_label .= $prod_arr_simp[$k][$i];

              my $var_index = 1;
              my $the_var = $prod_arr_simp[$k][$i];
              if (index($the_var, "!") != -1){
                $var_index = -1;
                $the_var = substr($the_var, 1, length($the_var)-1);
              }
              my $in_index = is_inside_string_array($the_var, $in_num, @in_arr);
              $var_index = $var_index * $in_index;
              my $lit_index = is_inside_numeric_array($var_index, $lit_num, @lit_arr);
              $lit_var_arr[$lit_index] = 1;
            }
            
            $the_cnf = "";
            my @lat_var_arr = ();
            foreach my $j (1 .. $lat_prod_cnt){
              if ($prod_lvl_simp[$i] <= $lat_prod_lvl[$j]){
                my $and_in_cnt = 0;
                my @and_in_arr = ();
                my $and_label = "AND";
                foreach my $k (1 .. $lat_prod_lvl[$j]){
                  my $the_index = $lat_prod_arr[$k][$j] + 0.0;
                  $and_label = $and_label . "_" . $the_index;

                  if (!(defined $lat_var_arr[$the_index])){
                    $var_cnt++;
                    printf $fid_var "%0d = %d_%0s \n", $var_cnt, $the_index, $prod_label;
                    $lat_var_arr[$the_index] = $var_cnt;
                  }

                  $and_in_cnt++;
                  $and_in_arr[$and_in_cnt] = $lat_var_arr[$the_index];
                }

                $var_cnt++;
                printf $fid_var "%0d = %0s_%0s \n", $var_cnt, $and_label, $prod_label;
                ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
                $the_cnf = $the_cnf . $var_cnt . " ";
              }
            }

            #Generating the constraints indicating that at least one of products in the lattice function should realize the product in the target function
            if ($the_cnf ne ""){
              $cnf_cnt++;
              printf $fid_cnf "%0s0\n", $the_cnf;
            }

            #Generating the constraints indicating that when a selection variable is chosen the literals in the product have a high/low value as determined
            foreach my $j (1 .. $lat_in_cnt){
              if (defined $lat_var_arr[$j]){
                foreach my $k (1 .. $lit_num){
                  $cnf_cnt++;
                  if ($lit_var_arr[$k]){
                    printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                  }
                  else{
                    printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                  }
                }

                #For TRUE and FALSE
                $cnf_cnt++;
                printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$lit_num+1][$j], $lat_var_arr[$j];
                $cnf_cnt++;
                printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$lit_num+2][$j], $lat_var_arr[$j];
              }
            }
          }
        }

        #Generating constraints indicating that a lattice product must not realize the target product with one less term
        #my $conf_cnt = 0;
        #my @conf_arr = ();
        #foreach my $i (1 .. $prod_cnt_simp){
        #  if ($prod_lvl_simp[$i] > 1){
        #    my $the_pointer = 1;
        #    do{
        #      my $the_cnt = 0;
        #      my @the_arr = ();
        #      my $the_title = "";
        #      foreach my $j (1 .. $prod_lvl_simp[$i]){
        #        if ($j != $the_pointer){
        #          $the_cnt++;
        #          $the_arr[$the_cnt] = $prod_arr_simp[$j][$i];
        #          $the_title .= $prod_arr_simp[$j][$i];
        #        }
        #      }
        #      
        #      if (!is_inside_array_list($the_cnt, $conf_cnt, \@the_arr, \@conf_arr)){
        #        $conf_cnt++;
        #        $conf_arr[0][$conf_cnt]=$the_cnt;
        #        foreach my $j (1 .. $the_cnt){
        #          $conf_arr[$j][$conf_cnt] = $the_arr[$j];
        #        }

        #        my @var_index_arr = ();
        #        foreach my $j (1 .. $lat_in_cnt){
        #          $var_index_arr[$j] = 0;
        #        }

        #        foreach my $j (1 .. $lat_prod_cnt){
        #          if ($the_cnt <= $lat_prod_lvl[$j]){
        #            $the_cnf = "";
        #            foreach my $k (1 .. $lat_prod_lvl[$j]){
        #              my $the_index = $lat_prod_arr[$k][$j] + 0.0;
        #              if (!$var_index_arr[$the_index]){
        #                $var_cnt++;
        #                $var_index_arr[$the_index] = $var_cnt;
        #                printf $fid_var "%0d = %0s_%0s \n", $var_cnt, $lat_prod_arr[$k][$j], $the_title;
        #              }
        #              $the_cnf = $the_cnf . "-" . $var_index_arr[$the_index] . " ";
        #            }
        #            $cnf_cnt++;
        #            printf $fid_cnf "%0s0\n", $the_cnf;  
        #          }
        #        }

        #        foreach my $j (1 .. $lat_in_cnt){
        #          if ($var_index_arr[$j]){
        #            foreach my $k (1 .. $lit_num){
        #              my $the_var = "";
        #              if ($lit_arr[$k] < 0){
        #                $the_var .= "!";
        #              }
        #              $the_var .= $in_arr[abs($lit_arr[$k])];
        #              my $the_index = is_inside_string_array($the_var, $the_cnt, @the_arr);

        #              if ($the_index){
        #                $the_cnf = "-" . $invar_lit_arr[$k][$j] . " " . $var_index_arr[$j];
        #              }
        #              else{
        #                $the_cnf = "-" . $invar_lit_arr[$k][$j] . " -" . $var_index_arr[$j];
        #              }
        #              $cnf_cnt++;
        #              printf $fid_cnf "%0s 0\n", $the_cnf;  
        #            }

        #            $cnf_cnt++;
        #            $the_cnf = "-" . $invar_lit_arr[$lit_num+1][$j] . " -" . $var_index_arr[$j];
        #            printf $fid_cnf "%0s 0\n", $the_cnf;
        #            $cnf_cnt++;
        #            $the_cnf = "-" . $invar_lit_arr[$lit_num+2][$j] . " -" . $var_index_arr[$j];
        #            printf $fid_cnf "%0s 0\n", $the_cnf;
        #          }
        #        }
        #      }

        #      $the_pointer++;
        #    }while ($the_pointer <= $prod_lvl_simp[$i]);
        #  }
        #}
      }
    }

    if ($cnf_cnt > 20000000){
      $the_ready = 0;
    }
    
    close $fid_cnf;
    close $fid_var;
    if ($the_verb <= 1){print MAGENTA, "[INFO] SAT problem on the target function, #variables: $var_cnt #clauses: $cnf_cnt \n", RESET;}
  }

  return ($the_ready, $var_cnt, $cnf_cnt, $netvar_cnt, $netcnf_cnt, \@invar_lit_arr);
}

sub bergman_dual{
  my ($the_verb, $file_dir, $path_sat, $prob_size_simp, $row_num, $col_num, $in_num, $lit_num, $tar_deg, $lat_deg, $in_arr_ref, $lit_arr_ref, $tt_arr_ref, $lat_in_cnt_dual, $prod_cnt_dual, $lat_prod_cnt_dual, $lat_prod_cnt_simp, $lat_in_arr_dual_ref, $single_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $lat_prod_lvl_dual_ref, $lat_prod_lvl_simp_ref, $prod_arr_dual_ref, $lat_prod_arr_dual_ref, $lat_prod_arr_simp_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @tt_arr = @ {$tt_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};

  my @single_lit_simp = @ {$single_lit_simp_ref};
  my @single_lit_dual = @ {$single_lit_dual_ref};

  #Related to the dual of the target function
  my @prod_arr_dual = @ {$prod_arr_dual_ref};
  my @prod_lvl_dual = @ {$prod_lvl_dual_ref};
  
  #Related to 8-terminal
  my $lat_in_cnt = $lat_in_cnt_dual;
  my $lat_prod_cnt = $lat_prod_cnt_dual;
  my @lat_in_arr = @ {$lat_in_arr_dual_ref};
  my @lat_prod_arr = @ {$lat_prod_arr_dual_ref};
  my @lat_prod_lvl = @ {$lat_prod_lvl_dual_ref};
  
  #Related to 4-terminal
  my @lat_prod_arr_simp = @ {$lat_prod_arr_simp_ref};
  my @lat_prod_lvl_simp = @ {$lat_prod_lvl_simp_ref};

  my $the_end = 0;
  my $var_cnt = 0;
  my $cnf_cnt = 0;
  my $the_ready = 1;
  my $netvar_cnt = 0;
  my $netcnf_cnt = 0;
  my @invar_lit_arr = ();

  if ($lat_in_cnt){
    if (!$the_verb){print "[INFO] Generating the SAT problem... \n";}
    my $file_cnf = $file_dir . "sat_problem_dual.cnf";
    my $file_var = $file_dir . "sat_problem_dual.var";
    open (my $fid_cnf, '>', $file_cnf);
    open (my $fid_var, '>', $file_var);
    printf $fid_cnf "p cnf 1 1 \n";

    my $the_cnf = "";
    my @latvar_tt_arr = ();

    #Generating the lattice network and lattice inputs for each truth table entry
    foreach my $tt_var (0 .. 2**$in_num-1){
      my $first_latvar = $var_cnt+1;
      foreach my $in_var (1 .. $lat_in_cnt){
        $var_cnt++;
        $latvar_tt_arr[$in_var][$tt_var] = $var_cnt;
        printf $fid_var "%0d = %0s_tt%0d \n", $var_cnt, $lat_in_arr[$in_var], $tt_var;
      }

      if ($tt_arr[$tt_var][$in_num+1]){
        $the_cnf = "";
        foreach my $i (1 .. $lat_prod_cnt){
          my $and_in_cnt = 0;
          my @and_in_arr = ();
          my $and_label = "AND";
          foreach my $j (1 .. $lat_prod_lvl[$i]){
            $and_in_cnt++;
            $and_label = $and_label . "_" . $lat_prod_arr[$j][$i];
            $and_in_arr[$and_in_cnt] = $first_latvar + $lat_prod_arr[$j][$i] - 1;
          }
          $var_cnt++;
          $the_cnf = $the_cnf . $var_cnt . " ";
          printf $fid_var "%0d = %0s_tt%0d \n", $var_cnt, $and_label, $tt_var;

          ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
        }
        $cnf_cnt++;
        printf $fid_cnf "%0s0 \n", $the_cnf;

        #Generating constraints indicating that all the lattice variables in each column should not be low
        foreach my $col_var (1 .. $col_num){
          $the_cnf = "";
          foreach my $row_var (1 .. $row_num){
            my $the_index = $first_latvar + ($row_var-1)*$col_num+$col_var - 1;
            $the_cnf = $the_cnf . $the_index . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        #Generating constraints indicating that all the variables in each path in the lattice function (which blocks any path from left-right) should not be low 
        #foreach my $i (1 .. $lat_prod_cnt_simp){
        #  $the_cnf = "";
        #  foreach my $j (1 .. $lat_prod_lvl_simp[$i]){
        #    my $the_index = $first_latvar + $lat_prod_arr_simp[$j][$i] - 1;
        #    $the_cnf = $the_cnf . $the_index . " ";
        #  }
        #  $cnf_cnt++;
        #  printf $fid_cnf "%0s0 \n", $the_cnf;
        #}

        if ($col_num >= 2){
          #Generating constraints indicating that in each consecutive rows if there must be at least one case that two rows in the same column or acrosses are high
          foreach my $col_var (1 .. $col_num-1){
            $the_cnf = "";
            foreach my $row_var (1 .. $row_num){
              my $and_in_cnt = 2;
              my @and_in_arr = ();
              
              $and_in_cnt = 2;
              $and_in_arr[1] = $first_latvar + ($row_var-1)*$col_num+$col_var - 1;
              $and_in_arr[2] = $first_latvar + ($row_var-1)*$col_num+$col_var;
              $var_cnt++;
              printf $fid_var "%0d = AND_%0d_%0d \n", $var_cnt, $first_latvar+($row_var-1)*$col_num+$col_var-1, $first_latvar+($row_var-1)*$col_num+$col_var;
              ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
              $the_cnf = $the_cnf . $var_cnt . " ";

              if ($row_var != 1){
                $and_in_cnt = 2;
                $and_in_arr[1] = $first_latvar + ($row_var-1)*$col_num+$col_var - 1;
                $and_in_arr[2] = $first_latvar + ($row_var-2)*$col_num+$col_var;
                $var_cnt++;
                printf $fid_var "%0d = AND_%0d_%0d \n", $var_cnt, $first_latvar+($row_var-1)*$col_num+$col_var-1, $first_latvar+($row_var-2)*$col_num+$col_var;
                ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
                $the_cnf = $the_cnf . $var_cnt . " ";
              }
              if ($row_var != $row_num){
                $and_in_cnt = 2;
                $and_in_arr[1] = $first_latvar + ($row_var-1)*$col_num+$col_var - 1;
                $and_in_arr[2] = $first_latvar + ($row_var)*$col_num+$col_var;
                $var_cnt++;
                printf $fid_var "%0d = AND_%0d_%0d \n", $var_cnt, $first_latvar+($row_var-1)*$col_num+$col_var-1, $first_latvar+($row_var)*$col_num+$col_var;
                ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
                $the_cnf = $the_cnf . $var_cnt . " ";
              }
            }
            $cnf_cnt++;
            printf $fid_cnf "%0s0 \n", $the_cnf;
          }
        }
      }
      else{
        foreach my $i (1 .. $lat_prod_cnt){
          $the_cnf = "";
          foreach my $j (1 .. $lat_prod_lvl[$i]){
            my $the_index = $first_latvar + $lat_prod_arr[$j][$i] - 1;
            $the_cnf = $the_cnf . "-". $the_index . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }
      }

      if ($cnf_cnt*$var_cnt > $prob_size_simp){
        close $fid_cnf;
        close $fid_var;
        $the_ready = 0;
        $netvar_cnt = $var_cnt;
        $netcnf_cnt = $cnf_cnt;
        if ($the_verb <= 1){print MAGENTA, "[INFO] SAT problem on the dual of the target function is greater than that of on the target function. Returning... \n", RESET;}
        return ($the_ready, $var_cnt, $cnf_cnt, $netvar_cnt, $netcnf_cnt, \@invar_lit_arr);
      }

      if ($cnf_cnt > 20000000){
        $the_end = 1;
        print BRIGHT_YELLOW "[WARNING] Number of constraints has exceeded the limit! Completing the generation of the SAT problem... \n";
        last;
      }
    }

    #Generating the selection variables and the necessary constraints
    if (!$the_end){
      foreach my $in_var (1 .. $lat_in_cnt){
        foreach my $lit_var (1 .. $lit_num){
          if ($lit_arr[$lit_var] > 0){
            $var_cnt++;
            $invar_lit_arr[$lit_var][$in_var] = $var_cnt;
            printf $fid_var "%0d = %0s_pos%0s \n", $var_cnt, $lat_in_arr[$in_var], $in_arr[$lit_arr[$lit_var]];
            ($cnf_cnt) = write_selection_constraints(1, $fid_cnf, $cnf_cnt, $in_var, $lit_var, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);
          }
          else{
            $var_cnt++;
            $invar_lit_arr[$lit_var][$in_var] = $var_cnt;
            printf $fid_var "%0d = %0s_neg%0s \n", $var_cnt, $lat_in_arr[$in_var], $in_arr[abs($lit_arr[$lit_var])];
            ($cnf_cnt) = write_selection_constraints(0, $fid_cnf, $cnf_cnt, $in_var, $lit_var, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);
          }
        }

        #For TRUE and FALSE
        $var_cnt++;
        $invar_lit_arr[$lit_num+1][$in_var] = $var_cnt;
        printf $fid_var "%0d = %0s_true \n", $var_cnt, $lat_in_arr[$in_var];
        ($cnf_cnt) = write_selection_constraints(3, $fid_cnf, $cnf_cnt, $in_var, 0, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);
        $var_cnt++;
        $invar_lit_arr[$lit_num+2][$in_var] = $var_cnt;
        printf $fid_var "%0d = %0s_false \n", $var_cnt, $lat_in_arr[$in_var];
        ($cnf_cnt) = write_selection_constraints(2, $fid_cnf, $cnf_cnt, $in_var, 0, $var_cnt, $in_num, \@lit_arr, \@latvar_tt_arr, \@tt_arr);

        $the_cnf = "";
        foreach my $i (1 .. $lit_num+1){
          $the_cnf = $the_cnf . $invar_lit_arr[$i][$in_var] . " ";
          foreach my $j ($i+1 .. $lit_num+2){
            $cnf_cnt++;
            printf $fid_cnf "-%0d -%0d 0 \n", $invar_lit_arr[$i][$in_var], $invar_lit_arr[$j][$in_var];
          }
        }
        $cnf_cnt++;
        printf $fid_cnf "%0s%0d 0 \n", $the_cnf, $invar_lit_arr[$lit_num+2][$in_var];

        if ($cnf_cnt*$var_cnt > $prob_size_simp){
          close $fid_cnf;
          close $fid_var;
          $the_ready = 0;
          $netvar_cnt = $var_cnt;
          $netcnf_cnt = $cnf_cnt;
          if ($the_verb <= 1){print MAGENTA, "[INFO] SAT problem on the dual of the target function is greater than that of on the target function. Returning... \n", RESET;}
          return ($the_ready, $var_cnt, $cnf_cnt, $netvar_cnt, $netcnf_cnt, \@invar_lit_arr);
        }

        if ($cnf_cnt > 20000000){
          $the_end=1;
          print BRIGHT_YELLOW "[WARNING] Number of constraints has exceeded the limit! Completing the generation of the SAT problem... \n";
          last;
        }
      }

      #Assuming that the dual of the target function is not TRUE, the terms in the products cannot be TRUE at the same time
      if (!$the_end){
        foreach my $i (1 .. $lat_prod_cnt){
          $the_cnf = "";
          foreach my $j (1 .. $lat_prod_lvl[$i]){
            my $the_var = $lat_prod_arr[$j][$i] + 0.0;
            $the_cnf = $the_cnf . "-" . $invar_lit_arr[$lit_num+1][$the_var] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        #Assuming that the dual of the target function is not FALSE, for each column, the entiries on each row cannot be FALSE at the same time
        foreach my $i (1 .. $col_num){
          $the_cnf = "";
          foreach my $j (1 .. $row_num){
            my $the_var = $i + ($j-1)*$col_num;
            $the_cnf = $the_cnf . "-" . $invar_lit_arr[$lit_num+2][$the_var] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        $netvar_cnt = $var_cnt;
        $netcnf_cnt = $cnf_cnt;

        my @prod_considered = ();
        foreach my $i (1 .. $prod_cnt_dual){
          $prod_considered[$i] = 0;
        }

        #Generating constraints indicating that WHEN the degree of the target and lattice functions are the same, the products with this degree in the lattice function should realize the ones with the same degree in the target function
        if ($tar_deg == $lat_deg){
          foreach my $i (1 .. $prod_cnt_dual){
            if ($prod_lvl_dual[$i] == $tar_deg){
              $prod_considered[$i] = 1;
              
              my @lit_var_arr = ();
              foreach my $j (1 .. $lit_num){
                $lit_var_arr[$j] = 0;
              }
              #Generating the product label and lit_var_arr indicating the literals of the product in the lit_arr
              my $prod_label = "";
              foreach my $k (1 .. $prod_lvl_dual[$i]){
                $prod_label .= $prod_arr_dual[$k][$i];

                my $var_index = 1;
                my $the_var = $prod_arr_dual[$k][$i];
                if (index($the_var, "!") != -1){
                  $var_index = -1;
                  $the_var = substr($the_var, 1, length($the_var)-1);
                }
                my $in_index = is_inside_string_array($the_var, $in_num, @in_arr);
                $var_index = $var_index * $in_index;
                my $lit_index = is_inside_numeric_array($var_index, $lit_num, @lit_arr);
                $lit_var_arr[$lit_index] = 1;
              }
              
              $the_cnf = "";
              my @lat_var_arr = ();
              foreach my $j (1 .. $lat_prod_cnt){
                if ($prod_lvl_dual[$i] == $lat_prod_lvl[$j]){
                  my $and_in_cnt = 0;
                  my @and_in_arr = ();
                  my $and_label = "AND";
                  foreach my $k (1 .. $lat_prod_lvl[$j]){
                    my $the_index = $lat_prod_arr[$k][$j] + 0.0;
                    $and_label = $and_label . "_" . $the_index;

                    if (!(defined $lat_var_arr[$the_index])){
                      $var_cnt++;
                      printf $fid_var "%0d = %d_%0s \n", $var_cnt, $the_index, $prod_label;
                      $lat_var_arr[$the_index] = $var_cnt;
                    }

                    $and_in_cnt++;
                    $and_in_arr[$and_in_cnt] = $lat_var_arr[$the_index];
                  }

                  $var_cnt++;
                  printf $fid_var "%0d = %0s_%0s \n", $var_cnt, $and_label, $prod_label;
                  ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
                  $the_cnf = $the_cnf . $var_cnt . " ";
                }
              }

              #Generating the constraints indicating that at least one of products in the lattice function should realize the product in the target function
              if ($the_cnf ne ""){
                $cnf_cnt++;
                printf $fid_cnf "%0s0\n", $the_cnf;
              }

              #Generating the constraints indicating that when a selection variable is chosen the literals in the product have a high/low value as determined
              foreach my $j (1 .. $lat_in_cnt){
                if (defined $lat_var_arr[$j]){
                  foreach my $k (1 .. $lit_num){
                    $cnf_cnt++;
                    if ($lit_var_arr[$k]){
                      printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                    }
                    else{
                      printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                    }
                  }

                  #For TRUE and FALSE
                  $cnf_cnt++;
                  printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$lit_num+1][$j], $lat_var_arr[$j];
                  $cnf_cnt++;
                  printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$lit_num+2][$j], $lat_var_arr[$j];
                }
              }
            }
          }
        }

        #Generating constraints indicating that if there is a single term product then one of the entries in the lattice should be equal to this literal
        foreach my $i (1 .. $single_lit_simp[0]){
          $the_cnf = "";
          foreach my $j (1 .. $lat_in_cnt){
            $the_cnf = $the_cnf . $invar_lit_arr[$single_lit_simp[$i]][$j] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        foreach my $i (1 .. $single_lit_dual[0]){
          $the_cnf = "";
          foreach my $j (1 .. $lat_in_cnt){
            $the_cnf = $the_cnf . $invar_lit_arr[$single_lit_dual[$i]][$j] . " ";
          }
          $cnf_cnt++;
          printf $fid_cnf "%0s0 \n", $the_cnf;
        }

        #Generating constraints indicating that the literals in the target function should appear at least in one entry of the lattice
        foreach my $i (1 .. $lit_num){
          if (!is_inside_numeric_array($i, $single_lit_simp[0], @single_lit_simp) and !is_inside_numeric_array($i, $single_lit_dual[0], @single_lit_dual)){
            $the_cnf = "";
            foreach my $j (1 .. $lat_in_cnt){
              $the_cnf = $the_cnf . $invar_lit_arr[$i][$j] . " ";
            }
            $cnf_cnt++;
            printf $fid_cnf "%0s0 \n", $the_cnf;
          }
        }

        #Generating constraints indicating that the single term product if there is any should be placed on the first column of the lattice
        #foreach my $i (1 .. $single_lit_dual[0]){
        #  $the_cnf = "";
        #  foreach my $j (1 .. $row_num){
        #    $the_cnf = $the_cnf . $invar_lit_arr[$single_lit_dual[$i]][($j-1)*$col_num+1] . " ";
        #  }
        #  $cnf_cnt++;
        #  printf $fid_cnf "%0s0 \n", $the_cnf;
        #}

        #Generating constraints indicating that a product in the dual of the target function must be realized by at least one of products in the dual of the lattice function
        foreach my $i (1 .. $prod_cnt_dual){
          if ($prod_lvl_dual[$i] > 5 and !$prod_considered[$i]){
            my @lit_var_arr = ();
            foreach my $j (1 .. $lit_num){
              $lit_var_arr[$j] = 0;
            }

            #Generating the product label and lit_var_arr indicating the literals of the product in the lit_arr
            my $prod_label = "";
            foreach my $k (1 .. $prod_lvl_dual[$i]){
              $prod_label .= $prod_arr_dual[$k][$i];

              my $var_index = 1;
              my $the_var = $prod_arr_dual[$k][$i];
              if (index($the_var, "!") != -1){
                $var_index = -1;
                $the_var = substr($the_var, 1, length($the_var)-1);
              }
              my $in_index = is_inside_string_array($the_var, $in_num, @in_arr);
              $var_index = $var_index * $in_index;
              my $lit_index = is_inside_numeric_array($var_index, $lit_num, @lit_arr);
              $lit_var_arr[$lit_index] = 1;
            }
            
            $the_cnf = "";
            my @lat_var_arr = ();
            foreach my $j (1 .. $lat_prod_cnt){
              if ($prod_lvl_dual[$i] <= $lat_prod_lvl[$j]){
                my $and_in_cnt = 0;
                my @and_in_arr = ();
                my $and_label = "AND";
                foreach my $k (1 .. $lat_prod_lvl[$j]){
                  my $the_index = $lat_prod_arr[$k][$j] + 0.0;
                  $and_label = $and_label . "_" . $the_index;

                  if (!(defined $lat_var_arr[$the_index])){
                    $var_cnt++;
                    printf $fid_var "%0d = %d_%0s \n", $var_cnt, $the_index, $prod_label;
                    $lat_var_arr[$the_index] = $var_cnt;
                  }

                  $and_in_cnt++;
                  $and_in_arr[$and_in_cnt] = $lat_var_arr[$the_index];
                }

                $var_cnt++;
                printf $fid_var "%0d = %0s_%0s \n", $var_cnt, $and_label, $prod_label;
                ($cnf_cnt) = write_and_cnffile($fid_cnf, $cnf_cnt, $var_cnt, $and_in_cnt, @and_in_arr);
                $the_cnf = $the_cnf . $var_cnt . " ";
              }
            }

            #Generating the constraints indicating that at least one of products in the lattice function should realize the product in the target function
            if ($the_cnf ne ""){
              $cnf_cnt++;
              printf $fid_cnf "%0s0\n", $the_cnf;
            }

            #Generating the constraints indicating that when a selection variable is chosen the literals in the product have a high/low value as determined
            foreach my $j (1 .. $lat_in_cnt){
              if (defined $lat_var_arr[$j]){
                foreach my $k (1 .. $lit_num){
                  $cnf_cnt++;
                  if ($lit_var_arr[$k]){
                    printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                  }
                  else{
                    printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$k][$j], $lat_var_arr[$j];
                  }
                }

                #For TRUE and FALSE
                $cnf_cnt++;
                printf $fid_cnf "-%d %d 0 \n", $invar_lit_arr[$lit_num+1][$j], $lat_var_arr[$j];
                $cnf_cnt++;
                printf $fid_cnf "-%d -%d 0 \n", $invar_lit_arr[$lit_num+2][$j], $lat_var_arr[$j];
              }
            }
          }
        }
        
        #Generating constraints indicating that a lattice product must not realize the target product with one less term
        #my $conf_cnt = 0;
        #my @conf_arr = ();
        #foreach my $i (1 .. $prod_cnt_dual){
        #  if ($prod_lvl_dual[$i] > 1){
        #    my $the_pointer = 1;
        #    do{
        #      my $the_cnt = 0;
        #      my @the_arr = ();
        #      my $the_title = "";
        #      foreach my $j (1 .. $prod_lvl_dual[$i]){
        #        if ($j != $the_pointer){
        #          $the_cnt++;
        #          $the_arr[$the_cnt] = $prod_arr_dual[$j][$i];
        #          $the_title .= $prod_arr_dual[$j][$i];
        #        }
        #      }
        #      
        #      if (!is_inside_array_list($the_cnt, $conf_cnt, \@the_arr, \@conf_arr)){
        #        $conf_cnt++;
        #        $conf_arr[0][$conf_cnt]=$the_cnt;
        #        foreach my $j (1 .. $the_cnt){
        #          $conf_arr[$j][$conf_cnt] = $the_arr[$j];
        #        }

        #        my @var_index_arr = ();
        #        foreach my $j (1 .. $lat_in_cnt){
        #          $var_index_arr[$j] = 0;
        #        }

        #        foreach my $j (1 .. $lat_prod_cnt){
        #          if ($the_cnt <= $lat_prod_lvl[$j]){
        #            $the_cnf = "";
        #            foreach my $k (1 .. $lat_prod_lvl[$j]){
        #              my $the_index = $lat_prod_arr[$k][$j] + 0.0;
        #              if (!$var_index_arr[$the_index]){
        #                $var_cnt++;
        #                $var_index_arr[$the_index] = $var_cnt;
        #                printf $fid_var "%0d = %0s_%0s \n", $var_cnt, $lat_prod_arr[$k][$j], $the_title;
        #              }
        #              $the_cnf = $the_cnf . "-" . $var_index_arr[$the_index] . " ";
        #            }
        #            $cnf_cnt++;
        #            printf $fid_cnf "%0s0\n", $the_cnf;  
        #          }
        #        }

        #        foreach my $j (1 .. $lat_in_cnt){
        #          if ($var_index_arr[$j]){
        #            foreach my $k (1 .. $lit_num){
        #              my $the_var = "";
        #              if ($lit_arr[$k] < 0){
        #                $the_var .= "!";
        #              }
        #              $the_var .= $in_arr[abs($lit_arr[$k])];
        #              my $the_index = is_inside_string_array($the_var, $the_cnt, @the_arr);

        #              if ($the_index){
        #                $the_cnf = "-" . $invar_lit_arr[$k][$j] . " " . $var_index_arr[$j];
        #              }
        #              else{
        #                $the_cnf = "-" . $invar_lit_arr[$k][$j] . " -" . $var_index_arr[$j];
        #              }
        #              $cnf_cnt++;
        #              printf $fid_cnf "%0s 0\n", $the_cnf;  
        #            }

        #            $cnf_cnt++;
        #            $the_cnf = "-" . $invar_lit_arr[$lit_num+1][$j] . " -" . $var_index_arr[$j];
        #            printf $fid_cnf "%0s 0\n", $the_cnf;
        #            $cnf_cnt++;
        #            $the_cnf = "-" . $invar_lit_arr[$lit_num+2][$j] . " -" . $var_index_arr[$j];
        #            printf $fid_cnf "%0s 0\n", $the_cnf;
        #          }
        #        }
        #      }

        #      $the_pointer++;
        #    }while ($the_pointer <= $prod_lvl_dual[$i]);
        #  }
        #}
      }
    }

    if ($cnf_cnt > 20000000){
      $the_ready = 0;
    }
    
    close $fid_cnf;
    close $fid_var;
    if ($the_verb <= 1){print MAGENTA, "[INFO] SAT problem on the dual of the target function, #variables: $var_cnt #clauses: $cnf_cnt \n", RESET;}
  }

  return ($the_ready, $var_cnt, $cnf_cnt, $netvar_cnt, $netcnf_cnt, \@invar_lit_arr);
}

sub remove_dontcare_inputs{
  my ($file_simp) = @_;
  
  my $in_num = 0;
  my $out_num = 0;
  my $prod_num = 0;

  my @in_arr = ();
  my @out_arr = ();
  my @prod_arr = ();

  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  my $ndc_in_cnt;
  my @ndc_in_arr;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $in_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $out_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $in_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_cnt++;
          $in_arr[$in_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $out_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_cnt++;
          $out_arr[$out_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".") == -1){
        $prod_num++;

        my $in_cnt = 0;
        $the_index = skip_spaces_forward($the_line, 0);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $in_cnt++;
          $prod_arr[$in_cnt][$prod_num] = $the_char;
          $the_index++;

          if ($in_cnt == $in_num){
            last;
          }
        }

        my $out_cnt = 0;
        $the_index = skip_spaces_forward($the_line, $the_index);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $out_cnt++;
          $prod_arr[$in_num+$out_cnt][$prod_num] = substr($the_line, $the_index , 1);
          $the_index++;

          if ($out_cnt == $out_num){
            last;
          }
        }
      }
    }
    
    close $file_header;

    if (!(@in_arr)){
      foreach my $i (1 .. $in_num){
        $in_arr[$i] = $i;
      }
    }

    #Check if an input variable is DC
    my $dcin_cnt = 0;
    my @dcin_arr = ();
    foreach my $i (1 .. $in_num){
      my $is_dcin = 1;
      foreach my $j (1 .. $prod_num){
        if ($prod_arr[$i][$j] eq "0" or $prod_arr[$i][$j] eq "1"){
          $is_dcin = 0;
          last;
        }
      }

      if ($is_dcin){
        #print "[INFO] The $in_arr[$i] input is always DC and hence, is removed from the input list \n";
        $dcin_cnt++;
        $dcin_arr[$dcin_cnt] = $i;
      }
    }

    if ($dcin_cnt){
      $ndc_in_cnt = 0;
      @ndc_in_arr = ();

      open (my $fid_pla, '>', $file_simp);
      printf $fid_pla ".i %0d \n", $in_num - $dcin_cnt;
      printf $fid_pla ".o %0d \n", $out_num;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_num){
          if (!is_inside_numeric_array($i, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s ", $in_arr[$i];

            $ndc_in_cnt++;
            $ndc_in_arr[$ndc_in_cnt] = $in_arr[$i];
          }
        }
        printf $fid_pla "\n";
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_num){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".p %0d \n", $prod_num;
      foreach my $i (1 .. $prod_num){
        foreach my $j (1 .. $in_num){
          if (!is_inside_numeric_array($j, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s", $prod_arr[$j][$i];
          }
        }
        printf $fid_pla " ";
        foreach my $j (1 .. $out_num){
          printf $fid_pla "%0s", $prod_arr[$in_num+$j][$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".e \n";
      close ($fid_pla);
    }
    else{
      $ndc_in_cnt = $in_num;
      @ndc_in_arr = @in_arr;
    }

  }
  else{
    print RED, "Could not open the $file_simp file \n";
  }

  return ($ndc_in_cnt, @ndc_in_arr);
}

sub simplify_sop{
  my ($file_dir, $the_file, $path_espresso) = @_;
  #print "The file: $the_file \n";

  my $in_cnt = 0;
  my $in_say = 0;
  my $lit_cnt = 0;
  my $out_cnt = 0;
  my $out_say = 0;
  my @in_arr = ();
  my @tt_arr = ();
  my @lit_arr = ();
  my @out_arr = ();
  
  my $deg_simp = 0;
  my $prod_simp = 0;
  my $mindeg_simp = 0;
  my $prod_cnt_simp = 0;
  my @prod_num_simp = ();
  my @prod_lvl_simp = ();
  my @prod_ind_simp = ();
  my @prod_arr_simp = ();
  
  my $init_index = 0;
  my $last_index = 0;

  my $dot_index = index($the_file, ".pla");
  my $file_simp = substr($the_file, 0, $dot_index) . "_simp.pla";

  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $prod_cnt = 0;
    my @prod_arr = ();
    my $minreq_cnt = 0;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $minreq_cnt++;
        $in_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $minreq_cnt++;
        $out_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_say++;
          $in_arr[$in_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($in_cnt and $in_say != $in_cnt){
          print RED, "[ERROR] The number of inputs is not the same as the number of input labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_say++;
          $out_arr[$out_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($out_cnt and $out_say != $out_cnt){
          print RED, "[ERROR] The number of outputs is not the same as the number of output labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".") == -1){
        if ($minreq_cnt < 2){
          $prod_cnt++;
          $prod_arr[$prod_cnt] = $the_line;
        }
      }
    }

    close $file_header;

    if ($minreq_cnt < 2){
      my $init_index = skip_spaces_forward($prod_arr[1], 0);
      my $last_index = index($prod_arr[1], " ", $init_index);
      $in_cnt = $last_index - $init_index;

      $last_index = skip_spaces_forward($prod_arr[1], $last_index);
      while (substr($prod_arr[1], $last_index, 1) ne " "){
        $last_index++;
        $out_cnt++;

        if ($last_index >= length($prod_arr[1])){
          last;
        }
      }

      my $file_temp = $file_dir . "temp_file.pla";
      open (my $fid_pla, '>', $file_temp);
      printf $fid_pla ".i %0s \n", $in_cnt;
      printf $fid_pla ".o %0s \n", $out_cnt;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_say){
          printf $fid_pla "%0s ", $in_arr[$i];
        }
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_say){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
      }
      printf $fid_pla ".p %0s \n", $prod_cnt;
      foreach my $i (1 .. $prod_cnt){
        printf $fid_pla "%0s \n", $prod_arr[$i];
      }
      printf $fid_pla ".e \n";
      close $fid_pla;

      my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_simp;
      system($the_cmd);
    }
    else{
      my $the_cmd = $path_espresso . " -Dexact " . $the_file . " > " . $file_simp;
      system($the_cmd);
    }

    if (!@in_arr){
      foreach my $i (1 .. $in_cnt){
        $in_arr[$i] = "$i";
      }
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
    return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
  }

  ($in_cnt, @in_arr) = remove_dontcare_inputs($file_simp);

  #Generating the initial truth table with full of zeros
  foreach my $i (0 .. 2**$in_cnt-1) {
    my @bin_rep = convert2binary($i, $in_cnt);
    foreach my $j (1 .. $in_cnt){
      $tt_arr[$i][$j] = $bin_rep[$j];
    }
    $tt_arr[$i][$in_cnt+1] = 0;
  }

  #Display the truth table
  #foreach my $i (0 .. 2**$in_cnt-1){
  #  foreach my $j (1 .. $in_cnt+1){
  #    print "$tt_arr[$i][$j]";
  #  }
  #  print "\n";
  #}

  #Generating the initial literal index array
  my @lit_index_arr = ();
  foreach my $i (1 .. 2*$in_cnt){
    $lit_index_arr[$i] = 0;
  }

  my $neg_lit = 0;
  my $pos_lit = 0;
  #Find the degree for the upper bound and generate the truth table
  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".p ") != -1){
        my $the_index = 3;
        $prod_simp = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;

        if (!$prod_simp){
          $in_cnt = 0;
          print RED, "[INFO] The number of products in the simplified target function is zero. No need to run the lattice synthesis algorithm! \n", RESET;
          return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
        }
      }
      elsif (index($the_line, ".") == -1){
        my $x_cnt = 0;
        my @x_arr = ();
        my $the_base = 0;
        
        my $lit_num = 0;
        $prod_cnt_simp++;
        my $the_index = -1;
        my $the_char = " ";
            
        do{
          $the_index++;
          $the_char = substr($the_line, $the_index, 1);
          if ($the_char eq "0"){
            $lit_num++;
            $neg_lit = 1;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = "!" . $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = -1;

            $lit_index_arr[2*($the_index+1)]++;
          }
          elsif ($the_char eq "1"){
            $pos_lit = 1;
            $the_base = $the_base + 2**$the_index;
            
            $lit_num++;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 1;
            
            $lit_index_arr[2*($the_index+1)-1]++;
          }
          elsif ($the_char eq "-"){
            $x_cnt++;
            $x_arr[$x_cnt] = $the_index;
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 0;
          }
        }while ($the_char ne " ");

        if (defined $prod_num_simp[$lit_num]){
          $prod_num_simp[$lit_num]++;
        }
        else{
          $prod_num_simp[$lit_num] = 1;
        }

        if ($lit_num > $deg_simp){
          $deg_simp = $lit_num;
        }

        #Find the truth table entries where the function is high
        if ($x_cnt){
          my @val_arr = ();
          my $the_pointer = 0;

          foreach my $i (1 .. $x_cnt){
            $val_arr[$i] = 0;
          }

          do{
            #Display the val_arr
            #foreach my $i (1 .. $x_cnt){
            #  print "$val_arr[$i]";
            #}
            #print "\n";

            $the_pointer = 1;

            my $x_sum = $the_base;
            foreach my $i (1 .. $x_cnt){
              $x_sum = $x_sum + $val_arr[$i] * 2**$x_arr[$i];
            }
            $tt_arr[$x_sum][$in_cnt+1] = 1;

            while ($val_arr[$the_pointer]){
              $val_arr[$the_pointer] = 0;
              $the_pointer++;

              if ($the_pointer > $x_cnt){
                last;
              }
            }

            if ($the_pointer <= $x_cnt){
              $val_arr[$the_pointer] = 1;
            }  
          }while ($the_pointer <= $x_cnt);
        }
        else{
          $tt_arr[$the_base][$in_cnt+1] = 1;
        }
      }
    }

    #Display the truth table
    #foreach my $i (0 .. 2**$in_cnt-1){
    #  foreach my $j (1 .. $in_cnt+1){
    #    print "$tt_arr[$i][$j]";
    #  }
    #  print "\n";
    #}

    close $file_header;
  }
  else{
    $in_cnt = 0;
    print RED, "[ERROR] Could not open the $file_simp file! \n", RESET;
    return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
  }

  #Generating the literal array including the literals to be considered
  foreach my $i (1 .. 2*$in_cnt){
    if ($lit_index_arr[$i]){
      $lit_cnt++;
      if ($i % 2){
        $lit_arr[$lit_cnt] = ($i+1)/2;
      }
      else{
        $lit_arr[$lit_cnt] = (-1)*($i)/2;
      }
    }
  }

  #Find the minimum degree for the lower bound in a recursive fashion
  my $file_prim = substr($the_file, 0, $dot_index) . "_simp_prim.pla";
  my $the_cmd = $path_espresso . " -Dprimes " . $file_simp . " > " . $file_prim;
  system($the_cmd);
  
  while (1) {
    my $max_deg = 0;
    my $min_deg = 9*9*9;

    my @lit_mat = ();
    my $prim_cnt = 0;
    my @prim_arr = ();
    my $maxprim_cnt = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".") == -1){
          my $lit_num = 0;
          my $the_index = -1;
          my $the_char = " ";

          $prim_cnt++;
          $prim_arr[$prim_cnt] = $the_line;

          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0" or $the_char eq "1"){
              $lit_num++;
            }
          }while ($the_char ne " ");

          $lit_mat[$prim_cnt] = $lit_num;

          if ($lit_num > $max_deg){
            $max_deg = $lit_num;
            $maxprim_cnt = 1;
          }
          elsif ($lit_num == $max_deg){
            $maxprim_cnt++;
          }
          
          if ($lit_num < $min_deg){
            $min_deg = $lit_num;
          }
        }
      }
      close $file_header;

      #print "Minimum number of literals: $min_deg \n";
      #print "Maximum number of literals: $max_deg \n";

      if ($min_deg < $max_deg){
        my $file_temp = $file_dir . "temp_file.pla";
        open (my $fid_temp, '>', $file_temp);
        foreach my $i (1 .. $prim_cnt){
          if ($lit_mat[$i] != $max_deg){
            printf $fid_temp "%0s \n", $prim_arr[$i];
          }
        }
        close $fid_temp;

        my $file_verify = $file_dir . "verify.out";
        my $the_cmd = $path_espresso . " -Dverify " . $file_simp . " " . $file_temp . " > ". $file_verify;
        system($the_cmd);

        my $is_verified = 0;
        if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, "compared equal") != -1){
              $is_verified = 1;
              last;
            }
          }

          if (!$is_verified){
            $mindeg_simp = $max_deg;
            last;
          }
          else{
            open (my $fid_prim, '>', $file_prim);
            printf $fid_prim ".i %0d \n", $in_cnt;
            printf $fid_prim ".o %0d \n", $out_cnt;
            printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
            foreach my $i (1 .. $prim_cnt){
              if ($lit_mat[$i] != $max_deg){
                printf $fid_prim "%0s \n", $prim_arr[$i];
              }
            }
            printf $fid_prim ".e \n";
            close $fid_prim;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
        }
      }
      else{
        $mindeg_simp = $max_deg;
        last;
      }
    }
    else{
      $in_cnt = 0;
      print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
      return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
    }
  }

  return ($file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
}

sub find_dual{
  my ($file_dir, $the_file, $path_espresso, $in_cnt, $out_cnt, $in_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};

  my @tt_arr = ();
  my $deg_num = 0;
  my $prod_cnt = 0;
  my @prod_lvl = ();
  my @prod_ind = ();
  my @prod_arr = ();
  my $mindeg_num = 0;
  my @prod_num_dual = ();
  
  my $dot_index = index($the_file, ".pla");
  my $file_dual = substr($the_file, 0, $dot_index) . "_dual.pla";

  #Generating the dual pla file by complementing each variable and the output function
  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_out, '>', $file_temp);
  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $first_prod = 1;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      
      my $the_char = "";
      my $the_index = 0;
     
      if (index($the_line, ".") == -1){
        #Complementing the output function
        if ($first_prod){
          printf $fid_out ".phase 0 \n";
          $first_prod = 0;
        }

        #Complementing the variable
        $the_index = skip_spaces_forward($the_line, $the_index);
        do {
          $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq "1"){
            printf $fid_out "0";
          }
          elsif ($the_char eq "0"){
            printf $fid_out "1";
          }
          elsif ($the_char eq "-" or $the_char eq " "){
            printf $fid_out "%0s", $the_char;
          }
          else{
            print "[WARNING] Only expecting 0 1 or - in this case. Something must be wrong! \n";
          }
          $the_index++;
        }while ($the_char ne " ");

        printf $fid_out "%0s \n", substr($the_line, $the_index, length($the_line)-$the_index+1);
      }
      else{
        printf $fid_out "%s \n", $the_line;
      }
    }

    close $file_header;
    close $fid_out;
    
    #Find the dual function with espresso
    my $the_cmd = $path_espresso . " -Dexact ". $file_temp . " > " . $file_dual;
    system($the_cmd);

    #Generating the initial truth table with full of zeros
    foreach my $i (0 .. 2**$in_cnt-1) {
      my @bin_rep = convert2binary($i, $in_cnt);
      foreach my $j (1 .. $in_cnt){
        $tt_arr[$i][$j] = $bin_rep[$j];
      }
      $tt_arr[$i][$in_cnt+1] = 0;
    }

    #Compute the degree of the dual function for the upper bound, determine the literals, and generate the truth table.
    if (open (my $file_header, '<:encoding(UTF-8)', $file_dual)){
      my $prod_num = 0;
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".p ") != -1){
          my $the_index = 3;
          $prod_cnt = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
        }
        elsif (index($the_line, ".") == -1){
          my $x_cnt = 0;
          my @x_arr = ();
          my $the_base = 0;
        
          my $lit_cnt = 0;
          $prod_num++;
          my $the_index = -1;
          my $the_char = " ";
          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0"){ 
              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = "!" . $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = -1;
            }
            elsif ($the_char eq "1"){
              $the_base = $the_base + 2**$the_index;

              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = 1;
            }
            elsif ($the_char eq "-") {
              $x_cnt++;
              $x_arr[$x_cnt] = $the_index;
              $prod_ind[$the_index+1][$prod_num] = 0;
            }
          }while ($the_char ne " ");

          if (defined $prod_num_dual[$lit_cnt]){
            $prod_num_dual[$lit_cnt]++;
          }
          else{
            $prod_num_dual[$lit_cnt] = 1;
          }

          if ($lit_cnt > $deg_num){
            $deg_num = $lit_cnt;
          }

          #Find the truth table entries where the function is high
          if ($x_cnt){
            my @val_arr = ();
            my $the_pointer = 0;

            foreach my $i (1 .. $x_cnt){
              $val_arr[$i] = 0;
            }

            do{
              $the_pointer = 1;

              my $x_sum = $the_base;
              foreach my $i (1 .. $x_cnt){
                $x_sum = $x_sum + $val_arr[$i] * 2**$x_arr[$i];
              }
              $tt_arr[$x_sum][$in_cnt+1] = 1;

              while ($val_arr[$the_pointer]){
                $val_arr[$the_pointer] = 0;
                $the_pointer++;

                if ($the_pointer > $x_cnt){
                  last;
                }
              }

              if ($the_pointer <= $x_cnt){
                $val_arr[$the_pointer] = 1;
              }  
            }while ($the_pointer <= $x_cnt);
          }
          else{
            $tt_arr[$the_base][$in_cnt+1] = 1;
          }
        }
      }
      close $file_header;

      #Compute the minimum degree for the lower bound in a recursive fashion
      my $file_prim = substr($the_file, 0, $dot_index) . "_dual_prim.pla";
      $the_cmd = $path_espresso . " -Dprimes " . $file_dual . " > " . $file_prim;
      system($the_cmd);
      
      while (1) {
        my $max_deg = 0;
        my $min_deg = 9*9*9;

        my @lit_arr = ();
        my $prim_cnt = 0;
        my @prim_arr = ();
        my $maxprim_cnt = 0;

        if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, ".") == -1){
              my $lit_cnt = 0;
              my $the_index = -1;
              my $the_char = " ";

              $prim_cnt++;
              $prim_arr[$prim_cnt] = $the_line;

              do{
                $the_index++;
                $the_char = substr($the_line, $the_index, 1);
                if ($the_char eq "0" or $the_char eq "1"){
                  $lit_cnt++;
                }
              }while ($the_char ne " ");

              $lit_arr[$prim_cnt] = $lit_cnt;

              if ($lit_cnt > $max_deg){
                $max_deg = $lit_cnt;
                $maxprim_cnt = 1;
              }
              elsif ($lit_cnt == $max_deg){
                $maxprim_cnt++;
              }
              
              if ($lit_cnt < $min_deg){
                $min_deg = $lit_cnt;
              }
            }
          }
          close $file_header;

          #print "Minimum number of literals: $min_deg \n";
          #print "Maximum number of literals: $max_deg \n";

          if ($min_deg < $max_deg){
            my $file_temp = $file_dir . "temp_file.pla";
            open (my $fid_temp, '>', $file_temp);
            foreach my $i (1 .. $prim_cnt){
              if ($lit_arr[$i] != $max_deg){
                printf $fid_temp "%0s \n", $prim_arr[$i];
              }
            }
            close $fid_temp;

            my $file_verify = $file_dir . "verify.out";
            $the_cmd = $path_espresso . " -Dverify " . $file_dual . " " . $file_temp . " > " . $file_verify;
            system($the_cmd);

            my $is_verified = 0;
            if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
              while (my $the_line = <$file_header>){
                chomp $the_line;

                if (index($the_line, "compared equal") != -1){
                  $is_verified = 1;
                  last;
                }
              }

              if (!$is_verified){
                $mindeg_num = $max_deg;
                last;
              }
              else{
                open (my $fid_prim, '>', $file_prim);
                printf $fid_prim ".i %0d \n", $in_cnt;
                printf $fid_prim ".o %0d \n", $out_cnt;
                printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
                foreach my $i (1 .. $prim_cnt){
                  if ($lit_arr[$i] != $max_deg){
                    printf $fid_prim "%0s \n", $prim_arr[$i];
                  }
                }
                printf $fid_prim ".e \n";
                close $fid_prim;
              }
            }
            else{
              print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
            }
          }
          else{
            $mindeg_num = $max_deg;
            last;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
        }
      }
    }
    else{
      print RED, "[ERROR] Could not open the $file_dual file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
  }

  return ($file_dual, $prod_cnt, $deg_num, $mindeg_num, \@prod_num_dual, \@prod_lvl, \@prod_arr, \@prod_ind, \@tt_arr);
}

sub read_match_pla{
  my ($file_dir, $the_first, $in_arr_ref, $prod_ind_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  my $the_index;
  my $imp_cnt = 0;
  my $match_cnt = 0;
  my @match_arr = ();

  my $file_temp_dual = $file_dir . "temp_dual_file.pla";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_temp_dual)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".p ") != -1){
        $imp_cnt = substr($the_line, 3, length($the_line)-3) + 0.0;
      }
      elsif (index($the_line, ".") == -1){
        $match_cnt++;
        $the_index = -1;

        my $the_cnt = 0;
        my @the_ind = ();
        my @the_arr = ();
        while (1){
          $the_index++;
          my $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq " "){
            last;
          }
          elsif($the_char eq "0"){
            $the_cnt++;
            $the_arr[$the_cnt] = "!" . $in_arr[$the_index+1];
            $the_ind[$the_cnt] = (-1)*($the_index+1);
          }
          elsif($the_char eq "1"){
            $the_cnt++;
            $the_arr[$the_cnt] = $in_arr[$the_index+1];
            $the_ind[$the_cnt] = $the_index+1;
          }

          if ($the_cnt == 1){
            $match_arr[$match_cnt][1] = $the_arr[1];
            $match_arr[$match_cnt][2] = $the_arr[1];
          }
          elsif ($the_cnt == 2){
            if ($prod_ind[abs($the_ind[1])][$the_first] == -1 and $the_ind[1] < 0){
              $match_arr[$match_cnt][1] = $the_arr[1];
              $match_arr[$match_cnt][2] = $the_arr[2];
            }
            elsif ($prod_ind[abs($the_ind[1])][$the_first] == 1 and $the_ind[1] > 0){
              $match_arr[$match_cnt][1] = $the_arr[1];
              $match_arr[$match_cnt][2] = $the_arr[2];
            }
            elsif ($prod_ind[abs($the_ind[2])][$the_first] == -1 and $the_ind[2] < 0){
              $match_arr[$match_cnt][1] = $the_arr[2];
              $match_arr[$match_cnt][2] = $the_arr[1];
            }
            elsif ($prod_ind[abs($the_ind[2])][$the_first] == 1 and $the_ind[2] > 0){
              $match_arr[$match_cnt][1] = $the_arr[2];
              $match_arr[$match_cnt][2] = $the_arr[1];
            }
          }
          elsif ($the_cnt > 2){
            print "[WARNING] The number of terms should not be greater than two! \n";
          }
        }
      }
    }
    close $file_header;
  }
  else{
    print "Could not open the $file_temp_dual file! \n";
  }

  return ($imp_cnt, $match_cnt, @match_arr);
}

sub write_match_pla{
  my ($file_dir, $in_num, $out_num, $the_first, $the_second, @prod_ind) = @_;

  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_pla, '>', $file_temp);
  
  printf $fid_pla ".i %0d \n", $in_num;
  printf $fid_pla ".o %0d \n", $out_num;
  printf $fid_pla ".phase 0 \n";
  printf $fid_pla ".p 2 \n";
  foreach my $k (1 .. $in_num){
    if ($prod_ind[$k][$the_first] == 1){
      printf $fid_pla "0";
    }
    elsif ($prod_ind[$k][$the_first] == -1){
      printf $fid_pla "1";
    }
    else{
      printf $fid_pla "-";
    }
  }
  printf $fid_pla " 1 \n";
  
  foreach my $k (1 .. $in_num){
    if ($prod_ind[$k][$the_second] == 1){
      printf $fid_pla "0";
    }
    elsif ($prod_ind[$k][$the_second] == -1){
      printf $fid_pla "1";
    }
    else{
      printf $fid_pla "-";
    }
  }
  printf $fid_pla " 1 \n";
  printf $fid_pla ".e \n";
  
  close $fid_pla;
}

sub find_forth_upper_bound{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_simp, $deg_simp, $in_arr_ref, $lit_arr_ref, $single_lit_simp_ref, $double_lit_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
  my @prod_arr_simp = @ {$prod_arr_simp_ref};
  my @prod_ind_simp = @ {$prod_ind_simp_ref};
  my @double_lit_simp = @ {$double_lit_simp_ref};
  my @single_lit_simp = @ {$single_lit_simp_ref};

  my $ub_four = 0;
  my $col_num = 0;
  my @imp_arr = ();
  my @sol_four = ();
  my $single_pointer = 0;

  #Initialize the implementation array
  foreach my $i (1 .. $prod_simp){
    if ($prod_lvl_simp[$i] == 1){
      $imp_arr[$i] = 1;
    }
    elsif ($double_lit_simp[0] > 1 and $prod_lvl_simp[$i] == 2){
      $imp_arr[$i] = 1;
    }
    else{
      $imp_arr[$i] = 0;
    }
  }

  my $the_end = 0;
  #First, place the products with two terms if there are more than one
  if ($double_lit_simp[0] > 1){
    foreach my $h (1 .. $double_lit_simp[0]){
      $ub_four += $deg_simp;

      my $first_var = "";
      if ($lit_arr[$double_lit_simp[2*$h-1]] < 0){
        $first_var = "!";
      }
      $first_var = $first_var . $in_arr[abs($lit_arr[$double_lit_simp[2*$h-1]])];
      
      my $second_var = "";
      if ($lit_arr[$double_lit_simp[2*$h]] < 0){
        $second_var = "!";
      }
      $second_var = $second_var . $in_arr[abs($lit_arr[$double_lit_simp[2*$h]])];
      
      $col_num++;
      foreach my $i (1 .. $deg_simp-1){
        $sol_four[$i][$col_num] = $first_var;
      }
      $sol_four[$deg_simp][$col_num] = $second_var;
    }

    $the_end = 1;
    foreach my $h (1 .. $prod_simp){
      if (!$imp_arr[$h]){
        $the_end = 0;
        last;
      }
    }

    if (!$the_end){
      #Adding a single term if there is any or just a false-column
      $col_num++;
      $ub_four += $deg_simp;
      if ($double_lit_simp[0] and $single_lit_simp[0]){
        $single_pointer++;
        
        my $the_var = "";
        if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
          $the_var = "!";
        }
        $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
        
        foreach my $i (1 .. $deg_simp){
          $sol_four[$i][$col_num] = $the_var;
        }
      }
      else{
        foreach my $i (1 .. $deg_simp){
          $sol_four[$i][$col_num] = "F";
        }
      }
    }
  }

  #Second, one by one add a prime implicant with a match if there is any
  if (!$the_end){
    foreach my $i (1 .. $prod_simp){
      if (!$imp_arr[$i]){
        my $imp_cnt;
        my $match_cnt;
        my @match_arr;
        my $match_found = 0;

        #Finding the match
        for (my $j = $i+1; $j <= $prod_simp; $j++){
          if (!$imp_arr[$j]){
            #Check if these prime implicants share at least oone common literal
            my $is_rel = 0;
            foreach my $k (1 .. $in_num){
              if ($prod_ind_simp[$k][$i] and $prod_ind_simp[$k][$j]){
                $is_rel = 1;
                last;
              }
            }

            if ($is_rel){
              write_match_pla($file_dir, $in_num, $out_num, $i, $j, @prod_ind_simp);
              my $file_temp = $file_dir . "temp_file.pla";
              my $file_temp_dual = $file_dir . "temp_dual_file.pla";
              my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_temp_dual;
              system ($the_cmd);
              ($imp_cnt, $match_cnt, @match_arr) = read_match_pla($file_dir, $i, \@in_arr, \@prod_ind_simp);

              if ($imp_cnt <= $deg_simp){
                $match_found = $j;
                last;
              }
            }
          }
        }

        if ($match_found){
          $col_num += 2;
          $imp_arr[$i] = 1;
          $imp_arr[$match_found] = 1;
          $ub_four += 2*$deg_simp;

          foreach my $j (1 .. $match_cnt){
            $sol_four[$j][$col_num-1] = $match_arr[$j][1];
            $sol_four[$j][$col_num] = $match_arr[$j][2];
          }
          for (my $j = $match_cnt+1; $j <= $deg_simp; $j++){
            $sol_four[$j][$col_num-1] = "T";
            $sol_four[$j][$col_num] = "T";
          }
        }
        else{
          $imp_arr[$i] = 1;
          $ub_four += $deg_simp;

          $col_num++;
          foreach my $j (1 .. $prod_lvl_simp[$i]){
            $sol_four[$j][$col_num] = $prod_arr_simp[$j][$i];
          }
          for (my $j = $prod_lvl_simp[$i]+1; $j <= $deg_simp; $j++){
            $sol_four[$j][$col_num] = "T";
          }
        }

        $the_end = 1;
        for (my $j = $i+1; $j <= $prod_simp; $j++){
          if (!$imp_arr[$j]){
            $the_end = 0;
            last;
          }
        }

        #Add a single-term prime implicant or a false-column if there is at least one prime implicant not considered, otherwise return
        if ($the_end){
          last;
        }
        else{
          $col_num++;
          $ub_four += $deg_simp;

          if ($single_pointer < $single_lit_simp[0]){
            $single_pointer++;
            
            my $the_var = "";
            if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
              $the_var = "!";
            }
            $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
            
            foreach my $j (1 .. $deg_simp){
              $sol_four[$j][$col_num] = $the_var;
            }
          }
          else{
            foreach my $j (1 .. $deg_simp){
              $sol_four[$j][$col_num] = "F";
            }
          }
        }
      }
    }
  }

  #Adding the single term prime implicant if there is any left
  while ($single_pointer < $single_lit_simp[0]){
    $col_num++;
    $single_pointer++;
    $ub_four += $deg_simp;
    
    my $the_var = "";
    if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
      $the_var = "!";
    }
    $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
    
    foreach my $i (1 .. $deg_simp){
      $sol_four[$i][$col_num] = $the_var;
    }
  }

  #print "The solution on the forth criteria: \n";
  #foreach my $i (1 .. $deg_simp){
  #  print "| ";
  #  foreach my $j (1 .. $col_num){
  #    if (index($sol_four[$i][$j], "!") != -1){
  #      print "$sol_four[$i][$j] | ";
  #    }
  #    else{
  #      print "$sol_four[$i][$j]  | ";
  #    }
  #  }
  #  print "\n";
  #}

  return ($ub_four, @sol_four);
}

sub find_fifth_upper_bound{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_dual, $deg_dual, $in_arr_ref, $lit_arr_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl_dual = @ {$prod_lvl_dual_ref};
  my @prod_arr_dual = @ {$prod_arr_dual_ref};
  my @prod_ind_dual = @ {$prod_ind_dual_ref};
  my @single_lit_dual = @ {$single_lit_dual_ref};

  my $ub_five = 0;
  my $row_num = 0;
  my @imp_arr = ();
  my @sol_five = ();
  my $single_pointer = 0;

  #Initialize the implementation array
  my $the_end = 1;
  foreach my $i (1 .. $prod_dual){
    if ($prod_lvl_dual[$i] == 1){
      $imp_arr[$i] = 1;
    }
    else{
      $the_end = 0;
      $imp_arr[$i] = 0;
    }
  }

  #One by one add a prime implicant with a match if there is any
  if (!$the_end){
    foreach my $i (1 .. $prod_dual){
      if (!$imp_arr[$i]){
        my $imp_cnt;
        my $match_cnt;
        my @match_arr;
        my $match_found = 0;

        #Finding the match
        for (my $j = $i+1; $j <= $prod_dual; $j++){
          if (!$imp_arr[$j]){
            #Check if these prime implicants share at least oone common literal
            my $is_rel = 0;
            foreach my $k (1 .. $in_num){
              if ($prod_ind_dual[$k][$i] and $prod_ind_dual[$k][$j]){
                $is_rel = 1;
                last;
              }
            }

            if ($is_rel){
              write_match_pla($file_dir, $in_num, $out_num, $i, $j, @prod_ind_dual);
              my $file_temp = $file_dir . "temp_file.pla";
              my $file_temp_dual = $file_dir . "temp_dual_file.pla";
              my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_temp_dual;
              system ($the_cmd);
              ($imp_cnt, $match_cnt, @match_arr) = read_match_pla($file_dir, $i, \@in_arr, \@prod_ind_dual);

              if ($imp_cnt <= $deg_dual){
                $match_found = $j;
                last;
              }
            }
          }
        }

        if ($match_found){
          $row_num += 2;
          $imp_arr[$i] = 1;
          $imp_arr[$match_found] = 1;
          $ub_five += 2*$deg_dual;

          foreach my $j (1 .. $match_cnt){
            $sol_five[$row_num-1][$j] = $match_arr[$j][1];
            $sol_five[$row_num][$j] = $match_arr[$j][2];
          }
          for (my $j = $match_cnt+1; $j <= $deg_dual; $j++){
            $sol_five[$row_num-1][$j] = "F";
            $sol_five[$row_num][$j] = "F";
          }
        }
        else{
          $imp_arr[$i] = 1;
          $ub_five += $deg_dual;

          $row_num++;
          foreach my $j (1 .. $prod_lvl_dual[$i]){
            $sol_five[$row_num][$j] = $prod_arr_dual[$j][$i];
          }
          for (my $j = $prod_lvl_dual[$i]+1; $j <= $deg_dual; $j++){
            $sol_five[$row_num][$j] = "F";
          }
        }

        $the_end = 1;
        for (my $j = $i+1; $j <= $prod_dual; $j++){
          if (!$imp_arr[$j]){
            $the_end = 0;
            last;
          }
        }

        #Add a single-term prime implicant or a false-row if there is at least one prime implicant not considered, otherwise return
        if ($the_end){
          last;
        }
        else{
          $row_num++;
          $ub_five += $deg_dual;

          if ($single_pointer < $single_lit_dual[0]){
            $single_pointer++;
            
            my $the_var = "";
            if ($lit_arr[$single_lit_dual[$single_pointer]] < 0){
              $the_var = "!";
            }
            $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_dual[$single_pointer]])];
            
            foreach my $j (1 .. $deg_dual){
              $sol_five[$row_num][$j] = $the_var;
            }
          }
          else{
            foreach my $j (1 .. $deg_dual){
              $sol_five[$row_num][$j] = "T";
            }
          }
        }
      }
    }
  }

  #Adding the single term prime implicant if there is any left
  while ($single_pointer < $single_lit_dual[0]){
    $row_num++;
    $single_pointer++;
    $ub_five += $deg_dual;
    
    my $the_var = "";
    if ($lit_arr[$single_lit_dual[$single_pointer]] < 0){
      $the_var = "!";
    }
    $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_dual[$single_pointer]])];
    
    foreach my $i (1 .. $deg_dual){
      $sol_five[$row_num][$i] = $the_var;
    }
  }

  #print "The solution on the fifth criteria: \n";
  #foreach my $i (1 .. $row_num){
  #  print "| ";
  #  foreach my $j (1 .. $deg_dual){
  #    if (index($sol_five[$i][$j], "!") != -1){
  #      print "$sol_five[$i][$j] | ";
  #    }
  #    else{
  #      print "$sol_five[$i][$j]  | ";
  #    }
  #  }
  #  print "\n";
  #}

  return ($ub_five, @sol_five);
}

sub determine_ub{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_simp, $prod_dual, $deg_simp, $deg_dual, $in_arr_ref, $lit_arr_ref, $non_double_simp, $non_single_dual, $single_lit_simp_ref, $double_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = @_;
  my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
  my @prod_arr_simp = @ {$prod_arr_simp_ref};
  my @prod_lvl_dual = @ {$prod_lvl_dual_ref};
  my @prod_arr_dual = @ {$prod_arr_dual_ref};

  my $the_ub = 0;
  my $the_row = 0;
  my $the_col = 0;
  my @the_sol = ();
  my $ub_index = 0;

  my $ub_one = $prod_simp * $prod_dual;
  #print "[INFO] The first upper bound: $ub_one \n";
  
  my $ub_two = $deg_simp * (2*$prod_simp-1);
  #print "[INFO] The second upper bound: $ub_two \n";

  my $ub_three = $deg_dual * (2*$prod_dual-1);
  #print "[INFO] The third upper bound: $ub_three \n";

  my ($ub_four, @sol_four) = find_forth_upper_bound($file_dir, $path_espresso, $in_num, $out_num, $prod_simp, $deg_simp, $in_arr_ref, $lit_arr_ref, $single_lit_simp_ref, $double_lit_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref);
  my ($ub_five, @sol_five) = find_fifth_upper_bound($file_dir, $path_espresso, $in_num, $out_num, $prod_dual, $deg_dual, $in_arr_ref, $lit_arr_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref);

  if ($ub_one <= $ub_two and $ub_one <= $ub_three and $ub_one <= $ub_four and $ub_one <= $ub_five){
    $ub_index = 1;
    $the_ub = $ub_one;

    $the_row = $prod_dual;
    $the_col = $prod_simp;

    foreach my $i (1 .. $the_row){
      foreach my $j (1 .. $the_col){
        my $var_found = 0;
        foreach my $m (1 .. $prod_lvl_dual[$i]){
          foreach my $k (1 .. $prod_lvl_simp[$j]){
            if ($prod_arr_simp[$k][$j] eq $prod_arr_dual[$m][$i]){
              $var_found = 1;
              $the_sol[$i][$j] = $prod_arr_simp[$k][$j];
              last;
            }
          }
          if ($var_found){
            last;
          }
        }

        if (!$var_found){
          print RED, "[ERROR] A literal in a normal product must match one literal in a dual product! \n", RESET;
        }
      }
    }

    #print "The first solution: \n";
    #foreach my $i (1 .. $the_row){
    #  print "| ";
    #  foreach my $j (1 .. $the_col){
    #    if (index($the_sol[$i][$j], "!") != -1){
    #      print "$the_sol[$i][$j] | ";
    #    }
    #    else{
    #      print "$the_sol[$i][$j]  | ";
    #    }
    #  }
    #  print "\n";
    #}
  }
  elsif ($ub_two <= $ub_one and $ub_two <= $ub_three and $ub_two <= $ub_four and $ub_two <= $ub_five){
    $ub_index = 2;
    $the_ub = $ub_two;

    $the_row = $deg_simp;
    $the_col = $the_ub/$the_row;

    #Writing the products and ones except the last product
    my $prod_cnt_simp = 0;
    foreach my $i (1 .. $the_col-1){
      if ($i % 2){
        $prod_cnt_simp++;
        foreach my $j (1 .. $prod_lvl_simp[$prod_cnt_simp]){
          $the_sol[$j][$i] = $prod_arr_simp[$j][$prod_cnt_simp];
        }
        for (my $j = $prod_lvl_simp[$prod_cnt_simp]+1; $j <= $the_row; $j++){
          $the_sol[$j][$i] = "T";
        }
      }
      else{
        foreach my $j (1 .. $the_row){
          $the_sol[$j][$i] = "F";
        }
      }
    }

    #Writing the last product
    foreach my $j (1 .. $prod_lvl_simp[$prod_simp]){
      $the_sol[$j][$the_col] = $prod_arr_simp[$j][$prod_simp];
    }
    for (my $j = $prod_lvl_simp[$prod_simp]+1; $j <= $the_row; $j++){
      $the_sol[$j][$the_row] = "T";
    }

    #print "The second solution: \n";
    #foreach my $i (1 .. $the_row){
    #  print "| ";
    #  foreach my $j (1 .. $the_col){
    #    if (index($the_sol[$i][$j], "!") != -1){
    #      print "$the_sol[$i][$j] | ";
    #    }
    #    else{
    #      print "$the_sol[$i][$j]  | ";
    #    }
    #  }
    #  print "\n";
    #}
  }
  elsif ($ub_three <= $ub_one and $ub_three <= $ub_two and $ub_three <= $ub_four and $ub_three <= $ub_five){
    $ub_index = 3;
    $the_ub = $ub_three;

    $the_col = $deg_dual;
    $the_row = $the_ub/$the_col;

    #Writing the products and ones except the last product
    my $prod_cnt_dual = 0;
    foreach my $i (1 .. $the_row-1){
      if ($i % 2){
        $prod_cnt_dual++;
        foreach my $j (1 .. $prod_lvl_dual[$prod_cnt_dual]){
          $the_sol[$i][$j] = $prod_arr_dual[$j][$prod_cnt_dual];
        }
        for (my $j = $prod_lvl_dual[$prod_cnt_dual]+1; $j <= $the_col; $j++){
          $the_sol[$i][$j] = "T";
        }
      }
      else{
        foreach my $j (1 .. $the_col){
          $the_sol[$i][$j] = "T";
        }
      }
    }

    #Writing the last product
    foreach my $j (1 .. $prod_lvl_dual[$prod_dual]){
      $the_sol[$the_row][$j] = $prod_arr_dual[$j][$prod_dual];
    }
    for (my $j = $prod_lvl_dual[$prod_dual]+1; $j <= $the_col; $j++){
      $the_sol[$the_row][$j] = "T";
    }
    
    #print "The third solution: \n";
    #foreach my $i (1 .. $the_row){
    #  print "| ";
    #  foreach my $j (1 .. $the_col){
    #    if (index($the_sol[$i][$j], "!") != -1){
    #      print "$the_sol[$i][$j] | ";
    #    }
    #    else{
    #      print "$the_sol[$i][$j]  | ";
    #    }
    #  }
    #  print "\n";
    #}
  }
  elsif ($ub_four <= $ub_one and $ub_four <= $ub_two and $ub_four <= $ub_three and $ub_four <= $ub_five){
    $ub_index = 4;
    $the_ub = $ub_four;
    $the_row = $deg_simp;
    $the_col = $the_ub/$deg_simp;
    @the_sol = @sol_four;
  }
  else{
    $ub_index = 5;
    $the_ub = $ub_five;
    $the_row = $the_ub/$deg_dual;
    $the_col = $deg_dual;
    @the_sol = @sol_five;
  }

  return ($the_ub, $ub_index, $the_row, $the_col, @the_sol);
}

sub generate_configurations{
  my ($no_sol_ite, $wide_thin, $the_mid, $lb_row, $lb_col, $the_lb, $fail_cnt, @fail_arr) = @_;

  my $conf_cnt = 0;
  my @conf_arr = ();

  if ($wide_thin and $no_sol_ite < 2){
    for (my $the_num = $the_mid; $the_num >= $the_lb; $the_num--){
      for (my $the_row = $the_num; $the_row >= 1; $the_row--){
        if ($the_row >= $lb_row){
          if (!($the_num % $the_row)){
            my $the_col = $the_num / $the_row;
            if ($the_col >= $lb_col){
              if (($the_row+1)*$the_col > $the_mid and $the_row*($the_col+1) > $the_mid){
                my $is_dom = 0;
                foreach my $fail_index (1 .. $fail_cnt){
                  if ($fail_arr[$fail_index][1] >= $the_row and $fail_arr[$fail_index][2] >= $the_col){
                    $is_dom = 1;
                    last;
                  }
                }
                if (!$is_dom){
                  $conf_cnt++;
                  $conf_arr[$conf_cnt][1] = $the_row;
                  $conf_arr[$conf_cnt][2] = $the_col;
                }
              }
            }
          }
        }
      }
    }
  }
  elsif (!$wide_thin and $no_sol_ite < 2){
    for (my $the_num = $the_mid; $the_num >= $the_lb; $the_num--){
      for (my $the_row = 1; $the_row <= $the_num; $the_row++){
        if ($the_row >= $lb_row){
          if (!($the_num % $the_row)){
            my $the_col = $the_num / $the_row;
            if ($the_col >= $lb_col){
              if (($the_row+1)*$the_col > $the_mid and $the_row*($the_col+1) > $the_mid){
                my $is_dom = 0;
                foreach my $fail_index (1 .. $fail_cnt){
                  if ($fail_arr[$fail_index][1] >= $the_row and $fail_arr[$fail_index][2] >= $the_col){
                    $is_dom = 1;
                    last;
                  }
                }
                if (!$is_dom){
                  $conf_cnt++;
                  $conf_arr[$conf_cnt][1] = $the_row;
                  $conf_arr[$conf_cnt][2] = $the_col;
                }
              }
            }
          }
        }
      }
    }
  }
  if ($wide_thin and $no_sol_ite >= 2){
    for (my $the_num = $the_lb; $the_num <= $the_mid; $the_num++){
      for (my $the_row = $the_num; $the_row >= 1; $the_row--){
        if ($the_row >= $lb_row){
          if (!($the_num % $the_row)){
            my $the_col = $the_num / $the_row;
            if ($the_col >= $lb_col){
              #if (($the_row+1)*$the_col > $the_mid and $the_row*($the_col+1) > $the_mid){
                my $is_dom = 0;
                foreach my $fail_index (1 .. $fail_cnt){
                  if ($fail_arr[$fail_index][1] >= $the_row and $fail_arr[$fail_index][2] >= $the_col){
                    $is_dom = 1;
                    last;
                  }
                }
                if (!$is_dom){
                  $conf_cnt++;
                  $conf_arr[$conf_cnt][1] = $the_row;
                  $conf_arr[$conf_cnt][2] = $the_col;
                }
              #}
            }
          }
        }
      }
    }
  }
  elsif (!$wide_thin and $no_sol_ite >= 2){
    for (my $the_num = $the_lb; $the_num <= $the_mid; $the_num++){
      for (my $the_row = 1; $the_row <= $the_num; $the_row++){
        if ($the_row >= $lb_row){
          if (!($the_num % $the_row)){
            my $the_col = $the_num / $the_row;
            if ($the_col >= $lb_col){
              #if (($the_row+1)*$the_col > $the_mid and $the_row*($the_col+1) > $the_mid){
                my $is_dom = 0;
                foreach my $fail_index (1 .. $fail_cnt){
                  if ($fail_arr[$fail_index][1] >= $the_row and $fail_arr[$fail_index][2] >= $the_col){
                    $is_dom = 1;
                    last;
                  }
                }
                if (!$is_dom){
                  $conf_cnt++;
                  $conf_arr[$conf_cnt][1] = $the_row;
                  $conf_arr[$conf_cnt][2] = $the_col;
                }
              #}
            }
          }
        }
      }
    }
  }

  #print "Possible configurations: \n";
  #foreach my $i (1 .. $conf_cnt){
  #  print "$conf_arr[$i][1] $conf_arr[$i][2] \n";
  #}

  return ($conf_cnt, @conf_arr);
}

sub find_inverse{
  my ($file_pla, $path_espresso) = @_;

  my $file_inv = "";
  my $dot_index = index($file_pla, ".");
  if ($dot_index == -1){
    $file_inv = $file_pla . "_inv.pla";
  }
  else{
    $file_inv = substr($file_pla, 0, $dot_index) . "_inv.pla";
  }

  my $first_prod = 1;
  if (open (my $file_header, '<:encoding(UTF-8)', $file_pla)) {
    open (my $fid_inv, '>', "temp_file.pla");
    
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      my $prime_index = index($the_line, ".p ");

      if ($prime_index != -1){
        printf $fid_inv ".phase 0 \n";
        printf $fid_inv "%0s\n", $the_line;
      }
      else{
        printf $fid_inv "%0s\n", $the_line;
      }
    }

    close $fid_inv;

    my $the_cmd = $path_espresso . " -Dexact temp_file.pla > " . $file_inv;
    system($the_cmd);
  }
  else{
    print RED, "[ERROR] Could not open the $file_pla file \n", RESET;
  }

  return ($file_inv);
}

sub is_function_synthesizable{
  my ($prod_cnt, $fun_deg, $prod_num_ref, $lat_prod_cnt, $lat_deg, $lat_prod_num_ref) = @_;
  my @prod_num = @ {$prod_num_ref};
  my @lat_prod_num = @ {$lat_prod_num_ref};

  my $the_value = 1;

  foreach my $i (1 .. $fun_deg){
    if (defined $prod_num[$i]){
      my $the_point = $i;
      my $the_sum = $prod_num[$i];
      
      while (1){
        if (defined $lat_prod_num[$the_point]){
          if ($lat_prod_num[$the_point] >= $the_sum){
            $lat_prod_num[$the_point] = $lat_prod_num[$the_point] - $the_sum;
            $the_sum = 0;
          }
          else{
            $the_sum = $the_sum - $lat_prod_num[$the_point];
            $lat_prod_num[$the_point] = 0;
          }
        }

        $the_point++;
        if ($the_point > $lat_deg or !$the_sum){
          last;
        }
      }
      
      if ($the_sum){
        $the_value = 0;
        last;
      }
    }
  }

  return ($the_value);
}

sub is_function_synthesizable_old{
  my ($prod_cnt, $fun_deg, $prod_num_ref, $lat_prod_cnt, $lat_deg, $lat_prod_num_ref) = @_;
  my @prod_num = @ {$prod_num_ref};
  my @lat_prod_num = @ {$lat_prod_num_ref};

  my $the_value = 1;

  if ($lat_prod_cnt < $prod_cnt){
    $the_value = 0;
  }
  else{
    foreach my $i (1 .. $fun_deg){
      if (defined $prod_num[$i]){
        my $the_sum = 0;
        foreach my $j ($i .. $lat_deg){
          if (defined $lat_prod_num[$j]){
            $the_sum += $lat_prod_num[$j];
          }
        }

        if ($the_sum < $prod_num[$i]){
          $the_value = 0;
          last;
        }
      }
    }
  }

  return ($the_value);
}

sub determine_single_double_products{
  my ($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt, $prod_lvl_ref, $prod_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl = @ {$prod_lvl_ref};
  my @prod_arr = @ {$prod_arr_ref};

  my $non_double = 0;
  my $non_single = 0;
  my @double_lit = ();
  my @single_lit = ();

  my $wide_cnt = 0;
  my $thin_cnt = 0;
  my $wide_thin = 0;

  my $the_index;
  $double_lit[0] = 0;
  $single_lit[0] = 0;
  foreach my $i (1 .. $prod_cnt){
    if ($prod_lvl[$i] == 1){
      $single_lit[0]++;
      my $the_var = $prod_arr[1][$i];
      if (index($the_var, "!") == -1){
        $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
      }
      else{
        $the_var = substr($the_var, 1, length($the_var)-1);
        $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
        $the_index = (-1) * $the_index;
      }

      $single_lit[$single_lit[0]] = is_inside_numeric_array($the_index, $lit_num, @lit_arr);
    }
    elsif ($prod_lvl[$i] == 2){
      $non_single = 1;

      $double_lit[0]++;
      foreach my $j (1 .. 2){
        my $the_var = $prod_arr[$j][$i];
        if (index($the_var, "!") == -1){
          $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
        }
        else{
          $the_var = substr($the_var, 1, length($the_var)-1);
          $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
          $the_index = (-1)*$the_index;
        }

        $double_lit[2*($double_lit[0]-1)+$j] = is_inside_numeric_array($the_index, $lit_num, @lit_arr);
      }
    }
    else{
      $non_single = 1;
      $non_double = 1;
    }

    if ($prod_lvl[$i] < $in_num/2){
      $wide_cnt++;
    }
    else{
      $thin_cnt++;
    }
  }

  if ($thin_cnt > $wide_cnt){
    $wide_thin = 1;
  }

  return ($wide_thin, $non_single, $non_double, \@single_lit, \@double_lit);
}

sub extract_lattice_product_info{
  my ($file_lattice) = @_;

  my $lat_deg = 0;
  my $prod_cnt = 0;
  my @lat_prod_num = ();

  my $init_index = 0;
  my $last_index = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_lattice)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      if (substr($the_line, 0, 1) eq "#"){
        $init_index = index($the_line, "with ");
        if ($init_index != -1){
          $init_index = skip_spaces_forward($the_line, $init_index+4);
          
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= length($the_line)){
              print RED, "[ERROR] There must be something wrong here! \n", RESET;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
          if ($the_var > $lat_deg){
            $lat_deg = $the_var;
          }

          $init_index = index($the_line, ": ");
          if ($init_index != -1){
            $init_index = skip_spaces_forward($the_line, $init_index+1);

            my $the_num = substr($the_line, $init_index, length($the_line)-$init_index) + 0.0;
            $lat_prod_num[$the_var] = $the_num;
            $prod_cnt += $the_num;
          }
        }
      }
    }
  }
  else{
    print RED, "[ERROR] Could not open the $file_lattice file! \n", RESET;
  }
  
  return ($prod_cnt, $lat_deg, \@lat_prod_num);
}

sub determine_lower_bound{
  my ($the_verb, $prod_simp, $prod_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref) = @_;

  my $lb_col = 1;
  if ($prod_simp > 1){
    $lb_col = 2;
  }
  if ($mindeg_dual > 2){
    $lb_col = 3;
  }

  my $lb_row = 3;
  if ($mindeg_simp == 2){
    $lb_row = 2;
  }
  elsif ($mindeg_simp == 1){
    $lb_row = 1;
  }

  my $the_lb = 1;
  my $the_end = 0;
  while (1){
    $the_lb++;

    for (my $the_row = 1; $the_row <= $the_lb; $the_row++){
      if (!($the_lb % $the_row)){
        my $the_col = $the_lb/$the_row;

        if ($the_row >= $lb_row and $the_col >= $lb_col){
          my $lat_str = $the_row . "x" . $the_col;
          my $file_lattice = "l" . $lat_str . ".eqn";
          if (!(-e $file_lattice)){
            my $the_cmd = "perl genlatfunc_rec.pl -r=" . $the_row . "  -c=" . $the_col;
            if ($the_verb < 1){print "[INFO] The $lat_str lattice equation (4-terminal) cannot be found! Generating...\n"};
            system($the_cmd);
          }
          my ($lat_prod_simp, $lat_deg_simp, $lat_prod_num_simp_ref) = extract_lattice_product_info($file_lattice);
          
          my $file_dual = "d" . $lat_str . ".eqn";
          if (!(-e $file_dual)){
            my $the_cmd = "perl genlatfunc_dual_rec.pl -r=" . $the_row . "  -c=" . $the_col;
            if ($the_verb < 1){print "[INFO] The dual of $lat_str lattice equation (8-terminal) cannot be found! Generating...\n"};
            system($the_cmd);
          }
          my ($lat_prod_dual, $lat_deg_dual, $lat_prod_num_dual_ref) = extract_lattice_product_info($file_dual);
         
          #print "[INFO] Checking the lower bound for the $lat_str lattice... \n";
          if (is_function_synthesizable($prod_simp, $deg_simp, $prod_num_simp_ref, $lat_prod_simp, $lat_deg_simp, $lat_prod_num_simp_ref)){
            if (is_function_synthesizable($prod_dual, $deg_dual, $prod_num_dual_ref, $lat_prod_dual, $lat_deg_dual, $lat_prod_num_dual_ref)){
              $the_end = 1;
              last;
            }
          }
        }
      }
    }

    if ($the_end){
      last;
    }
  }

  return ($the_lb);
}

sub read_lattice{
  my ($file_name) = @_;

  my $in_cnt = 0;
  my $the_deg = 0;
  my @in_arr = ();

  my $prod_cnt = 0;
  my @prod_arr =();
  my @prod_lvl =();
  my @prod_num = ();

  my $the_end;
  my $the_var;
  my $the_index;
  my $init_index;
  my $last_index;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_name)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      my $llength = length($the_line);

      $init_index=skip_spaces_forward($the_line, 0);
      if (substr($the_line, $init_index, 1) ne "#"){
        #Extract the products
        #print "[INFO] The product: $the_line \n";
        #sleep 1;
        
        $the_end = 0;
        if ($init_index < $llength){
          $prod_cnt++;
          $prod_lvl[$prod_cnt] = 0;

          while ($init_index < $llength){
            $last_index = $init_index;
            while (substr($the_line,$last_index,1) ne " "){
              $last_index++;

              if ($last_index > $llength){
                $the_end = 1;
                last;
              }
            }

            $the_var = substr($the_line, $init_index, $last_index-$init_index);
            #print "[INFO] The product literal: $the_var \n";
            #sleep 1;
 
            $prod_lvl[$prod_cnt]++;
            $prod_arr[$prod_lvl[$prod_cnt]][$prod_cnt] = $the_var;

            $init_index = skip_spaces_forward($the_line, $last_index);
          }

          if (defined $prod_num[$prod_lvl[$prod_cnt]]){
            $prod_num[$prod_lvl[$prod_cnt]]++;
          }
          else{
            $prod_num[$prod_lvl[$prod_cnt]] = 1;
          }

          if ($prod_lvl[$prod_cnt] > $the_deg){
            $the_deg = $prod_lvl[$prod_cnt];
          }
        }
      }
      else{
        if (index($the_line, "INORDER = ") != -1){
          $init_index = index($the_line, "=");
          $init_index = skip_spaces_forward($the_line, $init_index+1);

          $the_end = 0;
          while (1){
            $last_index = $init_index;
            while (substr($the_line,$last_index,1) ne " " and substr($the_line,$last_index,1) ne ";"){
              $last_index++;

              if ($last_index > $llength){
                $the_end = 1;
                last;
              }
            }

            if (substr($the_line,$last_index,1) eq ";"){
              $the_end = 1;
            }

            if ($last_index >= $init_index){
              $the_var = substr($the_line,$init_index,$last_index-$init_index);
              #print "[INFO] The variable: $the_var \n";

              if ($the_var =~ /[0-9a-zA-Z_]/ ){
                $in_cnt++;
                $in_arr[$in_cnt]=$the_var;
              }
            }

            if (!$the_end){
              $init_index = skip_spaces_forward($the_line, $last_index+1);
            }
            else{
              last;
            }
          }
        }
      }
    }

    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the $file_name file \n", RESET;
  }

  return ($in_cnt, $prod_cnt, $the_deg, \@in_arr, \@prod_num, \@prod_lvl, \@prod_arr);
}

sub janus_func{
  my ($file_pla, $the_verb, $cpu_limit, $sat_limit, $set_row, $set_col, $path_espresso, $path_sat) = @_;

  my $initial_time = time();  
  my $cur_dir = Cwd::cwd();
  
  my $file_dir = "";
  my $leaned_right = index($file_pla, "/");
  my $leaned_left = index($file_pla, "\\");
  if ($leaned_right != -1 or $leaned_left != -1){
    my $pla_index = index($file_pla, ".pla");
    while (substr($file_pla, $pla_index, 1) ne "/" and substr($file_pla, $pla_index, 1) ne "\\"){
      $pla_index--;
    }
    $file_dir = substr($file_pla, 0, $pla_index+1);
  }
  else{
    $file_dir = $cur_dir;
  }

  my $exp_cnt = 0;
  my @exp_arr = ();
  my $fail_cnt = 0;
  my @fail_arr = ();

  my $opt_col = 0;
  my $opt_row = 0;
  my $sol_opt = 0;
  my @opt_sol = ();
  my $sol_nonopt = 0;
  my $tot_sat_var = 0;
  my $tot_sat_cnf = 0;
  my $tot_sat_run = 0;

  if (!$the_verb){print "[INFO] Simplifying the target function and generating the truth table... \n";}
  my ($file_simp, $prod_cnt_simp, $deg_simp, $mindeg_simp, $in_num, $out_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_num_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $tt_arr_simp_ref) = simplify_sop($file_dir, $file_pla, $path_espresso);
  my ($wide_thin_simp, $non_single_simp, $non_double_simp, $single_lit_simp_ref, $double_lit_simp_ref) = determine_single_double_products($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt_simp, $prod_lvl_simp_ref, $prod_arr_simp_ref);

  if ($in_num){
    if (!$the_verb){print "[INFO] Finding the dual of the target function... \n";}
    my ($file_dual, $prod_cnt_dual, $deg_dual, $mindeg_dual, $prod_num_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref, $tt_arr_dual_ref) = find_dual($file_dir, $file_simp, $path_espresso, $in_num, $out_num, $in_arr_ref); 
    my ($wide_thin_dual, $non_single_dual, $non_double_dual, $single_lit_dual_ref, $double_lit_dual_ref) = determine_single_double_products($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt_dual, $prod_lvl_dual_ref, $prod_arr_dual_ref);

    my $the_lb;
    my $the_ub;
    my $lb_col;
    my $lb_row;
    my $opt_row;
    my $opt_col;
    my @opt_sol;
    my $ub_index;
    my $opt_prod_cnt;
    my @opt_prod_lvl;
    my @opt_prod_arr;

    if (!$set_row or !$set_col){
      if (!$the_verb){print "[INFO] Finding the lower and upper bounds of the problem... \n";}
      $the_lb = determine_lower_bound($the_verb, $prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $mindeg_simp, $mindeg_dual, $prod_num_simp_ref, $prod_num_dual_ref);
      ($the_ub, $ub_index, $opt_row, $opt_col, @opt_sol) = determine_ub($file_dir, $path_espresso, $in_num, $out_num, $prod_cnt_simp, $prod_cnt_dual, $deg_simp, $deg_dual, $in_arr_ref, $lit_arr_ref, $non_double_simp, $non_single_dual, $single_lit_simp_ref, $double_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref);
      if ($the_verb <= 1){print MAGENTA, "[INFO] Lower bound: $the_lb Upper bound: $the_ub (determined by the $ub_index. criteria) \n", RESET;}

      $lb_col = 1;
      if ($prod_cnt_simp > 1){
        $lb_col = 2;
      }
      if ($mindeg_dual > 2){
        $lb_col = 3;
      }

      $lb_row = 3;
      if ($mindeg_simp <= 2){
        $lb_row = $mindeg_simp;
      }

      if ($the_verb <= 1){print MAGENTA, "[INFO] Lower bound on #row: $lb_row Lower bound on #column: $lb_col \n", RESET;}

      $sol_opt = 1;
      $opt_prod_cnt = $prod_cnt_simp;
      @opt_prod_lvl = @ {$prod_lvl_simp_ref};
      @opt_prod_arr = @ {$prod_arr_simp_ref};
      
      $the_ub--; #This is due to the fact that a solution with the_ub exists and the aim is to find the one with a smaller value
    }
    #When a special lattice matrix is considered, the lower and upper bounds are set to its size
    else{
      $the_lb = $set_row * $set_col;
      $opt_row = $set_row;
      $opt_col = $set_col;
      $the_ub = $the_lb;
    }

    my @the_sol;
    my $sol_found;
    my $lat_prod_cnt;
    my @lat_prod_lvl;
    my @lat_prod_arr;    
    my $no_sol_ite = 1;

    while ($the_lb <= $the_ub){
      my $the_mid;
      my $the_diff = $the_ub-$the_lb;

      if ($the_diff > 2){
        my $the_divider = $no_sol_ite * (int (log($the_diff)/log(2)));
        $the_mid = int ($the_lb + $the_diff/$the_divider + 0.99);
      }
      else{
        $the_mid = $the_lb;
      }

      my $ub_updated = 0;
      if (!$the_verb){print "[INFO] Generating configurations in between $the_lb and $the_mid... \n";}
      my $conf_cnt = 0;
      my @conf_arr = ();
      if (!$set_row or !$set_col){
        ($conf_cnt, @conf_arr) = generate_configurations($no_sol_ite, $wide_thin_simp, $the_mid, $lb_row, $lb_col, $the_lb, $fail_cnt, @fail_arr);
      }
      else{
        $conf_cnt = 1;
        $conf_arr[1][1] = $set_row;
        $conf_arr[1][2] = $set_col;
      }
      foreach my $conf_index (1 .. $conf_cnt){
        my $row_num = $conf_arr[$conf_index][1];
        my $col_num = $conf_arr[$conf_index][2];
        my $latsize_str = $row_num . "x" . $col_num;
        if ($the_verb <= 1){print BLUE, "[INFO] Trying the $latsize_str lattice... \n", RESET;}

        my $is_dom_failed = 0;
        my $is_dom_expired = 0;
        foreach my $fail_index (1 .. $fail_cnt){
          if ($fail_arr[$fail_index][1] >= $row_num and $fail_arr[$fail_index][2] >= $col_num){
            $is_dom_failed = 1;
            last;
          }
        }

        if ($is_dom_failed){
          if ($the_verb <= 1){print GREEN "[INFO] The $latsize_str lattice is dominated by a failed lattice! \n", RESET;}
        }
        else{
          foreach my $exp_index (1 .. $exp_cnt){
            if ($exp_arr[$exp_index][1] == $row_num and $exp_arr[$exp_index][2] == $col_num){
              $is_dom_expired = 1;
              last;
            }
          }
        }

        if (!$is_dom_failed and !$is_dom_expired){
          #Generate the 4-terminal top-to-bottom lattice equation if it does not exist
          my $file_lattice = "l" . $latsize_str . ".eqn";
          if (!(-e $file_lattice)){
            my $the_cmd = "perl genlatfunc_rec.pl -r=" . $row_num . "  -c=" . $col_num;
            if ($the_verb < 1){print "[INFO] The $latsize_str lattice equation (4-terminal) cannot be found! Generating...\n";}
            system($the_cmd);
          }
          my ($lat_in_cnt_simp, $lat_prod_cnt_simp, $lat_deg_simp, $lat_in_arr_simp_ref, $lat_prod_num_simp_ref, $lat_prod_lvl_simp_ref, $lat_prod_arr_simp_ref) = read_lattice($file_lattice);

          #Generate the 8-terminal left-to-right lattice equation if it does not exist
          my $file_dual = "d" . $latsize_str . ".eqn";
          if (!(-e $file_dual)){
            if ($the_verb < 1){print "[INFO] The dual of $latsize_str lattice equation (8-terminal) cannot be found! Generating...\n";}
            my $the_cmd = "perl genlatfunc_dual_rec.pl -r=" . $row_num . "  -c=" . $col_num;
            system($the_cmd);
          }
          my ($lat_in_cnt_dual, $lat_prod_cnt_dual, $lat_deg_dual, $lat_in_arr_dual_ref, $lat_prod_num_dual_ref, $lat_prod_lvl_dual_ref, $lat_prod_arr_dual_ref) = read_lattice($file_dual);
          
          if (!is_function_synthesizable($prod_cnt_simp, $deg_simp, $prod_num_simp_ref, $lat_prod_cnt_simp, $lat_deg_simp, $lat_prod_num_simp_ref)){
            $sol_found = 0;
            
            $fail_cnt++;
            $fail_arr[$fail_cnt][1] = $row_num;
            $fail_arr[$fail_cnt][2] = $col_num; 
            if ($the_verb <= 1){print RED "[INFO] There exists no solution for the $latsize_str lattice due to the number and size of products in the target and lattice functions! \n", RESET;}
          }
          elsif (!is_function_synthesizable($prod_cnt_dual, $deg_dual, $prod_num_dual_ref, $lat_prod_cnt_dual, $lat_deg_dual, $lat_prod_num_dual_ref)){
            $sol_found = 0;
            
            $fail_cnt++;
            $fail_arr[$fail_cnt][1] = $row_num;
            $fail_arr[$fail_cnt][2] = $col_num; 
            if ($the_verb <= 1){print RED "[INFO] There exists no solution for the $latsize_str lattice due to the number and size of products in the dual of the target and lattice functions! \n", RESET;}
          }
          else{
            #Find the SAT problem for the top-bottom 4-terminal realization of the target function
            my ($simp_ready, $var_cnt_simp, $cnf_cnt_simp, $netvar_cnt_simp, $netcnf_cnt_simp, $invar_lit_arr_simp_ref) = bergman_simp($the_verb, $file_dir, $path_sat, $row_num, $col_num, $in_num, $lit_num, $deg_simp, $lat_deg_simp, $in_arr_ref, $lit_arr_ref, $tt_arr_simp_ref, $lat_in_cnt_simp, $prod_cnt_simp, $lat_prod_cnt_simp, $lat_prod_cnt_dual, $lat_in_arr_simp_ref, $single_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_simp_ref, $lat_prod_lvl_simp_ref, $lat_prod_lvl_dual_ref, $prod_arr_simp_ref, $lat_prod_arr_simp_ref, $lat_prod_arr_dual_ref);
            my $prob_size_simp = $netvar_cnt_simp*$netcnf_cnt_simp;

            #Find the SAT problem for the left-right 8-terminal realization of the dual of the target function
            my ($dual_ready, $var_cnt_dual, $cnf_cnt_dual, $netvar_cnt_dual, $netcnf_cnt_dual, $invar_lit_arr_dual_ref) = bergman_dual($the_verb, $file_dir, $path_sat, $prob_size_simp, $row_num, $col_num, $in_num, $lit_num, $deg_dual, $lat_deg_dual, $in_arr_ref, $lit_arr_ref, $tt_arr_dual_ref, $lat_in_cnt_dual, $prod_cnt_dual, $lat_prod_cnt_dual, $lat_prod_cnt_simp, $lat_in_arr_dual_ref, $single_lit_simp_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $lat_prod_lvl_dual_ref, $lat_prod_lvl_simp_ref, $prod_arr_dual_ref, $lat_prod_arr_dual_ref, $lat_prod_arr_simp_ref);
            my $prob_size_dual = $netvar_cnt_dual*$netcnf_cnt_dual;

            my $simp_dual = 0;
            my $sat_problem_file = "";
            if (!$simp_ready and !$dual_ready){
              $sol_found = -2;
            }
            else{
              $tot_sat_run++;
              if (($simp_ready and !$dual_ready) or ($simp_ready and $dual_ready and $prob_size_simp <= $prob_size_dual)){
                if ($the_verb <= 1){print YELLOW, "[INFO] Considering the top-bottom 4-terminal implementation of the target function...\n", RESET;}
                $sat_problem_file = $file_dir . "sat_problem_simp.cnf";
                $tot_sat_var += $var_cnt_simp;
                $tot_sat_cnf += $cnf_cnt_simp;
              }
              elsif ((!$simp_ready and $dual_ready) or ($simp_ready and $dual_ready and $prob_size_dual < $prob_size_simp)){
                if ($the_verb <= 1){print YELLOW, "[INFO] Considering the left-right 8-terminal implementation of the dual of the target function...\n", RESET;}
                $sat_problem_file = $file_dir . "sat_problem_dual.cnf";
                $tot_sat_var += $var_cnt_dual;
                $tot_sat_cnf += $cnf_cnt_dual;
                $simp_dual = 1;
              }

              #Solve the SAT problem
              if (!$the_verb){print CYAN "[INFO] Solving the SAT problem...\n", RESET;}
              my $sat_cpu_lim = int (abs($cpu_limit - time() + $initial_time));
              if ($sat_cpu_lim > $sat_limit){
                $sat_cpu_lim = $sat_limit;
              }
              #print "SAT CPU time limit: $sat_cpu_lim \n";
              my $file_sol = $file_dir . "sat_problem.sol";
              if (index($path_sat, "glucose") == -1){
                my $cmd_sat = "";
                if (index($path_sat, "cryptominisat") != -1){
                  $cmd_sat = $path_sat . " --maxtime $sat_cpu_lim $sat_problem_file > $file_sol ";
                }
                elsif (index($path_sat, "maple") != -1){
                  $cmd_sat = $path_sat . " -cpu-lim=$sat_cpu_lim $sat_problem_file > $file_sol ";
                }
                else{
                  $cmd_sat = $path_sat . "$sat_problem_file > $file_sol ";
                }
                my $sat_init_time = time();
                system($cmd_sat);
                my $sat_cpu = time() - $sat_init_time;
                if ($the_verb <= 1){print CYAN, "[INFO] SAT solver time: $sat_cpu \n", RESET;}
                if ($simp_dual){
                  ($sol_found, @the_sol) = file_read_cryptolingeling_solution($file_dir, $simp_dual, $row_num, $col_num, $in_num, $lit_num, $var_cnt_dual, $in_arr_ref, $lit_arr_ref, $invar_lit_arr_dual_ref);
                }
                else{
                  ($sol_found, @the_sol) = file_read_cryptolingeling_solution($file_dir, $simp_dual, $row_num, $col_num, $in_num, $lit_num, $var_cnt_simp, $in_arr_ref, $lit_arr_ref, $invar_lit_arr_simp_ref);
                }
              }
              else{
                my $file_out = $file_dir . "sat_problem.out";
                my $cmd_sat = $path_sat . " -cpu-lim=$sat_cpu_lim $sat_problem_file $file_out > $file_sol ";
                my $sat_init_time = time();
                system($cmd_sat);
                my $sat_cpu = time() - $sat_init_time;
                if ($the_verb <= 1){print CYAN, "[INFO] SAT solver time: $sat_cpu \n", RESET;}
                if ($simp_dual){
                  ($sol_found, @the_sol) = file_read_glucose_solution($file_dir, $simp_dual, $row_num, $col_num, $in_num, $lit_num, $var_cnt_dual, $in_arr_ref, $lit_arr_ref, $invar_lit_arr_dual_ref);
                }
                else{
                  ($sol_found, @the_sol) = file_read_glucose_solution($file_dir, $simp_dual, $row_num, $col_num, $in_num, $lit_num, $var_cnt_simp, $in_arr_ref, $lit_arr_ref, $invar_lit_arr_simp_ref);
                }
              }
            }

            if ($sol_found > 0){
              if ($the_verb <= 1){print BRIGHT_GREEN, "[INFO] A solution on the $latsize_str lattice has just been found... \n", RESET;}
              $sol_opt = 1;
              $ub_updated = 1;
              $the_ub = $row_num * $col_num - 1;

              $lat_prod_cnt = $lat_prod_cnt_simp;
              @lat_prod_lvl = @ {$lat_prod_lvl_simp_ref};
              @lat_prod_arr = @ {$lat_prod_arr_simp_ref};

              foreach my $i (1 .. $lat_prod_cnt){
                foreach my $j (1 .. $lat_prod_lvl[$i]){
                  my $the_var = $lat_prod_arr[$j][$i] + 0.0;
                  my $the_row = int ($the_var/$col_num + 0.99);
                  my $the_col = $the_var - ($the_row-1)*$col_num;

                  $lat_prod_arr[$j][$i] = $the_sol[$the_row][$the_col];
                }
              }

              $opt_row = $row_num;
              $opt_col = $col_num;
              @opt_sol = @{ dclone(\@the_sol) };
              $opt_prod_cnt = $lat_prod_cnt;
              @opt_prod_lvl = @{ dclone(\@lat_prod_lvl) };
              @opt_prod_arr = @{ dclone(\@lat_prod_arr) };
              last;
            }
            else{
              if ($sol_found == 0){
                if ($the_verb <= 1){print RED, "[INFO] There exists no solution on the $latsize_str lattice... \n", RESET;}
                
                $fail_cnt++;
                $fail_arr[$fail_cnt][1] = $row_num;
                $fail_arr[$fail_cnt][2] = $col_num;
              }
              elsif ($sol_found == -1){
                if ($the_verb <= 1){print CYAN, "[INFO] Due to the CPU time limit on the SAT solver, it has not been proved whether there exists a solution or not on the $latsize_str lattice... \n", RESET;}
                $sol_nonopt = 1;

                $exp_cnt++;
                $exp_arr[$exp_cnt][1] = $row_num;
                $exp_arr[$exp_cnt][2] = $col_num;
              }
              elsif ($sol_found == -2){
                if ($the_verb <= 1){print CYAN, "[INFO] Size of the SAT problem is beyond the capabilities of a SAT solver! \n", RESET;}
                $sol_nonopt = 1;
                
                $exp_cnt++;
                $exp_arr[$exp_cnt][1] = $row_num;
                $exp_arr[$exp_cnt][2] = $col_num;
              }
            }
          }
        }

        my $the_time = time() - $initial_time;
        if ($the_time > $cpu_limit){
          last;
        }
      }

      my $the_time = time() - $initial_time;
      if ($the_time > $cpu_limit){
        if ($the_lb < $the_ub){
          $sol_nonopt = 1;
        }
        if ($the_verb <= 1){print CYAN, "[INFO] CPU time limit on the algorithm has expired! Returning the solution... \n", RESET;}
        last;
      }
      else{
        if (!$ub_updated){
          $no_sol_ite++;
          $the_lb = $the_mid + 1;
        }
        else{
          $no_sol_ite = 1;
        }
        if ($the_verb <= 1){print YELLOW, "[INFO] Updating the search bounds... Lower bound: $the_lb Upper bound: $the_ub \n", RESET;}
      }
    }
    
    my $total_time = time() - $initial_time;
    my $optlatsize_str = $opt_row . "x" . $opt_col;
    if ($sol_opt){
      if ($sol_nonopt){
        if ($the_verb < 2){print BOLD BLUE "[INFO] Great! Through a number of difficulties, a solution has just been found using a $optlatsize_str lattice! \n", RESET;}
      }
      else{
        if ($the_verb < 2){print GREEN "[INFO] Hurray!!! A solution has just been found using a $optlatsize_str lattice without any difficulty! \n", RESET;}
      }
    }
    else{
      if ($the_verb < 2){print RED "[INFO] No solution was found for the given target function! \n", RESET;}
    }

    write_solution($total_time, $file_pla, $sol_opt, $sol_nonopt, $opt_row, $opt_col, $tot_sat_var, $tot_sat_cnf, $tot_sat_run, @opt_sol);

    if ($the_verb < 2){print CYAN, "[INFO] CPU time: $total_time \n", RESET;}
  }

  return ($sol_opt, $sol_nonopt);
}

1;

