#!/usr/bin/perl

use Cwd qw(); 
use strict;
use warnings;
#use diagnostics;
use Storable qw(dclone);
use List::Util qw[min max];
use Time::HiRes qw( time );
use warnings FATAL => 'all';
use Term::ANSIColor qw(:constants);
use Term::ANSIColor 2.00 qw(:pushpop);

my $the_verb = 2;
my $the_tech = 2;
my $file_pla = "";
my $sat_limit = 1200;
my $cpu_limit = 21600;
my $the_algo = "janus";

my $arg_ok = 1;
my $arg_cnt = 0;
while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
      last;
    }
    else{
      if (index($ARGV[$arg_cnt], "-verb=") != -1){
        $the_verb = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_verb < 0 or $the_verb > 2){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-cpu_lim=") != -1){
        $cpu_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9) + 0.0;
      }
      elsif (index($ARGV[$arg_cnt], "-sat_lim=") != -1){
        $sat_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9) + 0.0;
      }
      elsif (index($ARGV[$arg_cnt], "-algo=") != -1){
        $the_algo = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6);
        if ($the_algo ne "janus" and $the_algo ne "medea"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-tech=") != -1){
        $the_tech = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_tech < 1 or $the_tech > 3){
          $arg_ok = 0;
        }
      }
      else{
        if (!$arg_cnt){
          $file_pla = $ARGV[0];
        }
        else{
          $arg_ok = 0;
          last;
        }
      }
    }
  }
  else{
    if (!$arg_cnt){
      $arg_ok = 0;
    }
    last;
  }

  $arg_cnt++;
}

if ($arg_ok){
  if ($file_pla ne ""){
    main_part();
  }
  else{
    help_part();
  }
}
else{
  help_part();
}

sub help_part{
  print "################################################################################################################################### \n";
  print "# Usage:       perl mf_tool.pl <File_Name> -verb=0/1/2 -cpu_lim=<int> -sat_lim=<int> -algo=janus/medea -tech=<int>                # \n";
  print "# File_Name:   Name of the file including multiple logic functions given in PLA format                                            # \n";
  print "# -verb:       Level of verbosity (0: full, 1: medium, 2: none), by default it is none                                            # \n";
  print "# -cpu_lim:    CPU time limit in seconds, by default it is 21600                                                                  # \n";
  print "# -sat_lim:    CPU time limit for the SAT algorithm in seconds, by default it is 1200                                             # \n";
  print "# -algo:       The algorithm used to optimize the switching lattice in the first and second techniques, by default it is janus    # \n";
  print "# -tech:       The design technique, by default it is 2                                                                           # \n";
  print "#                1: Realizes each output at a time using janus/medea to find the optimized solution and merge these lattices      # \n";
  print "#                2: Initially, apply the first technique and then, checks if the #rows and #columns in each output can be reduced # \n";
  print "#                3: Aims to implement each output with the minimum number of rows, starting from 3                                # \n";
  print "# Description: Finds the realization of multiple logic functions in a lattice including four-terminal switches                    # \n";
  print "################################################################################################################################### \n";
}

sub is_inside_numeric_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] == $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub is_inside_string_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] eq $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      return $the_offset;
    }
  }

  return $the_offset;
}

sub skip_spaces_backward{
  my ($the_string, $the_offset) = @_;

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset--;
    if ($the_offset < 0) {
      last;
    }
  }

  return $the_offset;
}

sub convert2binary{
  my ($the_int, $the_len) = @_;

  my @the_rep = ();

  foreach my $i (1 .. $the_len){
    $the_rep[$i] = 0;
  }

  my $the_index = 0;
  while ($the_int > 1){
    $the_index++;
    my $the_val = $the_int % 2;
    $the_rep[$the_index] = $the_val;
    $the_int = ($the_int - $the_val) / 2;
  }

  $the_index++;
  $the_rep[$the_index] = $the_int;

  return (@the_rep);
}

sub file_read_pla{
  my ($the_file) = @_;

  my $init_index = 0;
  my $last_index = 0;

  my $in_num = 0;
  my $out_num = 0;
  my $min_deg = 0;
  my $prod_num = 0;
  my $prod_cnt = 0;

  my @in_arr = ();
  my @out_arr = ();
  my @prod_arr = ();

  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $in_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $out_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".p ") != -1){
        $prod_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $in_cnt = 0;
        my $the_end = 0;
        
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_cnt++;
          $in_arr[$in_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($in_cnt != $in_num){
          print RED, "[ERROR] The number of inputs is not the same as the number of input labels \n", RESET;
          $in_num = 0;
          last;
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $out_cnt = 0;
        my $the_end = 0;
        
        $init_index = skip_spaces_forward($the_line, 3);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_cnt++;
          $out_arr[$out_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($out_cnt != $out_num){
          print RED, "[ERROR] The number of outputs is not the same as the number of output labels \n", RESET;
          $in_num = 0;
          last;
        }
      }
      elsif (index($the_line, ".") == -1){
        $init_index = skip_spaces_forward($the_line, 0);
        if ($init_index < $lline){ 
          $prod_cnt++;
          my $nondc_cnt = 0;
          my $prod_in_cnt = 0;

          while ($init_index < $lline){
            my $the_char = substr($the_line, $init_index, 1);
            if ($the_char eq " "){
              last;
            }
            else{
              $prod_in_cnt++;
              $prod_arr[$prod_in_cnt][$prod_cnt] = $the_char;
              $init_index++;

              if ($the_char ne "-"){
                $nondc_cnt++;
              }
            }
          }
          #print "[INFO] prod_in_cnt: $prod_in_cnt \n";

          if ($prod_in_cnt != $in_num){
            print RED, "[ERROR] The number of inputs is not the same as the number of inputs in the products \n", RESET;
            $in_num = 0;
            last;
          }
          else{
            if ($nondc_cnt > $min_deg){
              $min_deg = $nondc_cnt;
            }
            my $prod_out_cnt = 0;
            $init_index = skip_spaces_forward($the_line, $init_index);
            while ($init_index < $lline){
              my $the_char = substr($the_line, $init_index, 1);
              if ($the_char eq " "){
                last;
              }
              else{
                $prod_out_cnt++;
                $prod_arr[$in_num+$prod_out_cnt][$prod_cnt] = $the_char;
                $init_index++;
              }
            }
            #print "[INFO] out_num: $out_num \n";
            #print "[INFO] prod_out_cnt: $prod_out_cnt \n";

            if ($prod_out_cnt != $out_num){
              print RED, "[ERROR] The number of outputs is not the same as the number of outputs in the products \n", RESET;
              $in_num = 0;
              last;
            }
          }
        }
      }
    }

    #print "prod_num: $prod_num \n";
    #print "prod_cnt: $prod_cnt \n";
    if ($prod_num and $prod_cnt != $prod_num){
      print RED, "[ERROR] The number of products is not the same as the number of given products \n", RESET;
      $in_num = 0;
    }

    if (!@in_arr and $in_num){
      foreach my $i (1 .. $in_num){
        $in_arr[$i] = "in" . $i;
      }
    }

    if (!@out_arr and $out_num){
      foreach my $i (1 .. $out_num){
        $out_arr[$i] = "out" . $i;
      }
    }

    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n";
  }

  return ($in_num, $out_num, $prod_cnt, $min_deg, \@in_arr, \@out_arr, \@prod_arr);
}

sub generate_pla_file{
  my ($file_out, $out_var, $in_num, $out_num, $prod_num, $in_arr_ref, $out_arr_ref, $prod_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @out_arr = @ {$out_arr_ref};
  my @prod_arr = @ {$prod_arr_ref};

  if (open (my $fid_out, '>', $file_out)) {
    printf $fid_out ".i %0d \n", $in_num;
    printf $fid_out ".o 1 \n";
    printf $fid_out ".ilb ";
    foreach my $i (1 .. $in_num){
      printf $fid_out "%0s ", $in_arr[$i];
    }
    printf $fid_out "\n";
    printf $fid_out ".ob %0s \n", $out_arr[$out_var];
    printf $fid_out ".p %0d \n", $prod_num;
    foreach my $i (1 .. $prod_num){
      foreach my $j (1 .. $in_num){
        printf $fid_out "%s", $prod_arr[$j][$i];
      }
      printf $fid_out " %s \n", $prod_arr[$in_num+$out_var][$i];
    }
    printf $fid_out ".e \n";
  }
  else{
    print "[ERROR] Could not open the $file_out file! \n";
  }
}

#sub extract_espresso_path{
#  my $path_espresso = "";
#  
#  if ($os_type == 1){
#    $path_espresso = "C:/Users/ECC-LAB/Levent/codes/espresso_win/espresso ";
#  }
#  elsif ($os_type == 2){
#    $path_espresso = "/okyanus/users/laksoy/cad_tools/sis-1.3.6/espresso/espresso ";
#  }
#  else{
#    $path_espresso = "/home/levent/codes/sis-1.3.6/espresso/espresso ";
#  }
#
#  return ($path_espresso);
#}

sub extract_paths{
  my ($paths_file) = @_;

  my $path_espresso = " ";
  my $path_ilp = " ";
  my $path_sat = " ";
  my $paths_ok = 1;

  if (-e $paths_file){
    my $the_index = 0;
    my $init_index = 0;
    my $last_index = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $paths_file)){
      while (my $the_line = <$file_header>){
        chomp $the_line;
        #print "$the_line \n";

        $the_index = index ($the_line, "=");

        if ($the_index >= 0){
          $init_index = skip_spaces_forward($the_line, 0);
          $last_index = skip_spaces_backward($the_line, $the_index-1);
          my $the_solver = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_solver: $the_solver \n";

          $init_index = skip_spaces_forward($the_line, $the_index+1);
          $last_index = skip_spaces_backward($the_line, length($the_line));
          my $the_path = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_path: $the_path \n";

          if ($the_path =~ /[0-9a-zA-Z_]/ ){
            if ($the_solver eq "espresso"){
              $path_espresso = $the_path;
            }
            elsif ($the_solver eq "ilp"){
              $path_ilp = $the_path;
            }
            elsif ($the_solver eq "sat"){
              $path_sat = $the_path;
            }
          }
          else{
            $paths_ok = 0;
          }
        }
      }

      if ($path_espresso eq " ") {
        $paths_ok = 0;
        print RED, "[ERROR] The path to the espresso could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_espresso: $path_espresso \n";
      #}
      if ($path_ilp eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the ILP solver could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_ilp: $path_ilp \n";
      #}
      if ($path_sat eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the SAT solver could not be extracted from the $paths_file file! \n", RESET;
      }
      #else{
      #  print "[INFO] path_sat: $path_sat \n";
      #}

      close ($file_header);
    }
    else{
      print RED, "[ERROR] Could not open the $paths_file file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not find the file including paths to solvers! \n", RESET;
  }

  return ($paths_ok, $path_espresso, $path_ilp, $path_sat);
}

sub remove_dontcare_inputs{
  my ($file_simp) = @_;
  
  my $in_num = 0;
  my $out_num = 0;
  my $prod_num = 0;

  my @in_arr = ();
  my @out_arr = ();
  my @prod_arr = ();

  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  my $ndc_in_cnt;
  my @ndc_in_arr;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $in_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $out_num = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $in_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_cnt++;
          $in_arr[$in_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $out_cnt = 0;
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_cnt++;
          $out_arr[$out_cnt] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
      elsif (index($the_line, ".") == -1){
        $prod_num++;

        my $in_cnt = 0;
        $the_index = skip_spaces_forward($the_line, 0);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $in_cnt++;
          $prod_arr[$in_cnt][$prod_num] = $the_char;
          $the_index++;

          if ($in_cnt == $in_num){
            last;
          }
        }

        my $out_cnt = 0;
        $the_index = skip_spaces_forward($the_line, $the_index);
        while (1){
          my $the_char = substr($the_line, $the_index, 1);
          $out_cnt++;
          $prod_arr[$in_num+$out_cnt][$prod_num] = substr($the_line, $the_index , 1);
          $the_index++;

          if ($out_cnt == $out_num){
            last;
          }
        }
      }
    }
    
    close $file_header;

    if (!(@in_arr)){
      foreach my $i (1 .. $in_num){
        $in_arr[$i] = $i;
      }
    }

    #Check if an input variable is DC
    my $dcin_cnt = 0;
    my @dcin_arr = ();
    foreach my $i (1 .. $in_num){
      my $is_dcin = 1;
      foreach my $j (1 .. $prod_num){
        if ($prod_arr[$i][$j] eq "0" or $prod_arr[$i][$j] eq "1"){
          $is_dcin = 0;
          last;
        }
      }

      if ($is_dcin){
        #print "[INFO] The $in_arr[$i] input is always DC and hence, is removed from the input list \n";
        $dcin_cnt++;
        $dcin_arr[$dcin_cnt] = $i;
      }
    }

    if ($dcin_cnt){
      $ndc_in_cnt = 0;
      @ndc_in_arr = ();

      open (my $fid_pla, '>', $file_simp);
      printf $fid_pla ".i %0d \n", $in_num - $dcin_cnt;
      printf $fid_pla ".o %0d \n", $out_num;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_num){
          if (!is_inside_numeric_array($i, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s ", $in_arr[$i];

            $ndc_in_cnt++;
            $ndc_in_arr[$ndc_in_cnt] = $in_arr[$i];
          }
        }
        printf $fid_pla "\n";
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_num){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".p %0d \n", $prod_num;
      foreach my $i (1 .. $prod_num){
        foreach my $j (1 .. $in_num){
          if (!is_inside_numeric_array($j, $dcin_cnt, @dcin_arr)){
            printf $fid_pla "%0s", $prod_arr[$j][$i];
          }
        }
        printf $fid_pla " ";
        foreach my $j (1 .. $out_num){
          printf $fid_pla "%0s", $prod_arr[$in_num+$j][$i];
        }
        printf $fid_pla "\n";
      }
      printf $fid_pla ".e \n";
      close ($fid_pla);
    }
    else{
      $ndc_in_cnt = $in_num;
      @ndc_in_arr = @in_arr;
    }

  }
  else{
    print RED, "Could not open the $file_simp file \n";
  }

  return ($ndc_in_cnt, @ndc_in_arr);
}

sub simplify_sop{
  my ($file_dir, $the_file, $path_espresso) = @_;
  #print "The file: $the_file \n";

  my $false_true = -1;
  
  my $in_cnt = 0;
  my $in_say = 0;
  my $lit_cnt = 0;
  my $out_cnt = 0;
  my $out_say = 0;
  my @in_arr = ();
  my @tt_arr = ();
  my @lit_arr = ();
  my @out_arr = ();
  
  my $deg_simp = 0;
  my $prod_simp = 0;
  my $mindeg_simp = 0;
  my $prod_cnt_simp = 0;
  my @prod_num_simp = ();
  my @prod_lvl_simp = ();
  my @prod_ind_simp = ();
  my @prod_arr_simp = ();

  my $init_index = 0;
  my $last_index = 0;

  my $dot_index = index($the_file, ".pla");
  my $file_simp = substr($the_file, 0, $dot_index) . "_simp.pla";

  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $prod_cnt = 0;
    my @prod_arr = ();
    my $minreq_cnt = 0;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      my $lline = length($the_line);

      if (index($the_line, ".i ") != -1){
        $minreq_cnt++;
        $in_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".o ") != -1){
        $minreq_cnt++;
        $out_cnt = substr($the_line, 3, $lline-3) + 0.0;
      }
      elsif (index($the_line, ".ilb ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 4);

        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The input: $the_var \n";
          #sleep 1;

          $in_say++;
          $in_arr[$in_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($in_cnt and $in_say != $in_cnt){
          print RED, "[ERROR] The number of inputs is not the same as the number of input labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".ob ") != -1){
        my $the_end = 0;
        $init_index = skip_spaces_forward($the_line, 3);
        
        while ($init_index < $lline){
          $last_index = $init_index;
          while (substr($the_line, $last_index, 1) ne " "){
            $last_index++;

            if ($last_index >= $lline){
              $the_end = 1;
              last;
            }
          }

          my $the_var = substr($the_line, $init_index, $last_index-$init_index);
          #print "The output: $the_var \n";
          #sleep 1;

          $out_say++;
          $out_arr[$out_say] = $the_var;

          if ($the_end){
            last;
          }
          else{
            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }

        if ($out_cnt and $out_say != $out_cnt){
          print RED, "[ERROR] The number of outputs is not the same as the number of output labels \n", RESET;
          $in_cnt = 0;
          last;
        }
      }
      elsif (index($the_line, ".") == -1){
        if ($minreq_cnt < 2){
          $prod_cnt++;
          $prod_arr[$prod_cnt] = $the_line;
        }
      }
    }

    close $file_header;

    if ($minreq_cnt < 2){
      my $init_index = skip_spaces_forward($prod_arr[1], 0);
      my $last_index = index($prod_arr[1], " ", $init_index);
      $in_cnt = $last_index - $init_index;

      $last_index = skip_spaces_forward($prod_arr[1], $last_index);
      while (substr($prod_arr[1], $last_index, 1) ne " "){
        $last_index++;
        $out_cnt++;

        if ($last_index >= length($prod_arr[1])){
          last;
        }
      }

      my $file_temp = $file_dir . "temp_file.pla";
      open (my $fid_pla, '>', $file_temp);
      printf $fid_pla ".i %0s \n", $in_cnt;
      printf $fid_pla ".o %0s \n", $out_cnt;
      if (@in_arr){
        printf $fid_pla ".ilb ";
        foreach my $i (1 .. $in_say){
          printf $fid_pla "%0s ", $in_arr[$i];
        }
      }
      if (@out_arr){
        printf $fid_pla ".ob ";
        foreach my $i (1 .. $out_say){
          printf $fid_pla "%0s ", $out_arr[$i];
        }
      }
      printf $fid_pla ".p %0s \n", $prod_cnt;
      foreach my $i (1 .. $prod_cnt){
        printf $fid_pla "%0s \n", $prod_arr[$i];
      }
      printf $fid_pla ".e \n";
      close $fid_pla;

      my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_simp;
      system($the_cmd);
    }
    else{
      my $the_cmd = $path_espresso . " -Dexact " . $the_file . " > " . $file_simp;
      system($the_cmd);
    }

    if (!@in_arr){
      foreach my $i (1 .. $in_cnt){
        $in_arr[$i] = "$i";
      }
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
    return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
  }

  ($in_cnt, @in_arr) = remove_dontcare_inputs($file_simp);

  #Generating the initial truth table with full of zeros
  foreach my $i (0 .. 2**$in_cnt-1) {
    my @bin_rep = convert2binary($i, $in_cnt);
    foreach my $j (1 .. $in_cnt){
      $tt_arr[$i][$j] = $bin_rep[$j];
    }
    $tt_arr[$i][$in_cnt+1] = 0;
  }

  #Display the truth table
  #foreach my $i (0 .. 2**$in_cnt-1){
  #  foreach my $j (1 .. $in_cnt+1){
  #    print "$tt_arr[$i][$j]";
  #  }
  #  print "\n";
  #}

  #Generating the initial literal index array
  my @lit_index_arr = ();
  foreach my $i (1 .. 2*$in_cnt){
    $lit_index_arr[$i] = 0;
  }

  my $in_simp = 0;
  my $neg_lit = 0;
  my $pos_lit = 0;
  #Find the degree for the upper bound and generate the truth table
  if (open (my $file_header, '<:encoding(UTF-8)', $file_simp)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".i ") != -1){
        my $the_index = 3;
        $in_simp = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
      }
      elsif (index($the_line, ".p ") != -1){
        my $the_index = 3;
        $prod_simp = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;

        if (!$prod_simp and !$in_simp){
          $in_cnt = 0;
          $false_true = 0;
          print YELLOW, "[INFO] The target function is equal to zero. No need to run the lattice synthesis algorithm! \n", RESET;
          return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
        }
        if ($prod_simp == 1 and !$in_simp){
          $in_cnt = 0;
          $false_true = 1;
          print YELLOW, "[INFO] The target function is equal to one. No need to run the lattice synthesis algorithm! \n", RESET;
          return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
        }
      }
      elsif (index($the_line, ".") == -1){
        my $x_cnt = 0;
        my @x_arr = ();
        my $the_base = 0;
        
        my $lit_num = 0;
        $prod_cnt_simp++;
        my $the_index = -1;
        my $the_char = " ";
            
        do{
          $the_index++;
          $the_char = substr($the_line, $the_index, 1);
          if ($the_char eq "0"){
            $lit_num++;
            $neg_lit = 1;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = "!" . $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = -1;

            $lit_index_arr[2*($the_index+1)]++;
          }
          elsif ($the_char eq "1"){
            $pos_lit = 1;
            $the_base = $the_base + 2**$the_index;
            
            $lit_num++;
            $prod_lvl_simp[$prod_cnt_simp] = $lit_num;
            $prod_arr_simp[$lit_num][$prod_cnt_simp] = $in_arr[$the_index+1];
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 1;
            
            $lit_index_arr[2*($the_index+1)-1]++;
          }
          elsif ($the_char eq "-"){
            $x_cnt++;
            $x_arr[$x_cnt] = $the_index;
            $prod_ind_simp[$the_index+1][$prod_cnt_simp] = 0;
          }
        }while ($the_char ne " ");

        if (defined $prod_num_simp[$lit_num]){
          $prod_num_simp[$lit_num]++;
        }
        else{
          $prod_num_simp[$lit_num] = 1;
        }

        if ($lit_num > $deg_simp){
          $deg_simp = $lit_num;
        }

        #Find the truth table entries where the function is high
        if ($x_cnt){
          my @val_arr = ();
          my $the_pointer = 0;

          foreach my $i (1 .. $x_cnt){
            $val_arr[$i] = 0;
          }

          do{
            #Display the val_arr
            #foreach my $i (1 .. $x_cnt){
            #  print "$val_arr[$i]";
            #}
            #print "\n";

            $the_pointer = 1;

            my $x_sum = $the_base;
            foreach my $i (1 .. $x_cnt){
              $x_sum = $x_sum + $val_arr[$i] * 2**$x_arr[$i];
            }
            $tt_arr[$x_sum][$in_cnt+1] = 1;

            while ($val_arr[$the_pointer]){
              $val_arr[$the_pointer] = 0;
              $the_pointer++;

              if ($the_pointer > $x_cnt){
                last;
              }
            }

            if ($the_pointer <= $x_cnt){
              $val_arr[$the_pointer] = 1;
            }  
          }while ($the_pointer <= $x_cnt);
        }
        else{
          $tt_arr[$the_base][$in_cnt+1] = 1;
        }
      }
    }

    #Display the truth table
    #foreach my $i (0 .. 2**$in_cnt-1){
    #  foreach my $j (1 .. $in_cnt+1){
    #    print "$tt_arr[$i][$j]";
    #  }
    #  print "\n";
    #}

    close $file_header;
  }
  else{
    $in_cnt = 0;
    print RED, "[ERROR] Could not open the $file_simp file! \n", RESET;
    return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
  }

  #Generate the literal array including the literals to be considered
  foreach my $i (1 .. 2*$in_cnt){
    if ($lit_index_arr[$i]){
      $lit_cnt++;
      if ($i % 2){
        $lit_arr[$lit_cnt] = ($i+1)/2;
      }
      else{
        $lit_arr[$lit_cnt] = (-1)*($i)/2;
      }
    }
  }

  #Find the minimum degree for the lower bound in a recursive fashion
  my $file_prim = substr($the_file, 0, $dot_index) . "_simp_prim.pla";
  my $the_cmd = $path_espresso . " -Dprimes " . $file_simp . " > " . $file_prim;
  system($the_cmd);
  
  while (1) {
    my $max_deg = 0;
    my $min_deg = 9*9*9;

    my @lit_mat = ();
    my $prim_cnt = 0;
    my @prim_arr = ();
    my $maxprim_cnt = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".") == -1){
          my $lit_num = 0;
          my $the_index = -1;
          my $the_char = " ";

          $prim_cnt++;
          $prim_arr[$prim_cnt] = $the_line;

          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0" or $the_char eq "1"){
              $lit_num++;
            }
          }while ($the_char ne " ");

          $lit_mat[$prim_cnt] = $lit_num;

          if ($lit_num > $max_deg){
            $max_deg = $lit_num;
            $maxprim_cnt = 1;
          }
          elsif ($lit_num == $max_deg){
            $maxprim_cnt++;
          }
          
          if ($lit_num < $min_deg){
            $min_deg = $lit_num;
          }
        }
      }
      close $file_header;

      #print "Minimum number of literals: $min_deg \n";
      #print "Maximum number of literals: $max_deg \n";

      if ($min_deg < $max_deg){
        my $file_temp = $file_dir . "temp_file.pla";
        my $file_verify = $file_dir . "verify.out";

        open (my $fid_temp, '>', $file_temp);
        foreach my $i (1 .. $prim_cnt){
          if ($lit_mat[$i] != $max_deg){
            printf $fid_temp "%0s \n", $prim_arr[$i];
          }
        }
        close $fid_temp;

        my $the_cmd = $path_espresso . " -Dverify " . $file_simp . " " . $file_temp . " > " . $file_verify;
        system($the_cmd);

        my $is_verified = 0;
        if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, "compared equal") != -1){
              $is_verified = 1;
              last;
            }
          }

          if (!$is_verified){
            $mindeg_simp = $max_deg;
            last;
          }
          else{
            open (my $fid_prim, '>', $file_prim);
            printf $fid_prim ".i %0d \n", $in_cnt;
            printf $fid_prim ".o %0d \n", $out_cnt;
            printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
            foreach my $i (1 .. $prim_cnt){
              if ($lit_mat[$i] != $max_deg){
                printf $fid_prim "%0s \n", $prim_arr[$i];
              }
            }
            printf $fid_prim ".e \n";
            close $fid_prim;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
        }
      }
      else{
        $mindeg_simp = $max_deg;
        last;
      }
    }
    else{
      $in_cnt = 0;
      print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
      return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
    }
  }

  return ($false_true, $file_simp, $prod_simp, $deg_simp, $mindeg_simp, $in_cnt, $out_cnt, $lit_cnt, \@in_arr, \@lit_arr, \@prod_num_simp, \@prod_lvl_simp, \@prod_arr_simp, \@prod_ind_simp, \@tt_arr);
}


sub find_dual{
  my ($file_dir, $the_file, $path_espresso, $in_cnt, $out_cnt, $in_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};

  my @tt_arr = ();
  my $deg_num = 0;
  my $prod_cnt = 0;
  my @prod_lvl = ();
  my @prod_ind = ();
  my @prod_arr = ();
  my $mindeg_num = 0;
  my @prod_num_dual = ();
  
  my $dot_index = index($the_file, ".pla");
  my $file_dual = substr($the_file, 0, $dot_index) . "_dual.pla";

  #Generating the dual pla file by complementing each variable and the output function
  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_out, '>', $file_temp);
  if (open (my $file_header, '<:encoding(UTF-8)', $the_file)){
    my $first_prod = 1;

    while (my $the_line = <$file_header>){
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      
      my $the_char = "";
      my $the_index = 0;
     
      if (index($the_line, ".") == -1){
        #Complementing the output function
        if ($first_prod){
          printf $fid_out ".phase 0 \n";
          $first_prod = 0;
        }

        #Complementing the variable
        $the_index = skip_spaces_forward($the_line, $the_index);
        do {
          $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq "1"){
            printf $fid_out "0";
          }
          elsif ($the_char eq "0"){
            printf $fid_out "1";
          }
          elsif ($the_char eq "-" or $the_char eq " "){
            printf $fid_out "%0s", $the_char;
          }
          else{
            print "[WARNING] Only expecting 0 1 or - in this case. Something must be wrong! \n";
          }
          $the_index++;
        }while ($the_char ne " ");

        printf $fid_out "%0s \n", substr($the_line, $the_index, length($the_line)-$the_index+1);
      }
      else{
        printf $fid_out "%s \n", $the_line;
      }
    }

    close $file_header;
    close $fid_out;
    
    #Find the dual function with espresso
    my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_dual;
    system($the_cmd);

    #Generating the initial truth table with full of zeros
    foreach my $i (0 .. 2**$in_cnt-1) {
      my @bin_rep = convert2binary($i, $in_cnt);
      foreach my $j (1 .. $in_cnt){
        $tt_arr[$i][$j] = $bin_rep[$j];
      }
      $tt_arr[$i][$in_cnt+1] = 0;
    }

    #Compute the degree of the dual function for the upper bound, determine the literals, and generate the truth table.
    if (open (my $file_header, '<:encoding(UTF-8)', $file_dual)){
      my $prod_num = 0;
      while (my $the_line = <$file_header>){
        chomp $the_line;

        if (index($the_line, ".p ") != -1){
          my $the_index = 3;
          $prod_cnt = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
        }
        elsif (index($the_line, ".") == -1){
          my $x_cnt = 0;
          my @x_arr = ();
          my $the_base = 0;
        
          my $lit_cnt = 0;
          $prod_num++;
          my $the_index = -1;
          my $the_char = " ";
          do{
            $the_index++;
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "0"){ 
              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = "!" . $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = -1;
            }
            elsif ($the_char eq "1"){
              $the_base = $the_base + 2**$the_index;

              $lit_cnt++;
              $prod_lvl[$prod_num] = $lit_cnt;
              $prod_arr[$lit_cnt][$prod_num] = $in_arr[$the_index+1];
              $prod_ind[$the_index+1][$prod_num] = 1;
            }
            elsif ($the_char eq "-") {
              $x_cnt++;
              $x_arr[$x_cnt] = $the_index;
              $prod_ind[$the_index+1][$prod_num] = 0;
            }
          }while ($the_char ne " ");

          if (defined $prod_num_dual[$lit_cnt]){
            $prod_num_dual[$lit_cnt]++;
          }
          else{
            $prod_num_dual[$lit_cnt] = 1;
          }

          if ($lit_cnt > $deg_num){
            $deg_num = $lit_cnt;
          }

          #Find the truth table entries where the function is high
          if ($x_cnt){
            my @val_arr = ();
            my $the_pointer = 0;

            foreach my $i (1 .. $x_cnt){
              $val_arr[$i] = 0;
            }

            do{
              $the_pointer = 1;

              my $x_sum = $the_base;
              foreach my $i (1 .. $x_cnt){
                $x_sum = $x_sum + $val_arr[$i] * 2**$x_arr[$i];
              }
              $tt_arr[$x_sum][$in_cnt+1] = 1;

              while ($val_arr[$the_pointer]){
                $val_arr[$the_pointer] = 0;
                $the_pointer++;

                if ($the_pointer > $x_cnt){
                  last;
                }
              }

              if ($the_pointer <= $x_cnt){
                $val_arr[$the_pointer] = 1;
              }  
            }while ($the_pointer <= $x_cnt);
          }
          else{
            $tt_arr[$the_base][$in_cnt+1] = 1;
          }
        }
      }
      close $file_header;

      #Compute the minimum degree for the lower bound in a recursive fashion
      my $file_prim = substr($the_file, 0, $dot_index) . "_dual_prim.pla";
      $the_cmd = $path_espresso . " -Dprimes " . $file_dual . " > " . $file_prim;
      system($the_cmd);
      
      while (1) {
        my $max_deg = 0;
        my $min_deg = 9*9*9;

        my @lit_arr = ();
        my $prim_cnt = 0;
        my @prim_arr = ();
        my $maxprim_cnt = 0;

        if (open (my $file_header, '<:encoding(UTF-8)', $file_prim)){
          while (my $the_line = <$file_header>){
            chomp $the_line;

            if (index($the_line, ".") == -1){
              my $lit_cnt = 0;
              my $the_index = -1;
              my $the_char = " ";

              $prim_cnt++;
              $prim_arr[$prim_cnt] = $the_line;

              do{
                $the_index++;
                $the_char = substr($the_line, $the_index, 1);
                if ($the_char eq "0" or $the_char eq "1"){
                  $lit_cnt++;
                }
              }while ($the_char ne " ");

              $lit_arr[$prim_cnt] = $lit_cnt;

              if ($lit_cnt > $max_deg){
                $max_deg = $lit_cnt;
                $maxprim_cnt = 1;
              }
              elsif ($lit_cnt == $max_deg){
                $maxprim_cnt++;
              }
              
              if ($lit_cnt < $min_deg){
                $min_deg = $lit_cnt;
              }
            }
          }
          close $file_header;

          #print "Minimum number of literals: $min_deg \n";
          #print "Maximum number of literals: $max_deg \n";

          if ($min_deg < $max_deg){
            my $file_temp = $file_dir . "temp_file.pla";
            open (my $fid_temp, '>', $file_temp);
            foreach my $i (1 .. $prim_cnt){
              if ($lit_arr[$i] != $max_deg){
                printf $fid_temp "%0s \n", $prim_arr[$i];
              }
            }
            close $fid_temp;

            my $file_verify = $file_dir . "verify.out";
            $the_cmd = $path_espresso . " -Dverify " . $file_dual . " " . $file_temp . " > " . $file_verify;
            system($the_cmd);

            my $is_verified = 0;
            if (open (my $file_header, '<:encoding(UTF-8)', $file_verify)){
              while (my $the_line = <$file_header>){
                chomp $the_line;

                if (index($the_line, "compared equal") != -1){
                  $is_verified = 1;
                  last;
                }
              }

              if (!$is_verified){
                $mindeg_num = $max_deg;
                last;
              }
              else{
                open (my $fid_prim, '>', $file_prim);
                printf $fid_prim ".i %0d \n", $in_cnt;
                printf $fid_prim ".o %0d \n", $out_cnt;
                printf $fid_prim ".p %0d \n", $prim_cnt - $maxprim_cnt;
                foreach my $i (1 .. $prim_cnt){
                  if ($lit_arr[$i] != $max_deg){
                    printf $fid_prim "%0s \n", $prim_arr[$i];
                  }
                }
                printf $fid_prim ".e \n";
                close $fid_prim;
              }
            }
            else{
              print RED, "[ERROR] Could not open the $file_verify file \n", RESET;
            }
          }
          else{
            $mindeg_num = $max_deg;
            last;
          }
        }
        else{
          print RED, "[ERROR] Could not open the $file_prim file! \n", RESET;
        }
      }
    }
    else{
      print RED, "[ERROR] Could not open the $file_dual file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not open the $the_file file! \n", RESET;
  }

  return ($file_dual, $prod_cnt, $deg_num, $mindeg_num, \@prod_num_dual, \@prod_lvl, \@prod_arr, \@prod_ind, \@tt_arr);
}

sub determine_single_double_products{
  my ($in_num, $lit_num, $in_arr_ref, $lit_arr_ref, $prod_cnt, $prod_lvl_ref, $prod_arr_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl = @ {$prod_lvl_ref};
  my @prod_arr = @ {$prod_arr_ref};

  my $non_double = 0;
  my $non_single = 0;
  my @double_lit = ();
  my @single_lit = ();

  my $wide_cnt = 0;
  my $thin_cnt = 0;
  my $wide_thin = 0;

  my $the_index;
  $double_lit[0] = 0;
  $single_lit[0] = 0;
  foreach my $i (1 .. $prod_cnt){
    if ($prod_lvl[$i] == 1){
      $single_lit[0]++;
      my $the_var = $prod_arr[1][$i];
      if (index($the_var, "!") == -1){
        $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
      }
      else{
        $the_var = substr($the_var, 1, length($the_var)-1);
        $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
        $the_index = (-1) * $the_index;
      }

      $single_lit[$single_lit[0]] = is_inside_numeric_array($the_index, $lit_num, @lit_arr);
    }
    elsif ($prod_lvl[$i] == 2){
      $non_single = 1;

      $double_lit[0]++;
      foreach my $j (1 .. 2){
        my $the_var = $prod_arr[$j][$i];
        if (index($the_var, "!") == -1){
          $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
        }
        else{
          $the_var = substr($the_var, 1, length($the_var)-1);
          $the_index = is_inside_string_array($the_var, $in_num, @in_arr);
          $the_index = (-1)*$the_index;
        }

        $double_lit[2*($double_lit[0]-1)+$j] = is_inside_numeric_array($the_index, $lit_num, @lit_arr);
      }
    }
    else{
      $non_single = 1;
      $non_double = 1;
    }

    if ($prod_lvl[$i] < $in_num/2){
      $wide_cnt++;
    }
    else{
      $thin_cnt++;
    }
  }

  if ($thin_cnt > $wide_cnt){
    $wide_thin = 1;
  }

  return ($wide_thin, $non_single, $non_double, \@single_lit, \@double_lit);
}

sub read_match_pla{
  my ($file_dir, $the_first, $in_arr_ref, $prod_ind_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @prod_ind = @ {$prod_ind_ref};

  my $the_index;
  my $imp_cnt = 0;
  my $match_cnt = 0;
  my @match_arr = ();

  my $file_temp_dual= $file_dir . "temp_dual_file.pla";
  if (open (my $file_header, '<:encoding(UTF-8)', $file_temp_dual)){
    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, ".p ") != -1){
        $imp_cnt = substr($the_line, 3, length($the_line)-3) + 0.0;
      }
      elsif (index($the_line, ".") == -1){
        $match_cnt++;
        $the_index = -1;

        my $the_cnt = 0;
        my @the_ind = ();
        my @the_arr = ();
        while (1){
          $the_index++;
          my $the_char = substr($the_line, $the_index, 1);

          if ($the_char eq " "){
            last;
          }
          elsif($the_char eq "0"){
            $the_cnt++;
            $the_arr[$the_cnt] = "!" . $in_arr[$the_index+1];
            $the_ind[$the_cnt] = (-1)*($the_index+1);
          }
          elsif($the_char eq "1"){
            $the_cnt++;
            $the_arr[$the_cnt] = $in_arr[$the_index+1];
            $the_ind[$the_cnt] = $the_index+1;
          }

          if ($the_cnt == 1){
            $match_arr[$match_cnt][1] = $the_arr[1];
            $match_arr[$match_cnt][2] = $the_arr[1];
          }
          elsif ($the_cnt == 2){
            if ($prod_ind[abs($the_ind[1])][$the_first] == -1 and $the_ind[1] < 0){
              $match_arr[$match_cnt][1] = $the_arr[1];
              $match_arr[$match_cnt][2] = $the_arr[2];
            }
            elsif ($prod_ind[abs($the_ind[1])][$the_first] == 1 and $the_ind[1] > 0){
              $match_arr[$match_cnt][1] = $the_arr[1];
              $match_arr[$match_cnt][2] = $the_arr[2];
            }
            elsif ($prod_ind[abs($the_ind[2])][$the_first] == -1 and $the_ind[2] < 0){
              $match_arr[$match_cnt][1] = $the_arr[2];
              $match_arr[$match_cnt][2] = $the_arr[1];
            }
            elsif ($prod_ind[abs($the_ind[2])][$the_first] == 1 and $the_ind[2] > 0){
              $match_arr[$match_cnt][1] = $the_arr[2];
              $match_arr[$match_cnt][2] = $the_arr[1];
            }
          }
          elsif ($the_cnt > 2){
            print "[WARNING] The number of terms should not be greater than two! \n";
          }
        }
      }
    }
    close $file_header;
  }
  else{
    print RED "[ERROR] Could not open the temp_dual_file.pla file! \n", RESET;
  }

  return ($imp_cnt, $match_cnt, @match_arr);
}

sub write_match_pla{
  my ($file_dir, $in_num, $out_num, $the_first, $the_second, @prod_ind) = @_;

  my $file_temp = $file_dir . "temp_file.pla";
  open (my $fid_pla, '>', $file_temp);
  
  printf $fid_pla ".i %0d \n", $in_num;
  printf $fid_pla ".o %0d \n", $out_num;
  printf $fid_pla ".phase 0 \n";
  printf $fid_pla ".p 2 \n";
  foreach my $k (1 .. $in_num){
    if ($prod_ind[$k][$the_first] == 1){
      printf $fid_pla "0";
    }
    elsif ($prod_ind[$k][$the_first] == -1){
      printf $fid_pla "1";
    }
    else{
      printf $fid_pla "-";
    }
  }
  printf $fid_pla " 1 \n";
  
  foreach my $k (1 .. $in_num){
    if ($prod_ind[$k][$the_second] == 1){
      printf $fid_pla "0";
    }
    elsif ($prod_ind[$k][$the_second] == -1){
      printf $fid_pla "1";
    }
    else{
      printf $fid_pla "-";
    }
  }
  printf $fid_pla " 1 \n";
  printf $fid_pla ".e \n";
  
  close $fid_pla;
}

sub find_forth_upper_bound{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_simp, $deg_simp, $in_arr_ref, $lit_arr_ref, $single_lit_simp_ref, $double_lit_simp_ref, $prod_lvl_simp_ref, $prod_arr_simp_ref, $prod_ind_simp_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl_simp = @ {$prod_lvl_simp_ref};
  my @prod_arr_simp = @ {$prod_arr_simp_ref};
  my @prod_ind_simp = @ {$prod_ind_simp_ref};
  my @double_lit_simp = @ {$double_lit_simp_ref};
  my @single_lit_simp = @ {$single_lit_simp_ref};

  my $ub_four = 0;
  my $col_num = 0;
  my @imp_arr = ();
  my @sol_four = ();
  my $single_pointer = 0;

  #Initialize the implementation array
  foreach my $i (1 .. $prod_simp){
    if ($prod_lvl_simp[$i] == 1){
      $imp_arr[$i] = 1;
    }
    elsif ($double_lit_simp[0] > 1 and $prod_lvl_simp[$i] == 2){
      $imp_arr[$i] = 1;
    }
    else{
      $imp_arr[$i] = 0;
    }
  }

  my $the_end = 0;
  #First, place the products with two terms if there are more than one
  if ($double_lit_simp[0] > 1){
    foreach my $h (1 .. $double_lit_simp[0]){
      $ub_four += $deg_simp;

      my $first_var = "";
      if ($lit_arr[$double_lit_simp[2*$h-1]] < 0){
        $first_var = "!";
      }
      $first_var = $first_var . $in_arr[abs($lit_arr[$double_lit_simp[2*$h-1]])];
      
      my $second_var = "";
      if ($lit_arr[$double_lit_simp[2*$h]] < 0){
        $second_var = "!";
      }
      $second_var = $second_var . $in_arr[abs($lit_arr[$double_lit_simp[2*$h]])];
      
      $col_num++;
      foreach my $i (1 .. $deg_simp-1){
        $sol_four[$i][$col_num] = $first_var;
      }
      $sol_four[$deg_simp][$col_num] = $second_var;
    }

    $the_end = 1;
    foreach my $h (1 .. $prod_simp){
      if (!$imp_arr[$h]){
        $the_end = 0;
        last;
      }
    }

    if (!$the_end){
      #Adding a single term if there is any or just a false-column
      $col_num++;
      $ub_four += $deg_simp;
      if ($double_lit_simp[0] and $single_lit_simp[0]){
        $single_pointer++;
        
        my $the_var = "";
        if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
          $the_var = "!";
        }
        $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
        
        foreach my $i (1 .. $deg_simp){
          $sol_four[$i][$col_num] = $the_var;
        }
      }
      else{
        foreach my $i (1 .. $deg_simp){
          $sol_four[$i][$col_num] = "F";
        }
      }
    }
  }

  #Second, one by one add a prime implicant with a match if there is any
  if (!$the_end){
    foreach my $i (1 .. $prod_simp){
      if (!$imp_arr[$i]){
        my $imp_cnt;
        my $match_cnt;
        my @match_arr;
        my $match_found = 0;

        #Finding the match
        for (my $j = $i+1; $j <= $prod_simp; $j++){
          if (!$imp_arr[$j]){
            #Check if these prime implicants share at least oone common literal
            my $is_rel = 0;
            foreach my $k (1 .. $in_num){
              if ($prod_ind_simp[$k][$i] and $prod_ind_simp[$k][$j]){
                $is_rel = 1;
                last;
              }
            }

            if ($is_rel){
              write_match_pla($file_dir, $in_num, $out_num, $i, $j, @prod_ind_simp);
              my $file_temp = $file_dir . "temp_file.pla";
              my $file_temp_dual = $file_dir . "temp_dual_file.pla";
              my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_temp_dual;
              system ($the_cmd);
              ($imp_cnt, $match_cnt, @match_arr) = read_match_pla($file_dir, $i, \@in_arr, \@prod_ind_simp);

              if ($imp_cnt <= $deg_simp){
                $match_found = $j;
                last;
              }
            }
          }
        }

        if ($match_found){
          $col_num += 2;
          $imp_arr[$i] = 1;
          $imp_arr[$match_found] = 1;
          $ub_four += 2*$deg_simp;

          foreach my $j (1 .. $match_cnt){
            $sol_four[$j][$col_num-1] = $match_arr[$j][1];
            $sol_four[$j][$col_num] = $match_arr[$j][2];
          }
          for (my $j = $match_cnt+1; $j <= $deg_simp; $j++){
            $sol_four[$j][$col_num-1] = "T";
            $sol_four[$j][$col_num] = "T";
          }
        }
        else{
          $imp_arr[$i] = 1;
          $ub_four += $deg_simp;

          $col_num++;
          foreach my $j (1 .. $prod_lvl_simp[$i]){
            $sol_four[$j][$col_num] = $prod_arr_simp[$j][$i];
          }
          for (my $j = $prod_lvl_simp[$i]+1; $j <= $deg_simp; $j++){
            $sol_four[$j][$col_num] = "T";
          }
        }

        $the_end = 1;
        for (my $j = $i+1; $j <= $prod_simp; $j++){
          if (!$imp_arr[$j]){
            $the_end = 0;
            last;
          }
        }

        #Add a single-term prime implicant or a false-column if there is at least one prime implicant not considered, otherwise return
        if ($the_end){
          last;
        }
        else{
          $col_num++;
          $ub_four += $deg_simp;

          if ($single_pointer < $single_lit_simp[0]){
            $single_pointer++;
            
            my $the_var = "";
            if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
              $the_var = "!";
            }
            $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
            
            foreach my $j (1 .. $deg_simp){
              $sol_four[$j][$col_num] = $the_var;
            }
          }
          else{
            foreach my $j (1 .. $deg_simp){
              $sol_four[$j][$col_num] = "F";
            }
          }
        }
      }
    }
  }

  #Adding the single term prime implicant if there is any left
  while ($single_pointer < $single_lit_simp[0]){
    $col_num++;
    $single_pointer++;
    $ub_four += $deg_simp;
    
    my $the_var = "";
    if ($lit_arr[$single_lit_simp[$single_pointer]] < 0){
      $the_var = "!";
    }
    $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_simp[$single_pointer]])];
    
    foreach my $i (1 .. $deg_simp){
      $sol_four[$i][$col_num] = $the_var;
    }
  }

  #print "The solution on the forth criteria: \n";
  #foreach my $i (1 .. $deg_simp){
  #  print "| ";
  #  foreach my $j (1 .. $col_num){
  #    if (index($sol_four[$i][$j], "!") != -1){
  #      print "$sol_four[$i][$j] | ";
  #    }
  #    else{
  #      print "$sol_four[$i][$j]  | ";
  #    }
  #  }
  #  print "\n";
  #}

  return ($deg_simp, $col_num, @sol_four);
}

sub find_fifth_upper_bound{
  my ($file_dir, $path_espresso, $in_num, $out_num, $prod_dual, $deg_dual, $in_arr_ref, $lit_arr_ref, $single_lit_dual_ref, $prod_lvl_dual_ref, $prod_arr_dual_ref, $prod_ind_dual_ref) = @_;
  my @in_arr = @ {$in_arr_ref};
  my @lit_arr = @ {$lit_arr_ref};
  my @prod_lvl_dual = @ {$prod_lvl_dual_ref};
  my @prod_arr_dual = @ {$prod_arr_dual_ref};
  my @prod_ind_dual = @ {$prod_ind_dual_ref};
  my @single_lit_dual = @ {$single_lit_dual_ref};

  my $ub_five = 0;
  my $row_num = 0;
  my @imp_arr = ();
  my @sol_five = ();
  my $single_pointer = 0;

  #Initialize the implementation array
  my $the_end = 1;
  foreach my $i (1 .. $prod_dual){
    if ($prod_lvl_dual[$i] == 1){
      $imp_arr[$i] = 1;
    }
    else{
      $the_end = 0;
      $imp_arr[$i] = 0;
    }
  }

  #One by one add a prime implicant with a match if there is any
  if (!$the_end){
    foreach my $i (1 .. $prod_dual){
      if (!$imp_arr[$i]){
        my $imp_cnt;
        my $match_cnt;
        my @match_arr;
        my $match_found = 0;

        #Finding the match
        for (my $j = $i+1; $j <= $prod_dual; $j++){
          if (!$imp_arr[$j]){
            #Check if these prime implicants share at least oone common literal
            my $is_rel = 0;
            foreach my $k (1 .. $in_num){
              if ($prod_ind_dual[$k][$i] and $prod_ind_dual[$k][$j]){
                $is_rel = 1;
                last;
              }
            }

            if ($is_rel){
              write_match_pla($file_dir, $in_num, $out_num, $i, $j, @prod_ind_dual);
              my $file_temp = $file_dir . "temp_file.pla";
              my $file_temp_dual = $file_dir . "temp_dual_file.pla";
              my $the_cmd = $path_espresso . " -Dexact " . $file_temp . " > " . $file_temp_dual;
              system ($the_cmd);
              ($imp_cnt, $match_cnt, @match_arr) = read_match_pla($file_dir, $i, \@in_arr, \@prod_ind_dual);

              if ($imp_cnt <= $deg_dual){
                $match_found = $j;
                last;
              }
            }
          }
        }

        if ($match_found){
          $row_num += 2;
          $imp_arr[$i] = 1;
          $imp_arr[$match_found] = 1;
          $ub_five += 2*$deg_dual;

          foreach my $j (1 .. $match_cnt){
            $sol_five[$row_num-1][$j] = $match_arr[$j][1];
            $sol_five[$row_num][$j] = $match_arr[$j][2];
          }
          for (my $j = $match_cnt+1; $j <= $deg_dual; $j++){
            $sol_five[$row_num-1][$j] = "F";
            $sol_five[$row_num][$j] = "F";
          }
        }
        else{
          $imp_arr[$i] = 1;
          $ub_five += $deg_dual;

          $row_num++;
          foreach my $j (1 .. $prod_lvl_dual[$i]){
            $sol_five[$row_num][$j] = $prod_arr_dual[$j][$i];
          }
          for (my $j = $prod_lvl_dual[$i]+1; $j <= $deg_dual; $j++){
            $sol_five[$row_num][$j] = "F";
          }
        }

        $the_end = 1;
        for (my $j = $i+1; $j <= $prod_dual; $j++){
          if (!$imp_arr[$j]){
            $the_end = 0;
            last;
          }
        }

        #Add a single-term prime implicant or a false-row if there is at least one prime implicant not considered, otherwise return
        if ($the_end){
          last;
        }
        else{
          $row_num++;
          $ub_five += $deg_dual;

          if ($single_pointer < $single_lit_dual[0]){
            $single_pointer++;
            
            my $the_var = "";
            if ($lit_arr[$single_lit_dual[$single_pointer]] < 0){
              $the_var = "!";
            }
            $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_dual[$single_pointer]])];
            
            foreach my $j (1 .. $deg_dual){
              $sol_five[$row_num][$j] = $the_var;
            }
          }
          else{
            foreach my $j (1 .. $deg_dual){
              $sol_five[$row_num][$j] = "T";
            }
          }
        }
      }
    }
  }

  #Adding the single term prime implicant if there is any left
  while ($single_pointer < $single_lit_dual[0]){
    $row_num++;
    $single_pointer++;
    $ub_five += $deg_dual;
    
    my $the_var = "";
    if ($lit_arr[$single_lit_dual[$single_pointer]] < 0){
      $the_var = "!";
    }
    $the_var = $the_var . $in_arr[abs($lit_arr[$single_lit_dual[$single_pointer]])];
    
    foreach my $i (1 .. $deg_dual){
      $sol_five[$row_num][$i] = $the_var;
    }
  }

  #print "The solution on the fifth criteria: \n";
  #foreach my $i (1 .. $row_num){
  #  print "| ";
  #  foreach my $j (1 .. $deg_dual){
  #    if (index($sol_five[$i][$j], "!") != -1){
  #      print "$sol_five[$i][$j] | ";
  #    }
  #    else{
  #      print "$sol_five[$i][$j]  | ";
  #    }
  #  }
  #  print "\n";
  #}

  return ($row_num, $deg_dual, @sol_five);
}

sub run_lattice_algorithm{
  my ($the_file) = @_;

  my $the_cmd = "";
  my $verb_info = "-verb=" . $the_verb . " ";
  my $cpu_info = "-cpu_lim=" . $cpu_limit . " ";
  my $sat_info = "-sat_lim=" . $sat_limit . " ";

  if ($the_algo eq "janus"){
    $the_cmd = "perl janus.pl " . $the_file . " " . $verb_info . $cpu_info . $sat_info;
  }
  else{
    $the_cmd = "perl medea.pl " . $the_file . " " . $verb_info . $cpu_info . $sat_info;
  }
  system($the_cmd);
}

sub find_lattice_realization{
  my ($the_file, $set_row, $set_col) = @_;

  my $verb_info = "-verb=" . $the_verb . " ";
  my $row_info = "-set_row=" . $set_row . " ";
  my $col_info = "-set_col=" . $set_col . " ";
  my $cpu_info = "-cpu_lim=" . $cpu_limit . " ";
  my $sat_info = "-sat_lim=" . $sat_limit . " ";
  my $the_cmd = "perl janus.pl " . $the_file . " " . $verb_info . $cpu_info . $sat_info . $row_info . $col_info;
  #print "The command: $the_cmd \n";
  #sleep 1;
  system($the_cmd);
}

sub file_read_solution{
  my ($the_file, $the_method) = @_;

  my $dot_index = index($the_file, ".pla");
  my $file_sol = "";
  if ($the_method eq "janus"){
    $file_sol = substr($the_file, 0, $dot_index) . ".sol";
  }
  else{
    $file_sol = substr($the_file, 0, $dot_index) . "_dc.sol";
  }
  #print "Solution file: $file_sol \n";

  my $sol_row = 0;
  my $sol_col = 0;
  my @sol_arr = ();
  my $sol_found = 1;

  my $the_row = 0;
  my $the_col = 0;
  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_sol)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";
      #sleep 1;

      if (index($the_line, "#") != -1){
        #Extract the best solution
        if (index($the_line, "# Lattice RowxColumn: ") != -1){
          my $the_size = substr($the_line, 22, length($the_line)-22);
          $the_index = index($the_size, "x");
          $sol_row = substr($the_size, 0, $the_index);
          $sol_col = substr($the_size, $the_index+1, length($the_size)-$the_index-1);
        }
      }
      else{
        if (index($the_line, "NO SOLUTION") != -1){
          $sol_found = 0;
        }
        else{
          #Extract the solution matrix
          if (index($the_line, "| ") != -1){
            $the_row++;
            $the_col = 0;
            
            my $init_index = 0;
            while ($the_col != $sol_col){
              while (substr($the_line, $init_index, 1) eq " " or substr($the_line, $init_index, 1) eq "|"){
                $init_index++;
              }
              $last_index = $init_index;
              while (substr($the_line, $last_index, 1) ne " " and substr($the_line, $last_index, 1) ne "|"){
                $last_index++;
              }
              my $sol_entry = substr($the_line, $init_index, $last_index-$init_index);
              #print "sol entry: $sol_entry \n";

              $the_col++;
              $sol_arr[$the_row][$the_col] = $sol_entry;

              $init_index = $last_index;
            }
          }
        }
      }
    }
  }
  else{
    $sol_found = 1;
    print "Could not open the $file_sol file \n";
  }

  return ($sol_found, $sol_row, $sol_col, @sol_arr);
}

sub merge_solution{
  my ($the_row, $the_col, $sol_row, $sol_col, $the_sol_ref, $sol_arr_ref) = @_;
  my @the_sol = @ {$the_sol_ref};
  my @sol_arr = @ {$sol_arr_ref};

  my $max_row = 0;
  if ($the_row > $sol_row){
    $max_row = $the_row;
  }
  else{
    $max_row = $sol_row;
  }

  if ($sol_row){
    $sol_col++;
    foreach my $i (1 .. $max_row){
      $sol_arr[$i][$sol_col] = "F";
    }

    foreach my $i (1 .. $the_col){
      $sol_col++;
      foreach my $j (1 .. $the_row){
        $sol_arr[$j][$sol_col] = $the_sol[$j][$i];
      }
    }
  }
  else{
    $sol_row = $the_row;
    $sol_col = $the_col;
    @sol_arr = @the_sol;
  }

  return ($max_row, $sol_col, @sol_arr);
}

sub write_solution{
  my ($main_file, $tot_time, $imp_cnt, $sol_row, $sol_col, $sol_arr_ref, $sol_imp_ref) = @_;
  my @sol_arr = @ {$sol_arr_ref};
  my @sol_imp = @ {$sol_imp_ref};

  my $file_sol = $main_file . "_multi_tech_" . $the_tech . ".sol";

  open (my $fid_out, '>', $file_sol);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);    
  printf $fid_out "# Synthesis of Multiple Logic Functions with a Lattice of Four-Terminal Switches\n";
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Target Functions File: %0s \n", $file_pla;
  printf $fid_out "# Lattice RowxColumn: %0dx%0d \n", $sol_row, $sol_col;
  printf $fid_out "# Size of lattice: %0d \n", $sol_row*$sol_col;
  foreach my $i (1 .. $imp_cnt){
    printf $fid_out "# Realization of the %0s function lays in between %0d and %0d columns: \n", $sol_imp[$i][1], $sol_imp[$i][2], $sol_imp[$i][3];
  }
  printf $fid_out "# CPU time: %.2f \n", $tot_time;

  foreach my $i (1 .. $sol_row){
    printf $fid_out "| ";
    foreach my $j (1 .. $sol_col){
      if (defined $sol_arr[$i][$j]){
        if (index($sol_arr[$i][$j], "!") != -1){
          printf $fid_out "%0s | ", $sol_arr[$i][$j];
        }
        else{
          printf $fid_out "%0s  | ", $sol_arr[$i][$j];
        }
      }
      else{
        printf $fid_out "T  | ";
      }
    }
    printf $fid_out "\n";
  }

  close $fid_out;
}

sub find_lb_row_column{
  my ($file_dir, $file_out, $path_espresso) = @_;

  my $lb_row = 0;
  my $lb_col = 0;

  #Simplify the Boolean function
  my $file_temp = $file_dir . "temp_file.pla";
  my $the_cmd = $path_espresso . " -Dexact " . $file_out . " > " . $file_temp;
  system($the_cmd);

  #Extract the necessary data from the simplified function
  my ($in_num, $out_num, $prod_cnt, $min_deg, $in_arr_ref, $out_arr_ref, $prod_arr_ref) = file_read_pla($file_temp);

  $lb_col = 1;
  if ($prod_cnt > 1){
    $lb_col = 2;
  }

  $lb_row = 3;
  if ($min_deg <= 2){
    $lb_row = $min_deg;
  }

  return ($lb_row, $lb_col);
}

sub compute_minimum_cost_simp{
  my ($max_row, $part_cnt, @sol_size) = @_;

  my $the_col = 0;
  my $min_cost = 0;
  my @min_col_arr = ();

  #Compute the minimum column that a partition can have
  foreach my $the_part (1 .. $part_cnt){
    if ($sol_size[$the_part][1] == $max_row){
      $min_col_arr[$the_part] = $sol_size[$the_part][2];
      $the_col = $the_col + $sol_size[$the_part][2];
    }
    else{
      my $the_cost = $sol_size[$the_part][1]*$sol_size[$the_part][2];
      my $a_col = 0;
      do {
        $a_col++;
      } 
      while($a_col * $max_row < $the_cost);
      $min_col_arr[$the_part] = $a_col;
      $the_col = $the_col + $a_col;
    }
  }

  #Add the isolation columns
  $the_col = $the_col + $part_cnt - 1;
  $min_cost = $max_row * $the_col;

  return ($min_cost, @min_col_arr);
}

sub main_part{ 
  my $initial_time = time();
  
  my $file_dir = "";
  my $file_name = "";
  my $leaned_right = index($file_pla, "/");
  my $leaned_left = index($file_pla, "\\");
  if ($leaned_right != -1 or $leaned_left != -1){
    my $pla_index = index($file_pla, ".pla");
    my $dot_index = $pla_index;
    while (substr($file_pla, $pla_index, 1) ne "/" and substr($file_pla, $pla_index, 1) ne "\\"){
      $pla_index--;
    }
    $file_dir = substr($file_pla, 0, $pla_index+1) . "temp";
    $file_name = substr($file_pla, $pla_index+1, $dot_index-$pla_index-1);
  }
  else{
    $file_dir = "temp";
    $file_name = $file_pla;
  }
  if (!(-e $file_dir and -d $file_dir)){
    my $the_cmd = "mkdir " . $file_dir;
    system($the_cmd);
  }
  if ($leaned_right != -1){
    $file_dir = $file_dir . "/";
  }
  else{
    $file_dir = $file_dir . "\\";
  }
  
  my ($paths_ok, $path_espresso, $path_ilp, $path_sat) = extract_paths("paths.pl");
  my ($in_num, $out_num, $prod_num, $min_deg, $in_arr_ref, $out_arr_ref, $prod_arr_ref) = file_read_pla($file_pla);

  my $the_row = 0;
  my $the_col = 0;
  my @the_sol = ();

  my $sol_row = 0;
  my $sol_col = 0;
  my @sol_arr = ();
  my $temp_row = 0;
  my $temp_col = 0;
  my @temp_sol = ();
  my @temp_imp = ();
  my @orig_sol = ();
  my $sol_found = 0;

  my $imp_cnt = 0;
  my @sol_imp = ();
  my @sol_size = ();

  if ($in_num){
    my $dot_index = index($file_pla, ".pla");
    my $main_file = substr($file_pla, 0, $dot_index);
    
    if ($the_tech == 1){
      $imp_cnt = $out_num;
      foreach my $out_var (1 .. $out_num){
        my $file_out = $file_dir . $file_name . "_out" . $out_var . ".pla";
        print "\n";
        print YELLOW, "[INFO] Finding the realization for the $out_var. output... \n", RESET;
        generate_pla_file($file_out, $out_var, $in_num, $out_num, $prod_num, $in_arr_ref, $out_arr_ref, $prod_arr_ref);
        run_lattice_algorithm($file_out);
        ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, $the_algo);
        if ($sol_found){
          ($sol_row, $sol_col, @sol_arr) = merge_solution($the_row, $the_col, $sol_row, $sol_col, \@the_sol, \@sol_arr);
          $sol_imp[$out_var][1] = "$out_var";
          $sol_imp[$out_var][2] = $sol_col-$the_col+1;
          $sol_imp[$out_var][3] = $sol_col;
        }
      }
    }
    elsif ($the_tech == 2){
      @sol_size = ();
      my $max_row = 0;
      $imp_cnt = $out_num;

      foreach my $out_var (1 .. $out_num){
        my $file_out = $file_dir . $file_name . "_out" . $out_var . ".pla";
        print "\n";
        print YELLOW, "[INFO] Finding the realization for the $out_var. output... \n", RESET;
        generate_pla_file($file_out, $out_var, $in_num, $out_num, $prod_num, $in_arr_ref, $out_arr_ref, $prod_arr_ref);
        run_lattice_algorithm($file_out);
        ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, $the_algo);
        if ($sol_found){
          my @cloned_sol = @{ dclone(\@the_sol) };
          $sol_size[$out_var][1] = $the_row;
          $sol_size[$out_var][2] = $the_col;
          $sol_size[$out_var][3] = \@cloned_sol;
          if ($the_row > $max_row){
            $max_row = $the_row;
          }
          ($sol_row, $sol_col, @sol_arr) = merge_solution($the_row, $the_col, $sol_row, $sol_col, \@the_sol, \@sol_arr);
          $sol_imp[$out_var][1] = "$out_var";
          $sol_imp[$out_var][2] = $sol_col-$the_col+1;
          $sol_imp[$out_var][3] = $sol_col;
        }
      }

      print "\n";
      my $min_cost = $sol_row*$sol_col; 
      my $sol_lat_str = $sol_row . "x" . $sol_col;
      my $first_part_time = time() - $initial_time;
      print BRIGHT_BLUE, "[INFO] Initial solution: $sol_lat_str \n", RESET;
      print RED, "[INFO] Initial cost value: $min_cost \n", RESET;
      print CYAN, "[INFO] First part CPU time: $first_part_time \n", RESET;
      print "\n";

      @orig_sol = @{ dclone(\@sol_size) };

      while ($max_row >= 3){
        $temp_row = 0;
        $temp_col = 0;
        @temp_sol = ();
        @temp_imp = ();

        my ($simp_cost, @min_col_arr) = compute_minimum_cost_simp($max_row, $out_num, @orig_sol);
        #print "max_row: $max_row \n";
        #print "min_cost: $min_cost \n";
        #sleep 1;

        if ($simp_cost < $min_cost){
          my $cost_exceeded = 0;

          foreach my $out_var (1 .. $out_num){
            my $file_out = $file_dir . $file_name . "_out" . $out_var . ".pla";

            if ($orig_sol[$out_var][1] < $max_row){
              if ($orig_sol[$out_var][2] > 2){
                my $orig_col = $orig_sol[$out_var][2];
                my $sol_improved = 0;
                while (1){
                  $orig_col--;
                  if ($orig_col > 1){
                    if ($max_row*$orig_col >= $orig_sol[$out_var][1]*$orig_sol[$out_var][2]){
                      my $lat_str = $max_row . "x" . $orig_col;
                      print BOLD BLUE "[INFO] Checking if the $out_var. output can be realized using the $lat_str lattice... \n", RESET;
                      find_lattice_realization($file_out, $max_row, $orig_col);
                      ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, "janus");
                      my @cloned_sol = @{ dclone(\@the_sol) };
                      if ($sol_found){
                        $sol_improved = 1;
                        $sol_size[$out_var][1] = $the_row;
                        $sol_size[$out_var][2] = $the_col;
                        $sol_size[$out_var][3] = \@cloned_sol;
                      }
                      else{
                        last;
                      }
                    }
                  }
                  else{
                    last;
                  }
                }

                my @the_sol = ();
                if ($sol_improved){
                  $the_row = $sol_size[$out_var][1];
                  $the_col = $sol_size[$out_var][2];
                  @the_sol = @ {$sol_size[$out_var][3]};
                }
                else{
                  $the_row = $orig_sol[$out_var][1];
                  $the_col = $orig_sol[$out_var][2];
                  @the_sol = @ {$orig_sol[$out_var][3]};
                }
                ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
                $temp_imp[$out_var][1] = "$out_var";
                $temp_imp[$out_var][2] = $temp_col-$the_col+1;
                $temp_imp[$out_var][3] = $temp_col;
              }
              else{
                $the_row = $orig_sol[$out_var][1];
                $the_col = $orig_sol[$out_var][2];
                my @the_sol = @ {$orig_sol[$out_var][3]};
                ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
                $temp_imp[$out_var][1] = "$out_var";
                $temp_imp[$out_var][2] = $temp_col-$the_col+1;
                $temp_imp[$out_var][3] = $temp_col;
              }
            }
            elsif ($orig_sol[$out_var][1] > $max_row){
              my $orig_col = $orig_sol[$out_var][2];
              my $sol_improved = 0;
              while (1){
                $orig_col++;

                if ($max_row*$orig_col >= $orig_sol[$out_var][1]*$orig_sol[$out_var][2]){
                  my $current_cost = 0;
                  if ($out_var == 1){
                    $current_cost = $current_cost + $max_row*$orig_col;
                  }
                  elsif ($out_var > 1){
                    $current_cost = $current_cost + $max_row*$temp_col;
                    $current_cost = $current_cost + $max_row*($orig_col+1);
                  }
                  for (my $part_index=$out_var+1; $part_index<=$out_num; $part_index++){
                    $current_cost = $current_cost + $max_row*($min_col_arr[$part_index]+1);
                  }

                  if ($current_cost < $min_cost){
                    my $lat_str = $max_row . "x" . $orig_col;
                    print BOLD BLUE "[INFO] Checking if the $out_var. output can be realized using the $lat_str lattice... \n", RESET;
                    find_lattice_realization($file_out, $max_row, $orig_col);
                    ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, "janus");
                    my @cloned_sol = @{ dclone(\@the_sol) };
                    if ($sol_found){
                      $sol_improved = 1;
                      $sol_size[$out_var][1] = $the_row;
                      $sol_size[$out_var][2] = $the_col;
                      $sol_size[$out_var][3] = \@cloned_sol;
                      last;
                    }
                  }
                  else{
                    $cost_exceeded = 1;
                    last;
                  }
                }
              }

              my @the_sol = ();
              if ($sol_improved){
                $the_row = $sol_size[$out_var][1];
                $the_col = $sol_size[$out_var][2];
                @the_sol = @ {$sol_size[$out_var][3]};
              }
              else{
                $the_row = $orig_sol[$out_var][1];
                $the_col = $orig_sol[$out_var][2];
                @the_sol = @ {$orig_sol[$out_var][3]};
              }
              ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
              $temp_imp[$out_var][1] = "$out_var";
              $temp_imp[$out_var][2] = $temp_col-$the_col+1;
              $temp_imp[$out_var][3] = $temp_col;
            }
            elsif ($orig_sol[$out_var][1] == $max_row){
              $the_row = $orig_sol[$out_var][1];
              $the_col = $orig_sol[$out_var][2];
              my @the_sol = @ {$orig_sol[$out_var][3]};
              ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
              $temp_imp[$out_var][1] = "$out_var";
              $temp_imp[$out_var][2] = $temp_col-$the_col+1;
              $temp_imp[$out_var][3] = $temp_col;
            }

            if ($cost_exceeded){
              last;
            }
          }

          if (!$cost_exceeded){
            my $temp_cost = $temp_row*$temp_col;
            if ($temp_cost < $min_cost){
              print RED, "[INFO] Good job! The cost has been decreased to $temp_cost \n", RESET;
              $min_cost = $temp_cost;
              $sol_row = $temp_row;
              $sol_col = $temp_col;
              @sol_arr = @{ dclone(\@temp_sol) };
              @sol_imp = @{ dclone(\@temp_imp) };
            }
          }
        }
        else{
          if ($the_verb < 1){print BRIGHT_GREEN, "[INFO] Computation of the cost with $max_row rows points out a worse cost than the found so far! Decreasing max_row... \n", RESET;};
        }

        $max_row--;
      }
    }
    elsif ($the_tech == 3){
      my $max_row = 0;
      my $all_synth = 1;
      $imp_cnt = $out_num;

      foreach my $out_var (1 .. $out_num){
        my $file_out = $file_dir . $file_name . "_out" . $out_var . ".pla";
        print "\n";
        print BRIGHT_YELLOW "[INFO] Finding the realization for the $out_var. output... \n", RESET;
        generate_pla_file($file_out, $out_var, $in_num, $out_num, $prod_num, $in_arr_ref, $out_arr_ref, $prod_arr_ref);
        my ($lb_row, $lb_col) = find_lb_row_column($file_dir, $file_out, $path_espresso);
        print "[INFO] Lower on the number of rows: $lb_row \n";
        print "[INFO] Lower on the number of columns: $lb_col \n";
        if ($lb_row < 3){
          find_lattice_realization($file_out, 0, 0);
          my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, "janus");
          $sol_size[$out_var][1] = $the_row;
          $sol_size[$out_var][2] = $the_col;
          $sol_size[$out_var][3] = \@the_sol;
          if ($the_row > $max_row){
            $max_row = $the_row;
          }
        }
        else{
          $all_synth = 0; 
          $sol_size[$out_var][1] = 0;
          $sol_size[$out_var][2] = 0;
          $sol_size[$out_var][3] = 0;
        }
      }

      if (!$all_synth){
        $max_row = 3;
        foreach my $out_var (1 .. $out_num){
          my $file_out = $file_dir . $file_name . "_out" . $out_var . ".pla";

          if (!$sol_size[$out_var][1]){
            my $the_col = 0;  
            while (1){
              $the_col++;

              print "\n";
              print BRIGHT_BLUE "[INFO] Checking if the $out_var. output can be realized using the 3x$the_col lattice... \n", RESET;
              find_lattice_realization($file_out, 3, $the_col);
              my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, "janus");
              if ($sol_found){
                $sol_size[$out_var][1] = $the_row;
                $sol_size[$out_var][2] = $the_col;
                $sol_size[$out_var][3] = \@the_sol;
                ($sol_row, $sol_col, @sol_arr) = merge_solution($the_row, $the_col, $sol_row, $sol_col, \@the_sol, \@sol_arr);
                $sol_imp[$out_var][1] = "$out_var";
                $sol_imp[$out_var][2] = $sol_col-$the_col+1;
                $sol_imp[$out_var][3] = $sol_col;
                last;
              }
            }
          }
          else{
            if ($sol_size[$out_var][1] > 1){
              my $the_col = $sol_size[$out_var][2];
              while ($the_col > 2){
                $the_col--;

                print "\n";
                print BRIGHT_BLUE "[INFO] Checking if the $out_var. output can be realized using the 3x$the_col lattice... \n", RESET;
                find_lattice_realization($file_out, 3, $the_col);
                my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, "janus");
                if ($sol_found){
                  $sol_size[$out_var][1] = $the_row;
                  $sol_size[$out_var][2] = $the_col;
                  $sol_size[$out_var][3] = \@the_sol;
                }
                else{
                  last;
                }
              }
            }

            ($sol_row, $sol_col, @sol_arr) = merge_solution($sol_size[$out_var][1], $sol_size[$out_var][2], $sol_row, $sol_col, $sol_size[$out_var][3], \@sol_arr);
            $sol_imp[$out_var][1] = "$out_var";
            $sol_imp[$out_var][2] = $sol_col-$sol_size[$out_var][2]+1;
            $sol_imp[$out_var][3] = $sol_col;
          }
        }
      }

      my $min_cost = $sol_row*$sol_col;
      print BRIGHT_RED "Initial cost: $min_cost \n", RESET;

      while (1){
        $temp_row = 0;
        $temp_col = 0;
        @temp_sol = ();
        @temp_imp = ();

        $max_row++;
        foreach my $out_var (1 .. $out_num){
          my $the_row = $max_row;
          my $the_col = $sol_size[$out_var][2];
          my $file_out = $file_dir . $file_name . "_out" . $out_var . ".pla";

          if ($the_col > 2 and $sol_size[$out_var][1] > 1){
            while (1){
              $the_col--;
              if ($the_col > 1){
                my $lat_str = $the_row . "x" . $the_col;
                print "\n";
                print BOLD BLUE "[INFO] Checking if the $out_var. output can be realized using the $lat_str lattice... \n", RESET;
                find_lattice_realization($file_out, $the_row, $the_col);
                my ($sol_found, $the_row, $the_col, @the_sol) = file_read_solution($file_out, "janus");
                if ($sol_found){
                  $sol_size[$out_var][1] = $the_row;
                  $sol_size[$out_var][2] = $the_col;
                  $sol_size[$out_var][3] = \@the_sol;
                }
                else{
                  $the_row = $sol_size[$out_var][1];
                  $the_col = $sol_size[$out_var][2];
                  my @the_sol = @{ dclone(\@{$sol_size[$out_var][3]}) };
                  ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
                  $temp_imp[$out_var][1] = "$out_var";
                  $temp_imp[$out_var][2] = $temp_col-$the_col+1;
                  $temp_imp[$out_var][3] = $temp_col;
                  last;
                }
              }
              else{
                $the_row = $sol_size[$out_var][1];
                $the_col = $sol_size[$out_var][2];
                my @the_sol = @{ dclone(\@{$sol_size[$out_var][3]}) };
                ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
                $temp_imp[$out_var][1] = "$out_var";
                $temp_imp[$out_var][2] = $temp_col-$the_col+1;
                $temp_imp[$out_var][3] = $temp_col;
                last;
              }
            }
          }
          else{
            $the_row = $sol_size[$out_var][1];
            $the_col = $sol_size[$out_var][2];
            my @the_sol = @{ dclone(\@{$sol_size[$out_var][3]}) };
            ($temp_row, $temp_col, @temp_sol) = merge_solution($the_row, $the_col, $temp_row, $temp_col, \@the_sol, \@temp_sol);
            $temp_imp[$out_var][1] = "$out_var";
            $temp_imp[$out_var][2] = $temp_col-$the_col+1;
            $temp_imp[$out_var][3] = $temp_col;
          }
        }

        my $temp_cost = $temp_row*$temp_col;
        if ($temp_cost < $min_cost){
          print RED, "[INFO] Good job! The cost has been decreased to $temp_cost \n", RESET;
          $min_cost = $temp_cost;
          $sol_row = $temp_row;
          $sol_col = $temp_col;
          @sol_arr = @{ dclone(\@temp_sol) };
          @sol_imp = @{ dclone(\@temp_imp) };
        }
        else{
          last;
        }
      }
    }

    my $total_time = time() - $initial_time;
    write_solution($main_file, $total_time, $imp_cnt, $sol_row, $sol_col, \@sol_arr,\@sol_imp);
    my $sollat_str = $sol_row . "x" . $sol_col;
    print "\n";
    print BRIGHT_GREEN "[INFO] Finally, the multiple target functions have just been realized using a $sollat_str lattice \n", RESET;
    print BRIGHT_CYAN "[INFO] Total CPU time: $total_time \n", RESET;
  }
}

