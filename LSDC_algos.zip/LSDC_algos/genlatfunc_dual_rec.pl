#!/usr/bin/perl

use Cwd qw(); 
use strict;
#use warnings;
#use diagnostics;
use Storable qw(dclone);
use Time::HiRes qw( time );
use warnings FATAL => 'all';
use Term::ANSIColor qw(:constants);

my $is_pla = 0;
my $row_num = 0;
my $col_num = 0;
my $cpu_limit = 3600;

my $arg_ok = 1;
my $arg_cnt = 0;

while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
      last;
    }
    elsif(index($ARGV[$arg_cnt], "-r=") != -1){
      my $row_str = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3);
      if ($row_str =~ /[0-9]/ and !($row_str =~ /[^0-9]/)){
        $row_num = $row_str + 0.0;
      }
      else{
        $arg_ok = 0;
        last;
      }
    }
    elsif(index($ARGV[$arg_cnt], "-c=") != -1){
      my $col_str = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3);
      if ($col_str =~ /[0-9]/ and !($col_str =~ /[^0-9]/)){
        $col_num = $col_str + 0.0;
      }
      else{
        $arg_ok = 0;
        last;
      }
    }
    elsif(index($ARGV[$arg_cnt], "-cpu_lim=") != -1){
      my $cpu_limit = substr($ARGV[$arg_cnt], 9, length($ARGV[$arg_cnt])-9);
      if ($cpu_limit <= 0){
        $arg_ok = 0;
        last;
      }
    }
    elsif(index($ARGV[$arg_cnt], "-pla") != -1){
      $is_pla = 1;
    }
    else{
      $arg_ok = 0;
      last;
    }
  }
  else{
    last;
  }

  $arg_cnt++;
}

if ($arg_ok){
  main_part($row_num, $col_num);
}
else{
  help_part();
}

sub help_part{
  print "\n";
  print "###################################################################################\n";
  print "# Usage:        perl genlatfunc_dual_rec.pl -r=m -c=n -cpu_lim=<int> -pla         #\n";
  print "# -r:           Indicates the number of rows where m is a positive integer        #\n";
  print "# -c:           Indicates the number of columns where n is a positive integer     #\n";
  print "# -cpu_lim:     CPU time limit, by default it is 3600s                            #\n";
  print "# -pla:         Describe the lattice equation in PLA format                       #\n";
  print "# Output:       Dual lattice equation in sum of product form where the variables  #\n";
  print "#               are indexed as an integer, set to 0 initially, increased by each  #\n";
  print "#               column in every row                                               #\n";
  print "# Description:  Finds all the paths by extending the paths in the mx(n-1) lattice #\n";
  print "###################################################################################\n";
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      return $the_offset;
    }
  }

  return $the_offset;
}

sub write_lattice{
  my ($row_val, $col_val, $sop_cnt, $sop_lvl_ref, $sop_arr_ref) = @_;
  my @sop_lvl = @ {$sop_lvl_ref};
  my @sop_arr = @ {$sop_arr_ref};

  #my @the_sorted = naive_sort_ascending($sop_cnt, @sop_lvl);
  
  my $min_prod = 2^31-1;
  my $max_prod = 0;
  
  my @spec_prod = ();
  my $the_str = "d" . $row_val . "x" . "$col_val";
  
  my $fid_pla;
  my @zero_arr = ();
  if ($is_pla){
    my $file_pla = $the_str . ".pla";
    open ($fid_pla, '>', $file_pla);
    printf $fid_pla ".i %0d \n", $row_num*$col_num;
    printf $fid_pla ".o 1 \n";
    printf $fid_pla ".p %0d \n", $sop_cnt;

    foreach my $i (1 .. $row_num*$col_num){
      $zero_arr[$i] = 0;
    }
  }

  my $file_out = $the_str. ".eqn";
  open (my $fid_out, '>', $file_out);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);    
  printf $fid_out "# Automatic Generation of the %0dx%0d Lattice Function \n", $row_val, $col_val;
  printf $fid_out "# Date and Time: %0d/%0d/%0d %0d:%0d:%0d \n", $mday, ($mon+1), ($year % 100), $hour, $min, $sec;
  printf $fid_out "# Number of Inputs: %0d \n", $row_val*$col_val;
  printf $fid_out "# Number of Outputs: 1 \n";
  printf $fid_out "# INORDER = ";
  foreach my $i (1 .. $row_val * $col_val - 1){
    printf $fid_out "%d ", $i; 
  }
  printf $fid_out "%0d;\n", $row_val * $col_val;
  printf $fid_out "# OUTORDER = f; \n";
  foreach my $i (1 .. $sop_cnt){
    if (defined $spec_prod[$sop_lvl[$i]]){
      $spec_prod[$sop_lvl[$i]]++;
    }
    else{
      $spec_prod[$sop_lvl[$i]] = 1;

      if ($sop_lvl[$i] > $max_prod){
        $max_prod = $sop_lvl[$i];
      }
      if ($sop_lvl[$i] < $min_prod){
        $min_prod = $sop_lvl[$i];
      }
    }

    my @index_arr = @{ dclone(\@zero_arr) };
    foreach my $j (1 .. $sop_lvl[$i]){
      my $the_point = $sop_arr[$j][$i];
      my $the_col = int ($the_point / $row_val + 0.99);
      my $the_row = ($the_point % $row_val);
      if (!$the_row){
        $the_row = $row_val;
      }
      my $mapped_point = ($the_row-1)*$col_val + $the_col;

      printf $fid_out "%d ", $mapped_point;
      
      if ($is_pla){
        $index_arr[$mapped_point] = 1;
      }
    }
    printf $fid_out "\n";

    if ($is_pla){
      foreach my $in_index (1 .. $row_num*$col_num){
        if ($index_arr[$in_index]){
          printf $fid_pla "1";
        }
        else{
          printf $fid_pla "-";
        }
      }
      printf $fid_pla " 1 \n";
    }
  }
  printf $fid_out "# Summary of the Function \n";
  printf $fid_out "# Number of products: %0d \n", $sop_cnt;
  printf $fid_out "# Minimum size of a product: %0d \n", $min_prod;
  printf $fid_out "# Maximum size of a product: %0d \n", $max_prod;
  foreach my $i ($min_prod .. $max_prod){
    if (defined $spec_prod[$i]){
      printf $fid_out "# Number of products with %0d variables: %0d \n", $i, $spec_prod[$i];
    }
    else{
      printf $fid_out "# Number of products with %0d variables: 0 \n", $i;
    }
  }
  printf $fid_out "\n";
  close $fid_out;
  
  if ($is_pla){
    printf $fid_pla ".e \n";
    close $fid_pla;
  }
}

sub add_symmetric_products {
  my ($row_val, $col_val, $sop_cnt, $sop_lvl_ref, $sop_arr_ref) = @_;
  my @sop_lvl = @ {$sop_lvl_ref};
  my @sop_arr = @ {$sop_arr_ref};

  my @sym_arr = ();
  foreach my $the_point (1 .. $row_val*$col_val){
    my $the_col = int ($the_point / $row_val + 0.99);
    my $fl_sum = $row_val*(2*$the_col-1) + 1;

    $sym_arr[$the_point] = $fl_sum - $the_point;
  }

  my $row_sym = int ($row_num/2);
  foreach my $i (1 .. $sop_cnt){
    if ($sop_arr[1][$i] <= $row_sym){
      $sop_cnt++;
      $sop_lvl[$sop_cnt] = $sop_lvl[$i];
      foreach my $j (1 .. $sop_lvl[$i]){
        $sop_arr[$j][$sop_cnt] = $sym_arr[$sop_arr[$j][$i]];
      }
    }
  }
  
  return ($sop_cnt, \@sop_lvl, \@sop_arr);
}

sub read_lattice{
  my ($row_val, $col_val) = @_;

  my $file_name = "d" . $row_val . "x" . $col_val . ".eqn";

  my $prod_cnt = 0;
  my @prod_arr =();
  my @prod_lvl =();

  $prod_lvl[1000000] = 0;
  $prod_arr[0][1000000] = 0;

  my $the_end;
  my $the_var;
  my $the_index;
  my $init_index;
  my $last_index;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_name)) {
    while (my $the_line = <$file_header>) {
      chomp $the_line;
      #print "[INFO] The line: $the_line \n";

      $init_index=skip_spaces_forward($the_line, 0);
      if (substr($the_line, $init_index, 1) ne "#"){
        #Extract the products
        #print "[INFO] The product: $the_line \n";
        #sleep 1;
        
        $the_end = 0;
        my $llength = length($the_line);

        if ($init_index < $llength){
          $prod_cnt++;
          $prod_lvl[$prod_cnt] = 0;

          while ($init_index < $llength){
            $last_index = $init_index;
            while (substr($the_line,$last_index,1) ne " "){
              $last_index++;

              if ($last_index > $llength){
                $the_end = 1;
                last;
              }
            }

            $the_var = substr($the_line, $init_index, $last_index-$init_index);
            #print "[INFO] The product literal: $the_var \n";
            #sleep 1;
 
            my $the_row = int ($the_var / $col_val + 0.99);
            my $the_col = ($the_var % $col_val);
            if (!$the_col){
              $the_col = $col_val;
            }
            my $mapped_var = ($the_col-1)*$row_val + $the_row;

            $prod_lvl[$prod_cnt]++;
            $prod_arr[$prod_lvl[$prod_cnt]][$prod_cnt] = $mapped_var;

            $init_index = skip_spaces_forward($the_line, $last_index);
          }
        }
      }
    }

    close $file_header;
  }
  else{
    print RED, "[ERROR] Could not open the $file_name file \n", RESET;
  }

  return ($prod_cnt, \@prod_lvl, \@prod_arr);
}

sub add_path{
  my ($row_val, $col_val, $is_added, $the_index, $cand_move, $cand_point, $path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = @_;
  my @path_move = @ {$path_move_ref};
  my @path_end = @ {$path_end_ref};
  my @path_lvl = @ {$path_lvl_ref};
  my @path_arr = @ {$path_arr_ref};
 
  if ($is_added == 1){
    $path_lvl[$the_index]++;
    $path_move[$the_index] = abs(7 - $cand_move);
    $path_arr[$path_lvl[$the_index]][$the_index] = $cand_point;

    if ($cand_move == 2 or $cand_move == 4 or $cand_move == 7){
      my $the_col = int ($cand_point / $row_val + 0.99);
      if ($the_col == $col_val){
        $path_end[$the_index] = 1;
      }
      else{
        $path_end[$the_index] = 0;
      }
    }
  }
  else{
    $path_cnt++;
    $path_move[$path_cnt] = abs(7 - $cand_move);
    $path_lvl[$path_cnt] = $path_lvl[$the_index];
    foreach my $k (1 .. $path_lvl[$the_index]-1){
      $path_arr[$k][$path_cnt] = $path_arr[$k][$the_index];
    }
    $path_arr[$path_lvl[$path_cnt]][$path_cnt] = $cand_point;
    
    if ($cand_move == 2 or $cand_move == 4 or $cand_move == 7){
      my $the_col = int ($cand_point / $row_val + 0.99);
      if ($the_col == $col_val){
        $path_end[$path_cnt] = 1;
      }
      else{
        $path_end[$path_cnt] = 0;
      }
    }  
  }

  return ($path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
}

sub generate_lattice{
  my ($initial_time, $row_val, $col_val) = @_;

  my $sop_cnt = 0;
  my @sop_lvl = ();
  my @sop_arr = ();
  my $cpu_expired = 0;
  my $sop_lvl_ref = 0;
  my $sop_arr_ref = 0;

  my $the_size = $row_val*$col_val;

  my $row_sym = int ($row_val/2 + 0.99);
  my $lat_str = $row_val . "x" . $col_val;
  my $pre_lat_str = $row_val . "x" . ($col_val-1);
 
  #print "[INFO] Reading the $pre_lat_str lattice function... \n";
  my ($pre_sop_cnt, $pre_sop_lvl_ref, $pre_sop_arr_ref) = read_lattice($row_val, $col_val-1);
  my @pre_sop_arr = @ {$pre_sop_arr_ref};
  my @pre_sop_lvl = @ {$pre_sop_lvl_ref};

  #print "[INFO] Finding the $lat_str lattice function... \n";
  foreach my $i (1 .. $pre_sop_cnt){
    if ($pre_sop_arr[1][$i] <= $row_sym){
      my $path_cnt = 1;
      my @path_lvl = ();
      my @path_arr = ();
      my @path_end = ();
      my @path_move = ();
      my $path_end_ref = 0;
      my $path_lvl_ref = 0;
      my $path_arr_ref = 0;
      my $path_move_ref = 0;

      $path_end[$path_cnt] = 0;
      $path_lvl[$path_cnt] = $pre_sop_lvl[$i];
      foreach my $j (1 .. $pre_sop_lvl[$i]){
        $path_arr[$j][$path_cnt] = $pre_sop_arr[$j][$i];
      }
      
      $path_move[$path_cnt] = 3; #Indicates the previous move (0: up-left, 1: up, 2: up-right, 3: right, 4: left, 5: down-left, 6: down, 7: down-right)
      if ($col_val > 2){
        my $the_diff = $path_arr[$path_lvl[$path_cnt]][$path_cnt] - $path_arr[$path_lvl[$path_cnt]-1][$path_cnt];

        if ($the_diff == $row_val){
          $path_move[$path_cnt] = 3;
        }
        elsif ($the_diff == $row_val + 1){
          $path_move[$path_cnt] = 0;
        }
        elsif ($the_diff == $row_val - 1){
          $path_move[$path_cnt] = 5;
        }
      }

      while (1){
        my $the_end = 1;
        
        foreach my $j (1 .. $path_cnt){
          if (!$path_end[$j]){
            $the_end = 0;

            my $cur_term_cnt = $path_lvl[$j];
            my $last_point = $path_arr[$path_lvl[$j]][$j];
            my $the_col = int ($last_point / $row_val + 0.99);
            my $the_row = ($last_point % $row_val);
            my $the_move = $path_move[$j];
            if (!$the_row){
              $the_row = $row_val;
            }

            my $is_added = 0;
            foreach my $cand_move (0 .. 7){
              if ($the_move != $cand_move){
                my $is_invalid = 0;

                if ($cand_move == 0){
                  my $cand_point = $last_point - $row_val - 1;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
                  
                  if ($the_row == 1 or $the_col <= 2 or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+$row_val+1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col)){
                        $is_invalid = 1;
                      }
                    }
                  }

                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 1){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point - 1;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
                  
                  if ($the_row == 1 or $the_col == 1 or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+$row_val+1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 2){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point + $row_val - 1;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
                  
                  if ($the_row == 1 or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+$row_val+1 == $cand_point and $point_col+1==$cand_col) or ($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 3){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point - $row_val;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
                  
                  if ($the_col <= 2 or $the_row >= $row_val-1 or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if ($path_arr[$k][$j]+$row_val+1 == $cand_point or ($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 4){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point + $row_val;
                  my $cand_col = int ($cand_point / $row_val + 0.99);

                  if ($cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{ 
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+$row_val+1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 5){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point - $row_val + 1;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
                  
                  if ($the_col <= 2 or $the_row >= $row_val-1 or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+$row_val+1 == $cand_point and $point_col+1==$cand_col) or ($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 6){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point + 1;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
                  
                  if ($the_col == 1 or $the_row == $row_val or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+$row_val+1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }
                elsif ($cand_move == 7){ 
                  my $is_invalid = 0;
                  my $cand_point = $last_point + $row_val + 1;
                  my $cand_col = int ($cand_point / $row_val + 0.99);
 
                  if ($the_row == $row_val or $cand_point < 1 or $cand_point > $the_size){
                    $is_invalid = 1;
                  }
                  else{
                    foreach my $k (1 .. $cur_term_cnt){
                      my $point_col = int ($path_arr[$k][$j] / $row_val + 0.99);

                      if (($path_arr[$k][$j]+1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val+1 == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-$row_val == $cand_point and $point_col-1 == $cand_col) or ($path_arr[$k][$j]+$row_val-1 == $cand_point and $point_col+1 == $cand_col) or ($path_arr[$k][$j]-1 == $cand_point and $cand_col == $point_col) or ($path_arr[$k][$j]-$row_val-1 == $cand_point and $point_col-1 == $cand_col)){
                        $is_invalid = 1;
                        last;
                      }
                    }
                  }
                  
                  if (!$is_invalid){
                    $is_added++;
                    ($path_cnt, $path_move_ref, $path_end_ref, $path_lvl_ref, $path_arr_ref) = add_path($row_val, $col_val, $is_added, $j, $cand_move, $cand_point, $path_cnt, \@path_move, \@path_end, \@path_lvl, \@path_arr);
                    @path_end = @ {$path_end_ref};
                    @path_arr = @ {$path_arr_ref};
                    @path_lvl = @ {$path_lvl_ref};
                    @path_move = @ {$path_move_ref};
                  }
                }

              }
            }

            if (!$is_added){
              $path_end[$j] = -1;
            }
          }

          if (time()-$initial_time > $cpu_limit){
            $cpu_expired = 1;
            last;
          }
        }

        if ($the_end){
          foreach my $m (1 .. $path_cnt){
            if ($path_end[$m] == 1){
              $sop_cnt++;
              $sop_lvl[$sop_cnt] = $path_lvl[$m];
              foreach my $n (1 .. $path_lvl[$m]){
                $sop_arr[$n][$sop_cnt] = $path_arr[$n][$m];
              }
            }
          }

          last;
        }

        if ($cpu_expired){
          last;
        }
      }
    }

    if ($cpu_expired){
      last;
    }
  }

  if (!$cpu_expired){
    #print "[INFO] Adding the symmetric paths... \n";
    ($sop_cnt, $sop_lvl_ref, $sop_arr_ref) = add_symmetric_products($row_val, $col_val, $sop_cnt, \@sop_lvl, \@sop_arr);
    #print "[INFO] Number of products in the dual of the $lat_str lattice: $sop_cnt \n";
    #print "[INFO] Writing the lattice function... \n";
    write_lattice($row_val, $col_val, $sop_cnt, $sop_lvl_ref, $sop_arr_ref);
  }
}

sub main_part{
  my ($row_val, $col_val) = @_;

  my $initial_time = time();
  
  #Find the available lattice with (row_val)xn where n is the largest integer with n < $col_val. If not, generate the ($row_val)x1 lattice
  while (1){
    $col_val--;
    if (!$col_val){
      my @sop_lvl = ();
      my @sop_arr = ();
      my $sop_cnt = $row_val;

      foreach my $i (1 .. $row_val){
        $sop_lvl[$i] = 1;
        $sop_arr[1][$i] = $i;
      }

      $col_val++;
      write_lattice($row_val, 1, $sop_cnt, \@sop_lvl, \@sop_arr);
      last;
    }
    else{
      my $base_lat_str = "d" . $row_val . "x" . $col_val . ".eqn";
      if (-e $base_lat_str){
        last;
      }
    }
  }

  #Start building up the lattices recursively
  while ($col_val != $col_num){
    $col_val++;
    generate_lattice($initial_time, $row_val, $col_val);
    if (time()-$initial_time > $cpu_limit){
      last;
    }
  }
}

